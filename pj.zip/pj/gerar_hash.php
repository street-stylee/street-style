<?php
// Script temporário para gerar o hash da senha '123456'
$senha_clara = '123456';
$hash_gerado = password_hash($senha_clara, PASSWORD_DEFAULT);
echo "Use este HASH para atualizar o banco de dados:\n";
echo $hash_gerado;
?>