<?php
// Garantia de que a sessão está iniciada.
// Se 'formu.php' já faz isso, não há problema em chamar novamente (session_start() ignora chamadas repetidas).
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 1. Inicializa as variáveis para uso no HTML/PHP
$usuario_logado = false;
$primeiro_nome = 'Convidado'; 

// 2. Define o status e o nome com base na sessão
if (isset($_SESSION['usuario_id']) && isset($_SESSION['usuario_nome'])) {
    $usuario_logado = true;
    
    // Extrai o primeiro nome para a saudação
    $nome_completo = $_SESSION['usuario_nome'];
    $partes_nome = explode(' ', $nome_completo);
    $primeiro_nome = htmlspecialchars($partes_nome[0]);
}

// 3. Verifica o problema anterior (apenas para debug)
// Se o usuário estivesse tentando acessar o perfil, agora ele será redirecionado corretamente pelo perfil.php ou pelo login.php
?>

<header>
    <a href="index.php" class="logo"><img src="_ADM/img_index/logotipo.png" alt="Street Style Logo"></a>

    <ul class="navmenu">
        <li><a href="index.php">home</a></li>
        <li><a href="produtos.php">produtos</a></li>
        <li><a href="sobre.php">sobre</a></li>
        <li><a href="contato.php">contato</a></li>

        <li class="mobile-icons">
            <a href="busca/index.php"><i class='bx bx-search'></i> Busca</a>
        </li>
        <li class="mobile-icons">
            <a href="<?php echo $usuario_logado ? 'perfil.php' : 'login.php'; ?>"><i class='bx bx-user'></i>
                <?php echo $usuario_logado ? $primeiro_nome : 'Perfil'; ?>
            </a>
        </li>
        <li class="mobile-icons">
            <a href="carrinho.php"><i class='bx bx-cart'></i> Carrinho</a>
        </li>
    </ul>

    <div class="nav-icon">

        <?php if ($usuario_logado): ?>
            <a href="perfil.php" class="usuario-logado" title="Ver Perfil">
                Olá, <?php echo $primeiro_nome; ?>
            </a>
            <a href="logout.php" title="Sair do Sistema" class="btn-logout">
                <i class='bx bx-log-out'></i>
            </a>
            <a href="busca/index.php" class="desktop-icon"><i class='bx bx-search'></i></a>

        <?php else: ?>
            <a href="busca/index.php" class="desktop-icon"><i class='bx bx-search'></i></a>
            <a href="login.php" title="Fazer Login ou Cadastrar" class="desktop-icon">
                <i class='bx bx-user'></i>
            </a>
        <?php endif; ?>

        <a href="carrinho.php" class="desktop-icon"><i class='bx bx-cart'></i></a>

        <div class="bx bx-menu" id="menu-icon"></div>
    </div>

</header>