<?php
// header.php

// 1. Garantia de que a sessão está iniciada.
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 2. Inicializa e define variáveis de usuário
$usuario_logado = false;
$primeiro_nome = 'Convidado';

if (isset($_SESSION['usuario_id']) && isset($_SESSION['usuario_nome'])) {
    $usuario_logado = true;
    $nome_completo = $_SESSION['usuario_nome'];
    $partes_nome = explode(' ', $nome_completo);
    $primeiro_nome = htmlspecialchars($partes_nome[0]);
}

// ----------------------------------------------------
// NOVO: LÓGICA PARA CONTAR ITENS DO CARRINHO (BD)
// ----------------------------------------------------
$quantidade_carrinho = 0;
$conexao_header_aberta = false;

// 1. Tenta REABRIR a conexão se estiver fechada ou não existir (RESOLVE O ERRO FATAL)
if (!isset($conexao) || !is_object($conexao) || empty($conexao->server_info)) {

    // ATENÇÃO: SUBSTITUA 'USUARIO_BD' e 'SENHA_BD' pelos seus dados reais!
    // Para XAMPP/MAMP padrão, geralmente é 'root' e ''.
    @$conexao = new mysqli("localhost:3306", "root", "", "testebe");

    // Se a conexão falhou após a tentativa de reabertura, remove a variável.
    if ($conexao->connect_error) {
        unset($conexao);
    } else {
        $conexao_header_aberta = true;
    }
} else {
    // Se a conexão já existia e estava ativa, podemos usá-la.
    $conexao_header_aberta = true;
}


// 2. Procede com a contagem SOMENTE se a conexão estiver ATIVA
if ($conexao_header_aberta) {

    // 3. Define o ID de referência do carrinho
    if (!isset($_SESSION['carrinho_session_id'])) {
        $_SESSION['carrinho_session_id'] = session_id();
    }

    $carrinho_ref_id = $_SESSION['usuario_id'] ?? $_SESSION['carrinho_session_id'];
    $is_user = isset($_SESSION['usuario_id']);

    $sql_count = "SELECT SUM(quantidade) FROM carrinho_itens 
                  WHERE " . ($is_user ? "usuario_id = ?" : "carrinho_session_id = ?");

    // Tenta preparar a query
    if ($stmt_count = $conexao->prepare($sql_count)) {
        if ($is_user) {
            $stmt_count->bind_param("i", $carrinho_ref_id);
        } else {
            $stmt_count->bind_param("s", $carrinho_ref_id);
        }

        $stmt_count->execute();
        // ...
        $stmt_count->execute();

        // CORREÇÃO: Usa fetch_array() ou fetch_row() para compatibilidade
        $resultado = $stmt_count->get_result();
        if ($linha = $resultado->fetch_row()) {
            $total_itens = $linha[0]; // O resultado do SUM(quantidade) é o primeiro (e único) campo
        } else {
            $total_itens = 0;
        }

        $stmt_count->close();

        $quantidade_carrinho = intval($total_itens);
        // ...

        $quantidade_carrinho = intval($total_itens);
    }

    // 4. Se a conexão foi reaberta NESTE script, feche-a ao terminar
    // Isso evita que ela fique aberta desnecessariamente se o script anterior a fechou.
    if ($conexao_header_aberta && !isset($conexao_originalmente_incluida)) {
        // Não feche aqui, pois pode ser necessária mais tarde no produto.php.
        // A melhor prática é fechar no final do produto.php!
    }
}
// ----------------------------------------------------
?>

<header id="header-main">
    <a href="index.php" class="logo"><img src="_ADM/img/logotipo.png" alt="Street Style Logo"></a>

    <ul class="navmenu">
        <li><a href="index.php">home</a></li>
        <li><a href="produtos.php">produtos</a></li>
        <li><a href="sobre.php">sobre</a></li>
        <li><a href="contato.php">contato</a></li>

        <li class="mobile-icons">
            <a href="buscar.php"><i class='bx bx-search'></i> Busca</a>
        </li>
        <li class="mobile-icons">
            <a href="<?php echo $usuario_logado ? 'perfil.php' : 'login.php'; ?>"><i class='bx bx-user'></i>
                <?php echo $usuario_logado ? $primeiro_nome : 'Perfil'; ?>
            </a>
        </li>
        <li class="mobile-icons">
            <a href="carrinho_visualizar.php"><i class='bx bx-cart'></i> Carrinho
                <?php if ($quantidade_carrinho > 0): ?>
                    (<?php echo $quantidade_carrinho; ?>)
                <?php endif; ?>
            </a>
        </li>
    </ul>

    <div class="nav-icon">

        <div class="search-container desktop-search">
            <form action="buscar.php" method="GET" class="search-form">
                <input type="text" name="q" placeholder="Buscar produtos..." required>
                <button type="submit" title="Buscar"><i class='bx bx-search'></i></button>
            </form>
        </div>

        <?php if ($usuario_logado): ?>
            <a href="perfil.php" class="usuario-logado desktop-icon" title="Ver Perfil">
                Olá, <?php echo $primeiro_nome; ?>
            </a>
            <a href="logout.php" title="Sair do Sistema" class="btn-logout desktop-icon">
                <i class='bx bx-log-out'></i>
            </a>
        <?php else: ?>
            <a href="login.php" title="Fazer Login ou Cadastrar" class="desktop-icon">
                <i class='bx bx-user'></i>
            </a>
        <?php endif; ?>

        <a href="carrinho_visualizar.php" class="desktop-icon carrinho-link">
            <i class='bx bx-cart'></i>
            <?php if ($quantidade_carrinho > 0): ?>
                <span class="carrinho-badge"><?php echo $quantidade_carrinho; ?></span>
            <?php endif; ?>
        </a>

        <div class="bx bx-menu" id="menu-icon"></div>
    </div>

</header>

<style>
    .carrinho-link {
        position: relative;
        display: flex;
        align-items: center;
    }

    .carrinho-badge {
        position: absolute;
        top: -5px;
        right: -10px;
        background: #e74c3c;
        color: white;
        border-radius: 50%;
        padding: 2px 6px;
        font-size: 0.7em;
        font-weight: bold;
        line-height: 1;
        z-index: 10;
        min-width: 20px;
        text-align: center;
    }

    .nav-icon .bx-cart {
        font-size: 1.5em;
    }
</style>