<?php
// carrinho_visualizar.php (VISUALIZAÇÃO DO CARRINHO BASEADO NO BD)

session_start();
require_once 'formu.php'; // Inclui a conexão com o banco de dados

// 1. Define o ID de referência
$usuario_logado = isset($_SESSION['usuario_id']);
if (!isset($_SESSION['usuario_id']) && !isset($_SESSION['carrinho_session_id'])) {
    $_SESSION['carrinho_session_id'] = session_id();
}
$carrinho_ref_id = $_SESSION['usuario_id'] ?? $_SESSION['carrinho_session_id'];
$is_user = isset($_SESSION['usuario_id']);

$primeiro_nome = $usuario_logado ? htmlspecialchars(explode(' ', $_SESSION['usuario_nome'] ?? 'Usuário')[0]) : '';

// 2. Busca os itens do carrinho no banco de dados
$sql_carrinho_itens = "
    SELECT 
        CI.id AS item_carrinho_id, 
        CI.quantidade, 
        P.preco AS preco_unitario,
        P.id AS produto_id, 
        P.nome AS nome_produto, 
        P.imagem_url,
        PV.tamanho
    FROM carrinho_itens CI
    JOIN produtos P ON CI.produto_id = P.id
    JOIN produto_variacoes PV ON CI.variacao_id = PV.id
    WHERE " . ($is_user ? "CI.usuario_id = ?" : "CI.carrinho_session_id = ?");

$stmt_carrinho_itens = $conexao->prepare($sql_carrinho_itens);

if ($stmt_carrinho_itens === false) {
    die("Erro na preparação da consulta SQL: " . $conexao->error);
}

if ($is_user) {
    $stmt_carrinho_itens->bind_param("i", $carrinho_ref_id);
} else {
    $stmt_carrinho_itens->bind_param("s", $carrinho_ref_id);
}

$stmt_carrinho_itens->execute();
$resultado_itens = $stmt_carrinho_itens->get_result();

$carrinho_itens = [];
while ($item = $resultado_itens->fetch_assoc()) {
    $carrinho_itens[] = $item;
}
$stmt_carrinho_itens->close();


// 3. Calcula o total
$total_geral = 0;
foreach ($carrinho_itens as $item) {
    $total_geral += $item['preco_unitario'] * $item['quantidade'];
}

// Fechamento da conexão no final do script
// Movemos o fechamento da conexão para o final do HTML, antes da tag </body>
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrinho de Compras - Street Style</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&display=swap"        
        rel="stylesheet">
    <link        
        href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&family=Poppins:wght@100;300;400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link rel="shortcut icon" href="../_ADM/favicon.ico/favicon.ico" type="image/x-icon">
    <link rel="icon" type="image/png" sizes="32x32" href="_ADM/favicon.ico/favicon-96x96.png">

    <link rel="stylesheet" href="_ADM/css/estilo_pg_produto.css">
    <link rel="stylesheet" href="_ADM/css/header-footer.css">
    <link rel="stylesheet" href="_ADM/css/estilo_carrinho.css">
</head>

<body>
    <?php require_once 'header.php' ?>

    <div class="carrinho-container">
        <h1><i class='bx bx-shopping-bag' style="vertical-align: middle;"></i> Seu Carrinho</h1>

        <?php if (!empty($carrinho_itens)): ?>
            <div class="carrinho-header">
                <a href="carrinho.php?acao=limpar" class="btn btn-limpar-tudo">
                    <i class="fa-solid fa-trash-can"></i> Limpar Carrinho
                </a>
            </div>

            <ul class="lista-itens">
                <?php foreach ($carrinho_itens as $item): ?>

                    <?php
                    $preco_total_item = $item['preco_unitario'] * $item['quantidade'];
                    $item_id = $item['item_carrinho_id'];
                    $link_base = "carrinho.php?item_id=" . urlencode($item_id);
                    ?>
                    <li class="item-carrinho">
                        <div class="item-imagem">
                            <img src="<?php echo htmlspecialchars($item['imagem_url']); ?>"        
                                alt="<?php echo htmlspecialchars($item['nome_produto']); ?>">
                        </div>
                        <div class="item-info">
                            <a href="produto.php?id=<?php echo htmlspecialchars($item['produto_id']); ?>" class="item-nome">
                                <?php echo htmlspecialchars($item['nome_produto']); ?>
                            </a>
                            <span class="item-tamanho">Tamanho:
                                <?php echo htmlspecialchars($item['tamanho']); ?></span>
                            <span class="item-preco-unitario">R$

                                <?php echo number_format($item['preco_unitario'], 2, ',', '.'); ?>/un.</span>

                            <div class="item-acoes-mobile">
                                <span class="quantidade-mobile">Qtde:

                                    <?php echo htmlspecialchars($item['quantidade']); ?></span>
                                <a href="<?php echo $link_base; ?>&acao=diminuir"              
                                    class="btn-remover-mobile">Diminuir</a>
                                <a href="<?php echo $link_base; ?>&acao=aumentar"          
                                    class="btn-remover-mobile">Aumentar</a>
                            </div>
                        </div>

                        <div class="item-quantidade">
                            <a href="<?php echo $link_base; ?>&acao=diminuir"                       class="btn-qty">-</a>
                            <span class="quantidade-display"><?php echo htmlspecialchars($item['quantidade']); ?></span>
                            <a href="<?php echo $link_base; ?>&acao=aumentar" class="btn-qty">+</a>
                        </div>

                        <div class="item-subtotal">
                            <span class="subtotal-label">Subtotal</span>
                            <span class="subtotal-valor">R$
                                <?php echo number_format($preco_total_item, 2, ',', '.'); ?></span>
                        </div>

                        <a href="<?php echo $link_base; ?>&acao=excluir" class="btn-remover">
                            <i class="fa-solid fa-xmark"></i>
                        </a>
                    </li>
                <?php endforeach; ?>

            </ul>

            <div class="resumo-compra">
                <div class="resumo-row">
                    <span>Subtotal de Produtos (<?php echo count($carrinho_itens); ?> itens)</span>
                    <span class="valor-produtos">R$
                        <?php echo number_format($total_geral, 2, ',', '.'); ?></span>
                </div>
                <div class="resumo-row total-final">
                    <h3>Total a Pagar</h3>
                    <h3 class="valor-final">R$ <?php echo number_format($total_geral, 2, ',', '.'); ?>
                    </h3>
                </div>

                <?php if ($usuario_logado): ?>
                    <a href="checkout.php" class="btn-finalizar-compra">
                        <i class="fa-solid fa-truck-fast"></i> Finalizar Pedido
                    </a>
                <?php else: ?>
                    <a href="login.php?redirect=checkout.php" class="btn-finalizar-compra btn-alert">
                        <i class="fa-solid fa-user-lock"></i> Faça Login para Finalizar
                    </a>

                    <p style="text-align: center; margin-top: 10px;">
                        Não tem conta? 
                        <a href="cadastro.php?redirect=checkout.php" style="font-weight: bold; color: #333;">Cadastre-se</a>
                    </p>
                <?php endif; ?>

                <style>
                    .btn-alert {
                        background-color: #f39c12 !important;
                        box-shadow: 0 4px 8px rgba(243, 156, 18, 0.4);
                    }

                    .btn-alert:hover {
                        background-color: #e67e22 !important;
                        box-shadow: 0 6px 12px rgba(243, 156, 18, 0.6);
                    }
                </style>

            </div>

        <?php else: ?>
            <div class="carrinho-vazio">
                <i class='bx bx-shopping-bag' style="font-size: 80px; color: #ccc;"></i>
                <h2>Seu carrinho está vazio!</h2>
                <p>Parece que você ainda não adicionou nenhum item.</p>
            </div>
        <?php endif; ?>

        <a href="produtos.php" class="btn-continuar-comprando">
            <i class="fa-solid fa-arrow-left"></i> Continuar Comprando
        </a>
    </div>

    <section class="contato">
    </section>
    <div class="texto-final">
        <p>Street Style © 2025. Todos os direitos reservados.</p>
    </div>


    <script>
        // Função para mudar a imagem principal ao rolar (Header)
        window.onscroll = function () {
            scrollFunction();
        };

        function scrollFunction() {
            var header = document.querySelector('header');
            if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        }
    </script>

</body>

</html>
<?php
// Fechamento da conexão no final do script
if (isset($conexao)) {
    $conexao->close();
}
?>