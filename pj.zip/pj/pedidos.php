<?php
require_once 'formu.php';
@session_start();

// 1. VERIFICAÇÃO DE LOGIN
if (!isset($_SESSION['usuario_id'])) { 
    header("Location: login.php");
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$pedidos = [];

// 2. BUSCA DOS PEDIDOS DO USUÁRIO
// Ordena do mais recente para o mais antigo
$sql = "SELECT id, data_pedido, total_geral, status FROM pedidos WHERE usuario_id = ? ORDER BY data_pedido DESC";
$stmt = $conexao->prepare($sql);

if ($stmt) {
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $resultado = $stmt->get_result();

    while ($pedido = $resultado->fetch_assoc()) {
        $pedidos[] = $pedido;
    }
    $stmt->close();
}

// Fechamento da conexão
if (isset($conexao)) {
    $conexao->close();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meus Pedidos | Street Style</title>
    <link rel="stylesheet" href="_ADM/css/header-footer.css">
    <link rel="stylesheet" href="_ADM/css/perfil.css">
    <link rel="stylesheet" href="_ADM/css/footer.css">

    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <style>
    /* ==================================== */
    /* ESTILOS GERAIS DA PÁGINA 'MEUS PEDIDOS' */
    /* ==================================== */
    
    /* Variáveis de Cores (Ajuste se necessário) */
    :root {
        --cor-principal: #333; /* Texto escuro */
        --cor-secundaria: #555; /* Texto cinza */
        --cor-borda-clara: #eee;
        --cor-sucesso: #27ae60; /* Verde do botão/status Concluído */
        --cor-atencao: #ffc107; /* Amarelo do status Pendente */
        --cor-fundo-card: #f9f9f9; /* Fundo suave para o card */
    }

    .pedidos-container {
        max-width: 850px; /* Largura otimizada */
        margin: 100px auto 50px; /* Margem ajustada */
        padding: 30px 20px;
    }

    /* Título principal */
    .pedidos-container h1 {
        font-size: 2rem;
        font-weight: 700;
        color: var(--cor-principal);
        margin-bottom: 30px;
        border-bottom: 2px solid var(--cor-borda-clara);
        padding-bottom: 10px;
        display: flex;
        align-items: center;
        gap: 10px; /* Espaço entre o ícone e o texto */
    }

    /* Estilo do Card do Pedido */
    .pedido-card {
        background-color: var(--cor-fundo-card); /* Fundo suave */
        border: 1px solid var(--cor-borda-clara);
        border-radius: 12px;
        margin-bottom: 25px;
        padding: 25px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.05); /* Sombra mais suave */
        transition: transform 0.2s, box-shadow 0.2s;
    }

    .pedido-card:hover {
        transform: translateY(-2px); /* Efeito de elevação sutil */
        box-shadow: 0 6px 15px rgba(0,0,0,0.1);
    }

    /* Cabeçalho do Card (ID e Status) */
    .pedido-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding-bottom: 15px;
        margin-bottom: 15px;
        border-bottom: 1px solid #e0e0e0;
    }

    .pedido-header h3 {
        font-size: 1.6rem;
        color: var(--cor-principal);
        font-weight: 700;
        margin: 0;
    }
    
    /* Detalhes do Pedido (Data e Total) */
    .pedido-details p {
        margin: 8px 0;
        font-size: 1rem;
        color: var(--cor-secundaria);
    }

    .pedido-details strong {
        color: var(--cor-principal);
        font-weight: 600;
        display: inline-block; /* Alinha o texto e o valor */
        min-width: 50px; /* Garante alinhamento visual */
    }

    /* Status Tag */
    .pedido-status {
        padding: 6px 12px;
        border-radius: 20px; /* Arredondado para parecer uma tag */
        font-weight: 700;
        font-size: 0.85rem;
        text-transform: uppercase;
    }

    /* Estilos Específicos para os Status */
    .status-Pendente { 
        background-color: #ffeeb3; 
        color: #b08d00; 
        border: 1px solid #ffcc00;
    }
    .status-Concluido, .status-Enviado { /* Adicione mais status se tiver */
        background-color: #d8f5e0; 
        color: #1e8449;
        border: 1px solid var(--cor-sucesso);
    }
    .status-Cancelado {
        background-color: #fcebeb;
        color: #cc3333;
        border: 1px solid #cc3333;
    }

    /* Botão Ver Detalhes */
    .pedido-details a.btn-primary {
        background-color: var(--cor-principal); /* Usando a cor principal do tema Street Style */
        color: #fff;
        border: none;
        border-radius: 6px;
        padding: 8px 15px;
        font-size: 0.9rem;
        font-weight: 600;
        text-decoration: none;
        transition: background-color 0.3s;
        margin-top: 15px;
        display: inline-block;
    }

    .pedido-details a.btn-primary:hover {
        background-color: #555;
    }

    /* Estilo para quando não houver pedidos */
    .pedidos-container .pedido-card[style="text-align: center;"] {
        padding: 40px;
        border: 2px dashed var(--cor-borda-clara);
    }
</style>
</head>
<body>
    <?php require_once 'header.php'; ?>

    <div class="pedidos-container">
        <h1><i class='bx bxs-package'></i> Meus Pedidos</h1>

        <?php if (empty($pedidos)): ?>
            <div class="pedido-card" style="text-align: center;">
                <p>Você ainda não fez nenhum pedido.</p>
                <a href="produtos.php" class="btn-primary">Começar a comprar</a>
            </div>
        <?php else: ?>
            <?php foreach ($pedidos as $pedido): ?>
                <div class="pedido-card">
                    <div class="pedido-header">
                        <h3>Pedido #<?php echo htmlspecialchars($pedido['id']); ?></h3>
                        <span class="pedido-status status-<?php echo htmlspecialchars($pedido['status']); ?>">
                            <?php echo htmlspecialchars($pedido['status']); ?>
                        </span>
                    </div>
                    <div class="pedido-details">
                        <p><strong>Data:</strong> <?php echo date('d/m/Y H:i', strtotime($pedido['data_pedido'])); ?></p>
                        <p><strong>Total:</strong> R$ <?php echo number_format($pedido['total_geral'], 2, ',', '.'); ?></p>
                        <a href="pedido_concluido.php?id=<?php echo $pedido['id']; ?>" class="btn-primary" style="margin-top: 10px; display: inline-block;">Ver Detalhes</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <?php require_once 'footer.php'; ?>
</body>
</html>