<?php
require_once 'formu.php'; // Inclui a conexão e inicia a sessão

// Variável para armazenar os pedidos
$pedidos = [];
$mensagem = '';
$tipo_mensagem = '';

// 1. VERIFICAÇÃO DE LOGIN
// editar_perfil.php (CÓDIGO CORRIGIDO - Use esta opção)

// 1. VERIFICAÇÃO DE LOGIN
// Redireciona se o ID do usuário NÃO estiver definido na sessão
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

$usuario_id = $_SESSION['usuario_id']; // Agora podemos usar o ID com segurança
// ... o restante do código segue

// =======================================================
// 2. BUSCA DO HISTÓRICO DE PEDIDOS
// =======================================================
// Busca todos os pedidos do usuário logado, ordenados do mais recente para o mais antigo
$sql_pedidos = "SELECT id, data_pedido, status, total FROM pedidos WHERE usuario_id = ? ORDER BY data_pedido DESC";
$stmt_pedidos = $conexao->prepare($sql_pedidos);

if ($stmt_pedidos) {
    $stmt_pedidos->bind_param("i", $usuario_id);
    $stmt_pedidos->execute();
    $resultado = $stmt_pedidos->get_result();

    if ($resultado->num_rows > 0) {
        // Armazena todos os pedidos em um array
        while ($pedido = $resultado->fetch_assoc()) {
            $pedidos[] = $pedido;
        }
    } else {
        $mensagem = "Você ainda não realizou nenhum pedido.";
        $tipo_mensagem = 'info';
    }
    $stmt_pedidos->close();
} else {
    $mensagem = "Erro interno ao buscar o histórico de pedidos: " . $conexao->error;
    $tipo_mensagem = 'erro';
}

// =======================================================
// FUNÇÃO PARA BUSCAR ITENS DO PEDIDO (Para detalhes)
// =======================================================
function buscarItensPedido($conexao, $pedido_id)
{
    $itens = [];
    $sql_itens = "SELECT nome_produto, quantidade, preco_unitario FROM itens_pedido WHERE pedido_id = ?";
    $stmt_itens = $conexao->prepare($sql_itens);

    if ($stmt_itens) {
        $stmt_itens->bind_param("i", $pedido_id);
        $stmt_itens->execute();
        $resultado_itens = $stmt_itens->get_result();

        while ($item = $resultado_itens->fetch_assoc()) {
            $itens[] = $item;
        }
        $stmt_itens->close();
    }
    return $itens;
}

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meus Pedidos | Street Style</title>

    <link rel="stylesheet" href="_ADM/css/header-footer.css">
    <link rel="stylesheet" href="_ADM/css/produto.css">
    <link rel="stylesheet" href="_ADM/css/perfil.css">
    <link rel="stylesheet" href="_ADM/css/pedidos.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
</head>

<body>

    <?php require_once 'header.php'; ?>

    <section class="pedidos-section">
        <div class="pedidos-container">

            <div class="pedidos-header">
                <i class='bx bxs-package'></i>
                <h1>Meus Pedidos</h1>
            </div>

            <a href="perfil.php" class="btn-voltar-perfil">
                <i class='bx bx-arrow-back'></i> Voltar ao Perfil
            </a>

            <?php if (!empty($mensagem)): ?>
                <div class="mensagem-feedback <?php echo $tipo_mensagem == 'info' ? 'aviso' : $tipo_mensagem; ?>">
                    <?php echo $mensagem; ?>
                </div>
            <?php endif; ?>

            <div class="lista-pedidos">

                <?php if (!empty($pedidos)): ?>
                    <?php foreach ($pedidos as $pedido):
                        // Formata a data para exibição
                        $data_formatada = date('d/m/Y H:i', strtotime($pedido['data_pedido']));
                        $itens_pedido = buscarItensPedido($conexao, $pedido['id']);
                        ?>
                        <div class="pedido-card">
                            <div class="pedido-sumario">
                                <div class="sumario-item">
                                    <label>Número do Pedido</label>
                                    <p class="pedido-id">#<?php echo htmlspecialchars($pedido['id']); ?></p>
                                </div>
                                <div class="sumario-item">
                                    <label>Data</label>
                                    <p><?php echo $data_formatada; ?></p>
                                </div>
                                <div class="sumario-item">
                                    <label>Status</label>
                                    <span class="status-badge status-<?php echo strtolower($pedido['status']); ?>">
                                        <?php echo htmlspecialchars($pedido['status']); ?>
                                    </span>
                                </div>
                                <div class="sumario-item total">
                                    <label>Total</label>
                                    <p class="valor-total">R$ <?php echo number_format($pedido['total'], 2, ',', '.'); ?></p>
                                </div>
                            </div>

                            <div class="pedido-detalhes">
                                <h4>Itens do Pedido:</h4>
                                <ul class="lista-itens">
                                    <?php foreach ($itens_pedido as $item): ?>
                                        <li>
                                            <span class="item-nome"><?php echo htmlspecialchars($item['nome_produto']); ?></span>
                                            <span class="item-info"><?php echo htmlspecialchars($item['quantidade']); ?>x | R$
                                                <?php echo number_format($item['preco_unitario'], 2, ',', '.'); ?></span>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>

            </div>

        </div>
    </section>

    <?php require_once 'footer.php'; ?>
    <script>
        // Opcional: Script simples para mostrar/esconder detalhes (se necessário)
    </script>
</body>

</html>
<?php
// Fechamento da conexão
if (isset($conexao)) {
    $conexao->close();
}
?>