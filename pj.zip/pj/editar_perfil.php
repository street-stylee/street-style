<?php
require_once 'formu.php'; // Inclui a conexão e inicia a sessão

// Variável para armazenar a mensagem de feedback
$mensagem = '';
$tipo_mensagem = ''; // 'sucesso' ou 'erro'

// 1. VERIFICAÇÃO DE LOGIN
// editar_perfil.php (CÓDIGO CORRIGIDO - Use esta opção)

// 1. VERIFICAÇÃO DE LOGIN
// Redireciona se o ID do usuário NÃO estiver definido na sessão
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

$usuario_id = $_SESSION['usuario_id']; // Agora podemos usar o ID com segurança
// ... o restante do código segue
$dados_usuario = []; // Inicializa para evitar erros

// =======================================================
// 2. BUSCA DOS DADOS ATUAIS
// =======================================================
$sql_busca = "SELECT nome, email, cpf, telefone, endereco FROM usuarios WHERE id = ?";
$stmt_busca = $conexao->prepare($sql_busca);

if ($stmt_busca) {
    $stmt_busca->bind_param("i", $usuario_id);
    $stmt_busca->execute();
    $resultado = $stmt_busca->get_result();

    if ($resultado->num_rows > 0) {
        $dados_usuario = $resultado->fetch_assoc();
    } else {
        // Erro: Usuário logado, mas não encontrado no banco
        $mensagem = "Erro: Seu perfil não foi encontrado. Por favor, faça login novamente.";
        $tipo_mensagem = 'erro';
        // Pode ser um caso de destruir a sessão e redirecionar
        // session_destroy(); header("Location: login.php"); exit;
    }
    $stmt_busca->close();
} else {
    $mensagem = "Erro interno ao preparar a busca de dados: " . $conexao->error;
    $tipo_mensagem = 'erro';
}

// =======================================================
// 3. PROCESSAMENTO DO FORMULÁRIO (ATUALIZAÇÃO)
// =======================================================
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // 3.1. Sanitização e Validação básica (Você pode adicionar validações mais robustas aqui)
    $novo_nome = trim($_POST['nome'] ?? '');
    $novo_email = trim($_POST['email'] ?? '');
    $novo_telefone = trim($_POST['telefone'] ?? '');
    $novo_endereco = trim($_POST['endereco'] ?? '');

    // Adicione uma validação de e-mail mais rigorosa, se necessário
    if (!filter_var($novo_email, FILTER_VALIDATE_EMAIL)) {
        $mensagem = "O e-mail fornecido é inválido.";
        $tipo_mensagem = 'erro';
    }
    // Validação de Nome
    else if (empty($novo_nome) || strlen($novo_nome) < 3) {
        $mensagem = "O nome precisa ter pelo menos 3 caracteres.";
        $tipo_mensagem = 'erro';
    }
    // ... adicione mais validações aqui (telefone, endereço)

    // Se a validação inicial passar, procede com a atualização
    if ($tipo_mensagem != 'erro') {

        // 3.2. Consulta de Atualização (UPDATE)
        $sql_update = "UPDATE usuarios SET nome = ?, email = ?, telefone = ?, endereco = ? WHERE id = ?";
        $stmt_update = $conexao->prepare($sql_update);

        if ($stmt_update) {
            $stmt_update->bind_param("ssssi", $novo_nome, $novo_email, $novo_telefone, $novo_endereco, $usuario_id);

            if ($stmt_update->execute()) {
                $mensagem = "Seu perfil foi atualizado com sucesso!";
                $tipo_mensagem = 'sucesso';

                // CRUCIAL: Atualiza os dados na variável $dados_usuario para o formulário
                // exibir os dados recém-salvos
                $dados_usuario['nome'] = $novo_nome;
                $dados_usuario['email'] = $novo_email;
                $dados_usuario['telefone'] = $novo_telefone;
                $dados_usuario['endereco'] = $novo_endereco;

                // Atualiza também a sessão para o nome no header
                $_SESSION['nome_usuario'] = $novo_nome;

            } else {
                $mensagem = "Erro ao atualizar o perfil: " . $stmt_update->error;
                $tipo_mensagem = 'erro';
            }
            $stmt_update->close();
        } else {
            $mensagem = "Erro interno ao preparar a atualização: " . $conexao->error;
            $tipo_mensagem = 'erro';
        }
    }

    // Se houve erro na validação, os dados originais $dados_usuario continuam a ser usados,
    // mas os campos do formulário devem mostrar os dados que o usuário tentou enviar ($novo_nome, etc.)
    // para que ele não perca o que digitou.
    // Para simplificar, vamos reatribuir os valores POST ao array $dados_usuario para que eles
    // sejam exibidos nos campos 'value'.
    $dados_usuario['nome'] = $novo_nome;
    $dados_usuario['email'] = $novo_email;
    $dados_usuario['telefone'] = $novo_telefone;
    $dados_usuario['endereco'] = $novo_endereco;
}

// Variáveis para preencher os campos com os dados atuais (ou os dados do POST se houver erro)
$nome_display = htmlspecialchars($dados_usuario['nome'] ?? '');
$email_display = htmlspecialchars($dados_usuario['email'] ?? '');
$telefone_display = htmlspecialchars($dados_usuario['telefone'] ?? '');
$endereco_display = htmlspecialchars($dados_usuario['endereco'] ?? '');
// O CPF não é editável, então buscamos a versão do banco para exibição
$cpf_display = htmlspecialchars($dados_usuario['cpf'] ?? '');

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Perfil | Street Style</title>

    <link rel="stylesheet" href="_ADM/css/header-footer.css">
    <link rel="stylesheet" href="_ADM/css/produto.css">
    <link rel="stylesheet" href="_ADM/css/perfil.css">
    <link rel="stylesheet" href="_ADM/css/form_geral.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
</head>

<body>

    <?php require_once 'header.php'; ?>

    <section class="perfil-section">
        <div class="perfil-card editar-card">

            <div class="perfil-header">
                <i class='bx bxs-edit-alt'></i>
                <h2>Editar Meus Dados</h2>
            </div>

            <?php if (!empty($mensagem)): ?>
                <div class="mensagem-feedback <?php echo $tipo_mensagem; ?>">
                    <?php echo $mensagem; ?>
                </div>
            <?php endif; ?>

            <form action="editar_perfil.php" method="POST" class="form-perfil">

                <div class="form-group">
                    <label for="nome"><i class='bx bxs-user'></i> Nome Completo</label>
                    <input type="text" id="nome" name="nome" value="<?php echo $nome_display; ?>" required>
                </div>

                <div class="form-group">
                    <label for="email"><i class='bx bxs-envelope'></i> E-mail</label>
                    <input type="email" id="email" name="email" value="<?php echo $email_display; ?>" required>
                </div>

                <div class="form-group">
                    <label for="cpf"><i class='bx bxs-id-card'></i> CPF (Não Editável)</label>
                    <input type="text" id="cpf" name="cpf"
                        value="<?php echo substr($cpf_display, 0, 3) . '********' . substr($cpf_display, -2); ?>"
                        disabled>
                </div>

                <div class="form-group">
                    <label for="telefone"><i class='bx bxs-phone'></i> Telefone</label>
                    <input type="text" id="telefone" name="telefone" value="<?php echo $telefone_display; ?>">
                </div>

                <div class="form-group">
                    <label for="endereco"><i class='bx bxs-home'></i> Endereço Principal</label>
                    <input type="text" id="endereco" name="endereco" value="<?php echo $endereco_display; ?>">
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn-submit"><i class='bx bxs-save'></i> Salvar Alterações</button>
                    <a href="perfil.php" class="btn-cancelar"><i class='bx bx-arrow-back'></i> Voltar ao Perfil</a>
                </div>

                <hr>

                <div class="form-senha">
                    <p>Deseja alterar sua senha?</p>
                    <a href="alterar_senha.php" class="btn-perfil editar-senha-btn">
                        <i class='bx bxs-lock-alt'></i> Alterar Senha
                    </a>
                </div>
            </form>

        </div>
    </section>

    <?php require_once 'footer.php'; ?>

</body>

</html>
<?php
// Fechamento da conexão
if (isset($conexao)) {
    $conexao->close();
}
?>