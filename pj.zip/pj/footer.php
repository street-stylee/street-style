  <section class="contato">
        <div class="contato-info">
            <div class="primeiro-info">
                <img src="_ADM/img/logotipo2.png" alt="">
                <p>ETEC Jornalista Roberto Marinho, <br> São Paulo - SP</p>
                <p>tccterceiroinfo@gmail.com</p>

                <div class="social-icon">
                    <a href="https://www.facebook.com/profile.php?id=61554518331187"><i class='bx bxl-facebook'></i></a>
                    <a href="https://twitter.com/home"><i class="fa-brands fa-x-twitter"></i></a>
                    <a href="https://www.instagram.com/streetstyle.ufc/"><i class='bx bxl-instagram'></i></a>
                    <a href="https://www.youtube.com/"><i class='bx bxl-youtube'></i></a>
                </div>
            </div>

            <div class="segundo-info">
                <h4>Suporte</h4>
                <p>Contato</p>
                <p>Sobre nós</p>
                <p>Políticas de privacidade</p>
                <p>Politicas de devolução e trocas</p>
                <p>Entrega e Prazos</p>
            </div>

            <div class="terceiro-info">
                <h4>Junte-se conosco</h4>
                <p>Venda na Street Style</p>
                <p>Anuncie sua empresa</p>
                <p>Publique suas roupas</p>
                <p>Seja um associado</p>
                <p>Anuncie seus produtos</p>
            </div>

            <div class="quarto-info">
                <h4>Pagamento</h4>
                <p>Meios de <br>Pagamento</p>
                <p>Compre com <br>Pontos</p>
                <p>Cartão de Crédito</p>
            </div>

            <div class="cinco">
                <h4>Deixe-nos ajudar você</h4>
                <p>Sua conta</p>
                <p>Frete e prazo de entrega</p>
                <p>Devoluções e reembolsos</p>
                <p>Gerencie seu conteúdo e <br>dispositivos</p>
                <p>Ajuda</p>
            </div>
        </div>
    </section>

    <div class="texto-final">
        <p>Street Style © 2025. Todos os direitos reservados.</p>
    </div>
