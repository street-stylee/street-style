<?php
require_once 'formu.php';
@session_start();
// Bloco de login (deixei descomentado, mas sem forçar o redirecionamento por enquanto)
// if((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) ==true))
// {
//     unset($_SESSION['email']);
//     unset($_SESSION['senha']);
//     header('Location: login.php');
// }

// 1. Definição das variáveis de sessão (melhor prática)
$usuario_logado = isset($_SESSION['usuario_id']);
$primeiro_nome = $usuario_logado ? htmlspecialchars(explode(' ', $_SESSION['usuario_nome'] ?? 'Usuário')[0]) : '';
// $logado = $_SESSION['email'] ?? ''; // Mantido como referência, mas usando $usuario_logado

$sql = "SELECT id, nome, preco, imagem_url FROM produtos ORDER BY nome";
$resultado = $conexao->query($sql);

// --- 1. Verificação de Segurança e Carrinho ---
// Se o usuário não estiver logado, redireciona para o login
if (!isset($_SESSION['usuario_id'])) {
    $_SESSION['redirect_after_login'] = 'checkout.php';
    header('Location: login.php');
    exit;
}

// Se o carrinho estiver vazio, redireciona para o carrinho
if (empty($_SESSION['carrinho'])) {
    header('Location: carrinho.php');
    exit;
}

// --- 2. Preparação de Dados ---
 // Inclui a conexão (se precisar de dados do usuário/frete)

$total_produtos = 0;
$itens_carrinho = $_SESSION['carrinho'];

foreach ($itens_carrinho as $item) {
    $total_produtos += $item['preco'] * $item['quantidade'];
}

// Valores fixos de exemplo. Em um sistema real, o frete seria calculado aqui.
$valor_frete = 25.00;
$valor_desconto = 0.00;

$total_geral = $total_produtos + $valor_frete - $valor_desconto;

// Fechamento da conexão
if (isset($conexao) && $conexao->ping()) {
    $conexao->close();
}

// --- 3. Processamento do Formulário (Exemplo Básico) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // A lógica real de processamento de pagamento, validação de endereço, 
    // inserção na tabela de pedidos e limpeza do carrinho viria AQUI.
    
    // Simulação de Sucesso:
    // unset($_SESSION['carrinho']); // Limpar o carrinho após sucesso
    // header('Location: pedido_concluido.php?id=123');
    // exit;
    
    // Por enquanto, apenas exibe uma mensagem de sucesso (simulada)
    $mensagem_status = "O pedido foi processado com sucesso (simulação).";
}

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finalizar Pedido - Street Style</title>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">

    <link rel="stylesheet" href="_ADM/css/estilo_pg_produto.css">    
    <link rel="stylesheet" href="_ADM/css/header-footer.css">    
    <link rel="stylesheet" href="_ADM/css/estilo_checkout.css">
</head>

<body>

   <?php require_once 'header.php' ?>

    <div class="checkout-container">
        <h1>Finalizar Pedido</h1>

        
        <?php if (isset($mensagem_status)): ?>
            <div style="background-color: #e6ffe6; color: #008000; padding: 15px; border-radius: 5px; margin-bottom: 20px; text-align: center;">
                <?php echo $mensagem_status; ?>
            </div>
        <?php endif; ?>

        <form action="checkout.php" method="POST" class="checkout-content">
            
            <div class="checkout-main">
                
                <div class="checkout-section endereco-section">
                    <h3 class="section-title"><i class="fa-solid fa-map-location-dot"></i> Endereço de Entrega</h3>
                    
                    <div class="form-row">
                        <div class="form-group" style="flex: 2;">
                            <label for="cep">CEP</label>
                            <input type="text" id="cep" name="cep" required placeholder="00000-000">
                        </div>
                        <div class="form-group" style="flex: 1;">
                            <label for="cidade">Cidade</label>
                            <input type="text" id="cidade" name="cidade" required readonly value="São Paulo">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="logradouro">Rua/Avenida</label>
                        <input type="text" id="logradouro" name="logradouro" required placeholder="Ex: Rua das Flores">
                    </div>

                    <div class="form-row">
                        <div class="form-group" style="flex: 1;">
                            <label for="numero">Número</label>
                            <input type="number" id="numero" name="numero" required>
                        </div>
                        <div class="form-group" style="flex: 2;">
                            <label for="complemento">Complemento (Opcional)</label>
                            <input type="text" id="complemento" name="complemento" placeholder="Apto, Bloco, etc.">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="bairro">Bairro</label>
                        <input type="text" id="bairro" name="bairro" required>
                    </div>

                    <div style="padding: 10px 0; border-top: 1px solid #eee; margin-top: 15px;">
                         <p style="margin: 0; font-weight: 600;">Frete: Entrega Padrão (5-7 dias) - R$ <?php echo number_format($valor_frete, 2, ',', '.'); ?></p>
                    </div>

                </div>
                
                <div class="checkout-section pagamento-section">
                    <h3 class="section-title"><i class="fa-solid fa-credit-card"></i> Método de Pagamento</h3>
                    
                    <div class="payment-methods">
                        
                        <div class="payment-method-item selected">
                            <label>
                                <input type="radio" name="metodo_pagamento" value="pix" checked>
                                PIX
                            </label>
                            <div class="card-details">
                                Pague instantaneamente com PIX. Chave gerada na próxima tela.
                            </div>
                        </div>

                        <div class="payment-method-item">
                            <label>
                                <input type="radio" name="metodo_pagamento" value="cartao">
                                Cartão de Crédito
                            </label>
                            <div class="card-details" style="display: none;">
                                <div class="form-group">
                                    <label for="num_cartao">Número do Cartão</label>
                                    <input type="text" id="num_cartao" placeholder="0000 0000 0000 0000">
                                </div>
                                <div class="form-row">
                                     <div class="form-group">
                                        <label for="validade">Validade</label>
                                        <input type="text" id="validade" placeholder="MM/AA">
                                    </div>
                                    <div class="form-group">
                                        <label for="cvv">CVV</label>
                                        <input type="text" id="cvv" placeholder="123">
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
            
            <div class="checkout-sidebar">
                <h3 class="section-title" style="margin-top: 0;"><i class="fa-solid fa-receipt"></i> Seu Pedido</h3>

                <?php foreach ($itens_carrinho as $item): ?>
                    <div class="resumo-item">
                        <div class="resumo-img">
                            <img src="<?php echo htmlspecialchars($item['imagem']); ?>" alt="<?php echo htmlspecialchars($item['nome']); ?>">
                        </div>
                        <div class="resumo-info">
                            <span class="item-nome"><?php echo htmlspecialchars($item['nome']); ?></span>
                            <p><?php echo htmlspecialchars($item['quantidade']); ?>x (T: <?php echo htmlspecialchars($item['tamanho']); ?>)</p>
                            <p>R$ <?php echo number_format($item['preco'] * $item['quantidade'], 2, ',', '.'); ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>

                <div class="resumo-valores">
                    <div class="valor-row">
                        <span>Subtotal de Produtos</span>
                        <span>R$ <?php echo number_format($total_produtos, 2, ',', '.'); ?></span>
                    </div>
                    <div class="valor-row">
                        <span>Frete</span>
                        <span>R$ <?php echo number_format($valor_frete, 2, ',', '.'); ?></span>
                    </div>
                    <?php if ($valor_desconto > 0): ?>
                    <div class="valor-row" style="color: var(--cor-alerta);">
                        <span>Desconto</span>
                        <span>- R$ <?php echo number_format($valor_desconto, 2, ',', '.'); ?></span>
                    </div>
                    <?php endif; ?>
                    <div class="valor-row total-final">
                        <span>TOTAL A PAGAR</span>
                        <span>R$ <?php echo number_format($total_geral, 2, ',', '.'); ?></span>
                    </div>
                </div>

                <button type="submit" class="btn-concluir-compra" name="concluir_pedido">
                    <i class="fa-solid fa-check-circle"></i> CONCLUIR COMPRA
                </button>
                
            </div>
            
        </form>
    </div>
    <?php require_once 'footer.php' ?>

    <script>
        // Função para mostrar ou esconder detalhes de pagamento
        document.querySelectorAll('.payment-method-item').forEach(item => {
            item.addEventListener('click', function() {
                // Remove a seleção de todos
                document.querySelectorAll('.payment-method-item').forEach(i => {
                    i.classList.remove('selected');
                    i.querySelector('.card-details').style.display = 'none';
                });
                
                // Adiciona a seleção ao clicado
                this.classList.add('selected');
                
                // Exibe os detalhes se for cartão (ou outro método complexo)
                const radio = this.querySelector('input[type="radio"]');
                if (radio.value === 'cartao') {
                    this.querySelector('.card-details').style.display = 'block';
                }
                radio.checked = true; // Garante que o radio button está marcado
            });
        });
        
        // JAVASCRIPT PARA SCROLL DO HEADER
        window.onscroll = function () { scrollFunction(); };

        function scrollFunction() {
            var header = document.querySelector('header');
            if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
                header.classList.add('scrolled');
            } else {
                if (header.classList.contains('scrolled')) {
                    header.classList.remove('scrolled');
                }
            }
        }
    </script>
</body>
</html>