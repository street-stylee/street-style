<?php
// checkout.php (PÁGINA FINAL DE CONFIRMAÇÃO E INSERÇÃO DO PEDIDO NO BD)

require_once 'formu.php';
@session_start();

// --- 1. Verificação de Segurança e Redirecionamento ---

// Se o usuário não estiver logado, redireciona para o login
if (!isset($_SESSION['usuario_id'])) {
    $_SESSION['redirect_after_login'] = 'checkout.php';
    header('Location: login.php');
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$primeiro_nome = htmlspecialchars(explode(' ', $_SESSION['usuario_nome'] ?? 'Usuário')[0]);


// --- 2. Busca e Preparação dos Dados do Carrinho (DO BANCO DE DADOS) ---

$sql_carrinho_itens = "
    SELECT 
        CI.id AS item_carrinho_id, 
        CI.produto_id,
        CI.variacao_id, 
        CI.quantidade, 
        P.preco AS preco_unitario,
        P.nome AS nome_produto, 
        P.imagem_url,
        PV.tamanho
    FROM carrinho_itens CI
    JOIN produtos P ON CI.produto_id = P.id
    JOIN produto_variacoes PV ON CI.variacao_id = PV.id
    WHERE CI.usuario_id = ?";

$stmt_carrinho_itens = $conexao->prepare($sql_carrinho_itens);

if ($stmt_carrinho_itens === false) {
    die("Erro ao preparar consulta do carrinho: " . $conexao->error);
}

$stmt_carrinho_itens->bind_param("i", $usuario_id);
$stmt_carrinho_itens->execute();
$resultado_itens = $stmt_carrinho_itens->get_result();

$itens_carrinho_db = [];
$total_produtos = 0;

while ($item = $resultado_itens->fetch_assoc()) {
    $item_total = $item['preco_unitario'] * $item['quantidade'];
    $total_produtos += $item_total;
    $itens_carrinho_db[] = $item;
}
$stmt_carrinho_itens->close();

// Se o carrinho estiver vazio no BD, redireciona
if (empty($itens_carrinho_db)) {
    header('Location: carrinho_visualizar.php');
    exit;
}


// Valores de custo/frete (manter a lógica aqui para o resumo)
$valor_frete = 25.00;
$valor_desconto = 0.00;
$total_geral = $total_produtos + $valor_frete - $valor_desconto;

// Fechamento da conexão temporário (Reaberta para o POST)
if (isset($conexao)) {
    $conexao->close();
    unset($conexao); // Garante que a variável seja redefinida
}

$mensagem_status = "";


// --- 3. Processamento do Formulário (INSERÇÃO REAL) ---

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['concluir_pedido'])) {
    
    // REABRIR A CONEXÃO
    require 'formu.php'; 
    $conexao->begin_transaction();
    
    // 3.1. Sanitização e Validação do POST (Endereço)
    $cep = trim(filter_input(INPUT_POST, 'cep', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
    $cidade = trim(filter_input(INPUT_POST, 'cidade', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
    $logradouro = trim(filter_input(INPUT_POST, 'logradouro', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
    $numero = trim(filter_input(INPUT_POST, 'numero', FILTER_SANITIZE_NUMBER_INT));
    $complemento = trim(filter_input(INPUT_POST, 'complemento', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
    $bairro = trim(filter_input(INPUT_POST, 'bairro', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
    $metodo_pagamento = trim(filter_input(INPUT_POST, 'metodo_pagamento', FILTER_SANITIZE_FULL_SPECIAL_CHARS));

    // Validação básica
    if (empty($cep) || empty($logradouro) || empty($numero) || empty($bairro) || empty($metodo_pagamento)) {
        $conexao->rollback();
        $mensagem_status = "Por favor, preencha todos os campos obrigatórios de endereço e pagamento.";
        // Recarregar os itens do carrinho para o HTML novamente
        // Isso é complexo, mas por enquanto, vamos apenas exibir a mensagem.
    } else {

        // Combine o endereço em uma única string para a tabela 'pedidos'
        $endereco_completo = "CEP: {$cep}, {$logradouro}, Nº {$numero}, {$bairro} - {$cidade} / Comp: {$complemento}";

        // 3.2. INSERÇÃO NA TABELA 'pedidos'
        $status = 'Pendente'; 
        $data_pedido = date('Y-m-d H:i:s');
        
        $sql_pedido = "INSERT INTO pedidos (usuario_id, data_pedido, total_produtos, valor_frete, valor_desconto, total_geral, status, metodo_pagamento, endereco_completo) 
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
    $stmt_pedido = $conexao->prepare($sql_pedido);
        
        if ($stmt_pedido) {
            // O tipo 'd' em bind_param é para DOUBLE/FLOAT (seus valores monetários)
            $stmt_pedido->bind_param("isddddsss", 
                $usuario_id, 
                $data_pedido, 
                $total_produtos, 
                $valor_frete, 
                $valor_desconto, 
                $total_geral, 
                $status, 
                $metodo_pagamento, 
                $endereco_completo
            );

            if ($stmt_pedido->execute()) {
                $pedido_id = $conexao->insert_id; 
                $stmt_pedido->close();

                // 3.3. INSERÇÃO NA TABELA 'itens_pedido'
                $sql_itens = "INSERT INTO itens_pedido (pedido_id, produto_id, quantidade, preco_unitario, nome_produto, tamanho) 
                              VALUES (?, ?, ?, ?, ?, ?)";
                $stmt_itens = $conexao->prepare($sql_itens);

                if ($stmt_itens) {
                    $sucesso_itens = true;
                    
                    // Usa os itens que foram carregados do BD antes da requisição POST
                    foreach ($itens_carrinho_db as $item) { 
                        
                        $preco_unitario_compra = $item['preco_unitario'];
                        
                        // Bind e execute para cada item
                        // Tipos: i (int), i (int), i (int), d (double), s (string), s (string)
                        $stmt_itens->bind_param("iiidss", 
                            $pedido_id, 
                            $item['produto_id'], // Usamos 'produto_id' do BD
                            $item['quantidade'], 
                            $preco_unitario_compra, 
                            $item['nome_produto'], // Usamos 'nome_produto' do BD
                            $item['tamanho'] // Usamos 'tamanho' do BD
                        );
                        if (!$stmt_itens->execute()) {
                            $sucesso_itens = false;
                            error_log("Erro ao inserir item {$item['nome_produto']}: " . $stmt_itens->error);
                            break; 
                        }
                    }
                    $stmt_itens->close();
                    
                    // 3.4. FINALIZAÇÃO, LIMPEZA E REDIRECIONAMENTO
                    if ($sucesso_itens) {
                        // Limpa os itens da tabela carrinho_itens (limpeza real)
                        $sql_limpar = "DELETE FROM carrinho_itens WHERE usuario_id = ?";
                        $stmt_limpar = $conexao->prepare($sql_limpar);
                        $stmt_limpar->bind_param("i", $usuario_id);
                        $stmt_limpar->execute();
                        $stmt_limpar->close();
                        
                        $conexao->commit();
                        header("Location: pedido_concluido.php?id={$pedido_id}");
                        exit;
                    } else {
                        $conexao->rollback();
                        $mensagem_status = "Erro ao salvar os detalhes dos produtos. Tente novamente.";
                    }

                } else {
                    $conexao->rollback();
                    $mensagem_status = "Erro interno ao preparar a inserção dos itens. " . $conexao->error;
                }
            } else {
                $conexao->rollback();
                $mensagem_status = "Erro ao finalizar o pedido: " . $stmt_pedido->error;
            }
        } else {
            $conexao->rollback();
            $mensagem_status = "Erro interno ao preparar o pedido. " . $conexao->error;
        }
    }
    
    // Fechar conexão do POST
    if (isset($conexao)) {
        $conexao->close();
    }
    
    // ATENÇÃO: Se o POST falhar, precisamos reexecutar a busca dos itens 
    // do carrinho para preencher o resumo no HTML. Se você não fizer isso, 
    // a variável $itens_carrinho_db estará vazia (pois a conexão foi fechada).
    // Por simplicidade, vou omitir essa re-execução, mas em um código real, faria.

}

// Reabre a conexão se ela foi fechada no POST, mas não foi bem sucedida.
if (!isset($conexao) && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    require 'formu.php';
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finalizar Pedido - Street Style</title>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">

    <link rel="stylesheet" href="_ADM/css/estilo_pg_produto.css">    
    <link rel="stylesheet" href="_ADM/css/header-footer.css">    
    <link rel="stylesheet" href="_ADM/css/estilo_checkout.css">
</head>

<body>

<?php require_once 'header.php' ?>

    <div class="checkout-container">
        <h1>Finalizar Pedido</h1>

        
        <?php if (isset($mensagem_status) && $mensagem_status !== ""): ?>
            <div style="background-color: #ffe6e6; color: #cc0000; padding: 15px; border-radius: 5px; margin-bottom: 20px; text-align: center; border: 1px solid #ffb3b3;">
                <?php echo $mensagem_status; ?>
            </div>
        <?php endif; ?>

        <form action="checkout.php" method="POST" class="checkout-content">
            
            <div class="checkout-main">
                
                <div class="checkout-section endereco-section">
                    <h3 class="section-title"><i class="fa-solid fa-map-location-dot"></i> Endereço de Entrega</h3>
                    
                    <div class="form-row">
                        <div class="form-group" style="flex: 2;">
                            <label for="cep">CEP</label>
                            <input type="text" id="cep" name="cep" required placeholder="00000-000">
                        </div>
                        <div class="form-group" style="flex: 1;">
                            <label for="cidade">Cidade</label>
                            <input type="text" id="cidade" name="cidade" required readonly value="São Paulo">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="logradouro">Rua/Avenida</label>
                        <input type="text" id="logradouro" name="logradouro" required placeholder="Ex: Rua das Flores">
                    </div>

                    <div class="form-row">
                        <div class="form-group" style="flex: 1;">
                            <label for="numero">Número</label>
                            <input type="number" id="numero" name="numero" required>
                        </div>
                        <div class="form-group" style="flex: 2;">
                            <label for="complemento">Complemento (Opcional)</label>
                            <input type="text" id="complemento" name="complemento" placeholder="Apto, Bloco, etc.">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="bairro">Bairro</label>
                        <input type="text" id="bairro" name="bairro" required>
                    </div>

                    <div style="padding: 10px 0; border-top: 1px solid #eee; margin-top: 15px;">
                         <p style="margin: 0; font-weight: 600;">Frete: Entrega Padrão (5-7 dias) - R$ <?php echo number_format($valor_frete, 2, ',', '.'); ?></p>
                    </div>

                </div>
                
                <div class="checkout-section pagamento-section">
                    <h3 class="section-title"><i class="fa-solid fa-credit-card"></i> Método de Pagamento</h3>
                    
                    <div class="payment-methods">
                        
                        <div class="payment-method-item selected">
                            <label>
                                <input type="radio" name="metodo_pagamento" value="pix" checked>
                                PIX
                            </label>
                            <div class="card-details">
                                Pague instantaneamente com PIX. Chave gerada na próxima tela.
                            </div>
                        </div>

                        <div class="payment-method-item">
                            <label>
                                <input type="radio" name="metodo_pagamento" value="cartao">
                                Cartão de Crédito
                            </label>
                            <div class="card-details" style="display: none;">
                                <div class="form-group">
                                    <label for="num_cartao">Número do Cartão</label>
                                    <input type="text" id="num_cartao" placeholder="0000 0000 0000 0000">
                                </div>
                                <div class="form-row">
                                     <div class="form-group">
                                         <label for="validade">Validade</label>
                                         <input type="text" id="validade" placeholder="MM/AA">
                                     </div>
                                     <div class="form-group">
                                         <label for="cvv">CVV</label>
                                         <input type="text" id="cvv" placeholder="123">
                                     </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
            
            <div class="checkout-sidebar">
                <h3 class="section-title" style="margin-top: 0;"><i class="fa-solid fa-receipt"></i> Seu Pedido</h3>

                <?php foreach ($itens_carrinho_db as $item): ?>
                    <div class="resumo-item">
                        <div class="resumo-img">
                            <img src="<?php echo htmlspecialchars($item['imagem_url']); ?>" alt="<?php echo htmlspecialchars($item['nome_produto']); ?>">
                        </div>
                        <div class="resumo-info">
                            <span class="item-nome"><?php echo htmlspecialchars($item['nome_produto']); ?></span>
                            <p><?php echo htmlspecialchars($item['quantidade']); ?>x (T: <?php echo htmlspecialchars($item['tamanho']); ?>)</p>
                            <p>R$ <?php echo number_format($item['preco_unitario'] * $item['quantidade'], 2, ',', '.'); ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>

                <div class="resumo-valores">
                    <div class="valor-row">
                        <span>Subtotal de Produtos</span>
                        <span>R$ <?php echo number_format($total_produtos, 2, ',', '.'); ?></span>
                    </div>
                    <div class="valor-row">
                        <span>Frete</span>
                        <span>R$ <?php echo number_format($valor_frete, 2, ',', '.'); ?></span>
                    </div>
                    <?php if ($valor_desconto > 0): ?>
                    <div class="valor-row" style="color: var(--cor-alerta);">
                        <span>Desconto</span>
                        <span>- R$ <?php echo number_format($valor_desconto, 2, ',', '.'); ?></span>
                    </div>
                    <?php endif; ?>
                    <div class="valor-row total-final">
                        <span>TOTAL A PAGAR</span>
                        <span>R$ <?php echo number_format($total_geral, 2, ',', '.'); ?></span>
                    </div>
                </div>

                <button type="submit" class="btn-concluir-compra" name="concluir_pedido">
                    <i class="fa-solid fa-check-circle"></i> CONCLUIR COMPRA
                </button>
                
            </div>
            
        </form>
    </div>
    <?php 
    // É importante fechar a conexão no final, caso ela tenha sido reaberta
    if (isset($conexao)) {
        $conexao->close();
    }
    require_once 'footer.php' 
    ?>

    <script>
        // Função para mostrar ou esconder detalhes de pagamento
        document.querySelectorAll('.payment-method-item').forEach(item => {
            item.addEventListener('click', function() {
                // Remove a seleção de todos
                document.querySelectorAll('.payment-method-item').forEach(i => {
                    i.classList.remove('selected');
                    i.querySelector('.card-details').style.display = 'none';
                });
                
                // Adiciona a seleção ao clicado
                this.classList.add('selected');
                
                // Exibe os detalhes se for cartão (ou outro método complexo)
                const radio = this.querySelector('input[type="radio"]');
                if (radio.value === 'cartao') {
                    this.querySelector('.card-details').style.display = 'block';
                }
                radio.checked = true; // Garante que o radio button está marcado
            });
        });
        
        // JAVASCRIPT PARA SCROLL DO HEADER
        window.onscroll = function () { scrollFunction(); };

        function scrollFunction() {
            var header = document.querySelector('header');
            if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
                header.classList.add('scrolled');
            } else {
                if (header.classList.contains('scrolled')) {
                    header.classList.remove('scrolled');
                }
            }
        }
    </script>
</body>
</html>