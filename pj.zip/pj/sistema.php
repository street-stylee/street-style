<?php 
    session_start();
    if((!isset($_SESSION['emaiil']) == true) and (!isset($_SESSION['senha']) ==true))
    {
        unset($_SESSION['email']);
        unset($_SESSION['senha']);
        header('Location: login.php');
    
    }
    $logado = $_SESSION['email'];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema</title>
</head>
<body>
    <h1>Acessou o sistema</h1>

    <a href="sair.php">Sair</a>
    <?php 
    echo ' Bem vindo'.$logado;
    ?>
</body>
</html> 