<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre nós</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&display=swap"
        rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">

    <link rel="shortcut icon" href="_ADM/favicon.ico/favicon.ico" type="image/x-icon">
    <link rel="icon" href="_ADM/favicon.ico/favicon.ico" type="image/x-icon">
    <link rel="icon" type="image/png" sizes="32x32" href="_ADM/favicon.ico/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="32x32" href="_ADM/favicon.ico/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="_ADM/favicon.ico/favicon-16x16.png">
    <link rel="stylesheet" href="_ADM/css/stylesobre.css">
    <link rel="stylesheet" href="_ADM/css/sobreCard.css">
    <link rel="stylesheet" href="_ADM/css/header-footer.css">
    <link rel="stylesheet" href="_ADM/css/footer.css">

</head>

<body>
    <?php require_once 'header.php' ?>



    <div class="heading">
        <h1>Sobre nós</h1>
        <p> A StreetStyle está ai para mudar a sua visão de moda!</p>
    </div>


    </div>

    <!-- Cards Personalizados -->

    <section class="pai">
        <div class="floating-shapes">
            <div class="shape"></div>
            <div class="shape"></div>
            <div class="shape"></div>
            <div class="shape"></div>
        </div>

        <div class="profile-card">
            <div class="image-wrapper">
                <div class="profile-image-container">
                    <img src="https://i.ibb.co/h7gBf33/daniel-soares.png" alt="Erick Altava" class="profile-image">
                </div>
                <div class="orbit-dot"></div>
                <div class="orbit-dot"></div>
            </div>

            <h1 class="profile-name">Erick Altava</h1>

            <div class="profile-title">
                <strong>Full-Stack Developer</strong>
                Inovador em Node & React<br>
                Construtor de experiências digitais de alta performance
            </div>

            <div class="social-icons">
                <a href="#" class="social-link" title="LinkedIn">
                    <i class="fab fa-linkedin-in"></i>
                </a>
                <a href="#" class="social-link" title="GitHub">
                    <i class="fab fa-github"></i>
                </a>
                <a href="#" class="social-link" title="Twitter">
                    <i class="fab fa-x-twitter"></i>
                </a>
                <a href="#" class="social-link" title="Instagram">
                    <i class="fab fa-instagram"></i>
                </a>
            </div>
        </div>

        <div class="profile-card">
            <div class="image-wrapper">
                <div class="profile-image-container">
                    <img src="https://i.ibb.co/h7gBf33/daniel-soares.png" alt="Bernardo Almeida" class="profile-image">
                </div>
                <div class="orbit-dot"></div>
                <div class="orbit-dot"></div>
            </div>

            <h1 class="profile-name">Bernardo Almeida</h1>

            <div class="profile-title">
                <strong>Full-Stack Developer</strong>
                Inovador em Node & React<br>
                Construtor de experiências digitais de alta performance
            </div>

            <div class="social-icons">
                <a href="#" class="social-link" title="LinkedIn">
                    <i class="fab fa-linkedin-in"></i>
                </a>
                <a href="#" class="social-link" title="GitHub">
                    <i class="fab fa-github"></i>
                </a>
                <a href="#" class="social-link" title="Twitter">
                    <i class="fab fa-x-twitter"></i>
                </a>
                <a href="#" class="social-link" title="Instagram">
                    <i class="fab fa-instagram"></i>
                </a>
            </div>
        </div>

        <div class="profile-card">
            <div class="image-wrapper">
                <div class="profile-image-container">
                    <img src="https://i.ibb.co/h7gBf33/daniel-soares.png" alt="Nickolas Miranda" class="profile-image">
                </div>
                <div class="orbit-dot"></div>
                <div class="orbit-dot"></div>
            </div>

            <h1 class="profile-name">Nickolas Miranda</h1>

            <div class="profile-title">
                <strong>Full-Stack Developer</strong>
                Inovador em Node & React<br>
                Construtor de experiências digitais de alta performance
            </div>

            <div class="social-icons">
                <a href="#" class="social-link" title="LinkedIn">
                    <i class="fab fa-linkedin-in"></i>
                </a>
                <a href="#" class="social-link" title="GitHub">
                    <i class="fab fa-github"></i>
                </a>
                <a href="#" class="social-link" title="Twitter">
                    <i class="fab fa-x-twitter"></i>
                </a>
                <a href="#" class="social-link" title="Instagram">
                    <i class="fab fa-instagram"></i>
                </a>
            </div>
        </div>

        <div class="profile-card">
            <div class="image-wrapper">
                <div class="profile-image-container">
                    <img src="https://i.ibb.co/h7gBf33/daniel-soares.png" alt="Cauã Bitencourt" class="profile-image">
                </div>
                <div class="orbit-dot"></div>
                <div class="orbit-dot"></div>
            </div>

            <h1 class="profile-name">Cauã Bitencourt</h1>

            <div class="profile-title">
                <strong>Full-Stack Developer</strong>
                Inovador em Node & React<br>
                Construtor de experiências digitais de alta performance
            </div>

            <div class="social-icons">
                <a href="#" class="social-link" title="LinkedIn">
                    <i class="fab fa-linkedin-in"></i>
                </a>
                <a href="#" class="social-link" title="GitHub">
                    <i class="fab fa-github"></i>
                </a>
                <a href="#" class="social-link" title="Twitter">
                    <i class="fab fa-x-twitter"></i>
                </a>
                <a href="#" class="social-link" title="Instagram">
                    <i class="fab fa-instagram"></i>
                </a>
            </div>
        </div>

        <div class="profile-card">
            <div class="image-wrapper">
                <div class="profile-image-container">
                    <img src="https://i.ibb.co/h7gBf33/daniel-soares.png" alt="Arthur Beserra" class="profile-image">
                </div>
                <div class="orbit-dot"></div>
                <div class="orbit-dot"></div>
            </div>

            <h1 class="profile-name">Arthur Beserra</h1>

            <div class="profile-title">
                <strong>Full-Stack Developer</strong>
                Inovador em Node & React<br>
                Construtor de experiências digitais de alta performance
            </div>

            <div class="social-icons">
                <a href="#" class="social-link" title="LinkedIn">
                    <i class="fab fa-linkedin-in"></i>
                </a>
                <a href="#" class="social-link" title="GitHub">
                    <i class="fab fa-github"></i>
                </a>
                <a href="#" class="social-link" title="Twitter">
                    <i class="fab fa-x-twitter"></i>
                </a>
                <a href="#" class="social-link" title="Instagram">
                    <i class="fab fa-instagram"></i>
                </a>
            </div>
        </div>
    </section>

    <!--  -->


    <!-- final -->
    <?php require_once 'footer.php' ?>

    <script src="java.js"></script>
</body>

</html>