<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre nós</title>
    <link rel="stylesheet" href="_ADM/css/stylesobre.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet"
    href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">

    <link rel="shortcut icon" href="_ADM/favicon.ico/favicon.ico" type="image/x-icon">
    <link rel="icon" href="_ADM/favicon.ico/favicon.ico" type="image/x-icon">
    <link rel="icon" type="image/png" sizes="32x32" href="_ADM/favicon.ico/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="32x32" href="_ADM/favicon.ico/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="_ADM/favicon.ico/favicon-16x16.png">
</head>
<body>
    <header>
        <a href="index.php" class="logo"><img src="_ADM/img_index/logotipo.png" alt=""></a>

        <ul class="navmenu">
            <li><a href="index.php">home</a></li>
            <li><a href="produtos.php">produtos</a></li>
            <li><a href="#">sobre</a></li>
            <li><a href="contato.php">contato</a></li>

        </ul>

        <div class="nav-icon">
            <a href="busca/index.php"><i class='bx bx-search'></i></a>
            <a href="#"><i class='bx bx-user' ></i></a>
            <a href="carrinho.php"><i class='bx bx-cart' ></i></a>
        </div>
    </header><br><br><br>
    <div class="heading">
        <h1>Sobre nós</h1>
        <p>  A StreetStyle está ai para mudar a sua visão de moda!</p>
    </div>
    <div class="container">
        <section class="sobre">
            <div class="imagem">
                <img src="_ADM/img/STREET_20231204_215406_0000.png">
            </div>
            <div class="sobrecontent">
                <h2>QUEM SOMOS NÓS???</h2>
                <p>Somos a StreetStyle e nosso objetivo é deixar você confortável e na moda para o seu dia a dia.<br>A nossa empresa é formada por cinco grandes apreciadores da moda, tendo como nossa maior referência de estilo o Cauã Bitencourt. A nossa empresa surgiu no momento em que percebemos que as lojas de estilo streetwear estavam muito fracas e repetidas, viemos para inovar e muda o seu conceito de moda de rua. Você não irá se arrepender de contar com a StreetStyle!
                </p>
                <a href="" class="botmais">Ler mais</a>

            </div>
        </section>
    </div><br><br>
    <section class="contato">
        <div class="contato-info">
            <div class="primeiro-info">
                <img src="_ADM/img_index/logotipo2.png" alt="">
                <p></p>
                <p>ETEC Jornalista Roberto Marinho, <br> São Paulo - SP</p>
                <p>tcaprimeiroinfo@gmail.com</p>

                <div class="social-icon">
                    <a href="https://www.facebook.com/profile.php?id=61554518331187"><i class='bx bxl-facebook'></i></a>
                    <a href="https://twitter.com/home"><i class="fa-brands fa-x-twitter" style="color: #000000;"></i></a>
                    <a href="https://www.instagram.com/streetstyle.ufc/"><i class='bx bxl-instagram'></i></a>
                    <a href="https://www.youtube.com/"><i class='bx bxl-youtube' ></i></a>
                </div>

            </div>

            <div class="segundo-info">
                <h4>Suporte</h4>
                <p>Contato</p>
                <p>Sobre nós</p>
                <p>Políticas de privacidade</p>
                <p>Politicas de devolução e trocas</p>
                <p>Entrega e Prazos</p>
            </div>
            
            <div class="terceiro-info">
                <h4>Junte-se conosco</h4>
                <p>Venda na Street Style</p>
                <p>Anuncie sua empresa</p>
                <p>Publique suas roupas</p>
                <p>Seja um associado</p>
                <p>Anuncie seus produtos</p>
            </div>

            <div class="quarto-info">
                <h4>Pagamento</h4>
                <p>Meios de <br>Pagamento</p>
                <p>Compre com <br>Pontos</p>
                <p>Cartão de Crédito</p>
            </div>

            <div class="cinco">
                <h4>Deixe-nos ajudar você</h4>
                <p>Sua conta</p>
                <p>Frete e prazo de entrega</p>
                <p>Devoluções e reembolsos</p>
                <p>Gerencie seu conteúdo e <br>dispositivos</p>
                <p>Ajuda</p>
            </div>
        </div>
    </section>

    <div class="texto-final">
        <p>Street Style © 2025. Todos os direitos reservados.</p>
    </div>

    <script src="java.js"></script>
</body>
</html>