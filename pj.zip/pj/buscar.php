<?php
require_once 'formu.php'; // Inclui a conexão com o banco de dados
@session_start();

// 1. Capturar o termo de busca
$termo_busca = '';
$resultados = [];
$total_resultados = 0;

if (isset($_GET['q']) && !empty(trim($_GET['q']))) {
    // Sanitiza e armazena o termo
    $termo_busca = trim(filter_input(INPUT_GET, 'q', FILTER_SANITIZE_FULL_SPECIAL_CHARS));

    // Constrói o termo de busca com wildcards (%) para buscar em qualquer parte do texto
    $param_busca = '%' . $termo_busca . '%';

    // 2. Consulta SQL Otimizada - CORRIGIDA!
    $sql = "SELECT id, nome, preco, imagem_url, descricao 
        FROM produtos 
        WHERE nome LIKE ? OR descricao LIKE ? OR SOUNDEX(nome) = SOUNDEX(?)
        ORDER BY nome ASC";

    if ($stmt = $conexao->prepare($sql)) {
        $stmt->bind_param("sss", $param_busca, $param_busca, $termo_busca);

        $stmt->execute();
        $resultado = $stmt->get_result();

        // 3. Armazena os resultados
        $total_resultados = $resultado->num_rows;
        while ($produto = $resultado->fetch_assoc()) {
            $resultados[] = $produto;
        }
        $stmt->close();
    } else {
        $erro_sql = "Erro ao preparar a consulta: " . $conexao->error;
    }
} else {
    $mensagem_inicial = "Digite algo na barra de busca para começar.";
}

// Fechamento da conexão no final do script
if (isset($conexao)) {
    // $conexao->close(); 
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultados para: <?php echo htmlspecialchars($termo_busca); ?></title>
    <link rel="stylesheet" href="_ADM/css/header-footer.css">
    <link rel="stylesheet" href="_ADM/css/buscar.css">
    <link rel="stylesheet" href="_ADM/css/footer.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
</head>

<body>
    <?php require_once 'header.php'; ?>

    <div id="main-container">
        <div id="search-info">
            <?php if (!empty($termo_busca)): ?>
                <h1>Resultados da Busca para: "<?php echo htmlspecialchars($termo_busca); ?>"</h1>
                <p>Encontramos **<?php echo $total_resultados; ?>** produtos correspondentes.</p>
            <?php else: ?>
                <h1><?php echo $mensagem_inicial ?? 'Página de Busca'; ?></h1>
            <?php endif; ?>
        </div>

        <div id="produtos-grid">
            <?php if ($total_resultados > 0): ?>
                <?php foreach ($resultados as $produto): ?>
                    <div id="produto-card"> <a href="produto.php?id=<?php echo $produto['id']; ?>">
                            <img src="<?php echo htmlspecialchars($produto['imagem_url']); ?>"
                                alt="<?php echo htmlspecialchars($produto['nome']); ?>">
                            <h3><?php echo htmlspecialchars($produto['nome']); ?></h3>
                            <p id="preco">R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></p>
                            <p id="descricao-curta">
                                <?php echo mb_strimwidth(htmlspecialchars($produto['descricao']), 0, 70, "..."); ?>
                            </p>
                        </a>
                        <button id="btn-comprar">Comprar</button>
                    </div>
                <?php endforeach; ?>
            <?php elseif (!empty($termo_busca)): ?>
                <div id="no-results">
                    <i class='bx bx-sad'></i>
                    <h2>Nenhum resultado encontrado.</h2>
                    <p>Tente refinar sua busca com palavras-chave diferentes ou verifique a ortografia.</p>
                    <a href="produtos.php" id="btn-primary">Ver todos os produtos</a>
                </div>
            <?php endif; ?>

            <?php if (isset($erro_sql)): ?>
                <p id="error-message">Houve um erro no servidor: <?php echo $erro_sql; ?></p>
            <?php endif; ?>
        </div>
    </div>

    <?php require_once 'footer.php'; ?>
</body>

</html>