<?php
require_once 'formu.php'; // Inclui a conexão e inicia a sessão

// 1. VERIFICAÇÃO DE LOGIN
// Se o usuário não estiver logado, redireciona para a página de acesso.
if (!isset($_SESSION['usuario_id'])) { 
    // Se o ID do usuário não estiver na sessão, ele não está logado
    header("Location: login.php");
    exit;
}
// O ID do usuário logado está na sessão
$usuario_id = $_SESSION['usuario_id'];
$dados_usuario = null;

// 2. BUSCA DOS DADOS DO USUÁRIO
// A coluna 'cpf' foi removida da sua consulta SQL
$sql = "SELECT nome, email, telefone, endereco FROM usuarios WHERE id = ?";
$stmt = $conexao->prepare($sql);

if ($stmt) {
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        $dados_usuario = $resultado->fetch_assoc();
    }
    $stmt->close();
}

// 3. Verifica se os dados foram encontrados (segurança extra)
if (!$dados_usuario) {
    // Caso o ID na sessão não corresponda a nenhum usuário
    session_destroy();
    header("Location: login.php?erro=usuario_nao_encontrado");
    exit;
}

// Agora você pode acessar os dados, ex: $dados_usuario['nome']

// Inclui o header HTML e a navegação
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meu Perfil | Street Style</title>
    
    <link rel="stylesheet" href="_ADM/css/header-footer.css">
    <link rel="stylesheet" href="_ADM/css/produto.css">
    <link rel="stylesheet" href="_ADM/css/perfil.css"> <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
</head>
<body>

    <?php require_once 'header.php'; ?>

    <section class="perfil-section">
        <div class="perfil-card">
            
            <div class="perfil-header">
                <i class='bx bxs-user-circle'></i> 
                <h2>Olá, <?php echo htmlspecialchars(explode(' ', $dados_usuario['nome'])[0]); ?></h2>
            </div>

            <div class="perfil-dados">
                <div class="dado-item">
                    <label><i class='bx bxs-user'></i> Nome Completo</label>
                    <p><?php echo htmlspecialchars($dados_usuario['nome']); ?></p>
                </div>
                
                <div class="dado-item">
                    <label><i class='bx bxs-envelope'></i> E-mail</label>
                    <p><?php echo htmlspecialchars($dados_usuario['email']); ?></p>
                </div>
                
                <div class="dado-item">
                    <label><i class='bx bxs-phone'></i> Telefone</label>
                    <p><?php echo htmlspecialchars($dados_usuario['telefone'] ?? 'Não cadastrado'); ?></p>
                </div>
                
                <div class="dado-item">
                    <label><i class='bx bxs-home'></i> Endereço Principal</label>
                    <p><?php echo htmlspecialchars($dados_usuario['endereco'] ?? 'Não cadastrado'); ?></p>
                </div>
                
            </div>
            
            <div class="perfil-acoes">
                <a href="editar_perfil.php" class="btn-perfil editar-btn">
                    <i class='bx bxs-edit-alt'></i> Editar Meus Dados
                </a>
                <a href="pedidos.php" class="btn-perfil pedidos-btn">
                    <i class='bx bxs-package'></i> Meus Pedidos
                </a>
                <a href="logout.php" class="btn-perfil sair-btn">
                    <i class='bx bx-log-out'></i> Sair da Conta
                </a>
            </div>

        </div>
    </section>

    <?php require_once 'footer.php'; ?>

    </body>
</html>
<?php 
// Fechamento da conexão no final do script
if (isset($conexao)) {
    $conexao->close();
}
?>