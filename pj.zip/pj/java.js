let menu = document.querySelector('#menu-icon');
let navmenu = document.querySelector('.navmenu');

menu.onclick = () => {
    // Alterna a classe 'open' no navmenu e no ícone do menu
    menu.classList.toggle('bx-x'); // Troca para o ícone de fechar (X)
    navmenu.classList.toggle('open'); 
};