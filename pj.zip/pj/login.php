<?php
session_start();
require_once 'formu.php';

$mensagem = '';
$tipo_mensagem = '';
$email_digitado = '';

// Captura a URL de redirecionamento do parâmetro GET.
// Se não houver, usa 'index.php' como padrão.
$redirect_target = filter_input(INPUT_GET, 'redirect', FILTER_SANITIZE_URL) ?? 'index.php';

// Verifica se o usuário já está logado
if (isset($_SESSION['usuario_id'])) {
    // Se o usuário está logado E veio com um redirect, o redireciona para lá (ex: checkout.php)
    $final_redirect = ($redirect_target === 'index.php') ? 'perfil.php' : $redirect_target;
    header("Location: " . $final_redirect);
    exit;
}

// ----------------------------------------------------
// Processamento do Formulário (POST)
// ----------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $senha = $_POST['senha'];
    $email_digitado = htmlspecialchars($email);

    if (empty($email) || empty($senha)) {
        $mensagem = 'E-mail e senha são obrigatórios.';
        $tipo_mensagem = 'error';
    } else {
        $sql = "SELECT id, nome, senha FROM usuarios WHERE email = ?";

        if ($stmt = $conexao->prepare($sql)) {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado->num_rows === 1) {
                $usuario = $resultado->fetch_assoc();
                $senha_hash_db = $usuario['senha'];

                if (password_verify($senha, $senha_hash_db)) {
                    // *** LOGIN BEM-SUCEDIDO ***
                    $_SESSION['usuario_id'] = $usuario['id'];
                    $_SESSION['usuario_nome'] = $usuario['nome'];

                    // NOTA: A lógica de Mesclagem do carrinho está no carrinho.php. 
                    // Ela será executada assim que o usuário acessar o carrinho_visualizar.php ou carrinho.php
                    
                    // 4. REDIRECIONAMENTO IMEDIATO PARA O DESTINO
                    header("Location: " . $redirect_target); 
                    
                    $stmt->close();
                    $conexao->close();
                    exit;

                } else {
                    $mensagem = 'E-mail ou senha inválidos.';
                    $tipo_mensagem = 'error';
                }
            } else {
                $mensagem = 'E-mail ou senha inválidos.';
                $tipo_mensagem = 'error';
            }
            $stmt->close();
        } else {
            $mensagem = 'Erro interno do servidor. Tente novamente mais tarde.';
            $tipo_mensagem = 'error';
        }
    }

    // 4. Fechamento da conexão se o script não saiu acima (em caso de erro)
    $conexao->close();
}

// Se a conexão não foi fechada no bloco POST (por erro), ela será fechada aqui
if (isset($conexao) && $conexao->ping()) {
    $conexao->close();
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Street Style</title>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="_ADM/css/estilo_pg_produto.css">
    <link rel="stylesheet" href="_ADM/css/form_auth.css">
    <link rel="stylesheet" href="_ADM/css/header-footer.css">
</head>

<body>

    <?php require_once 'header.php' ?>

    <div class="auth-container">
        <div class="form-box">
            <h2>Acessar Conta</h2>

            <?php if ($mensagem): ?>
                <div class="message <?php echo $tipo_mensagem; ?>">
                    <?php echo $mensagem; ?>
                </div>
            <?php endif; ?>

            <form action="login.php?redirect=<?php echo urlencode($redirect_target); ?>" method="POST">
                <div class="input-group">
                    <label for="email">E-mail</label>
                    <input type="email" id="email" name="email" required value="<?php echo $email_digitado; ?>">
                </div>
                <div class="input-group">
                    <label for="senha">Senha</label>
                    <input type="password" id="senha" name="senha" required>
                </div>
                <button type="submit" class="btn-submit">Entrar</button>
            </form>
            <p>Ainda não tem conta? <a href="cadastro.php?redirect=<?php echo urlencode($redirect_target); ?>">Cadastre-se</a></p>
        </div>
    </div>

    <section class="contato">
        </section>
    <div class="texto-final">
        <p>Street Style © 2025. Todos os direitos reservados.</p>
    </div>
    <script>
        // ... Seu script de scroll ...
    </script>
</body>

</html>