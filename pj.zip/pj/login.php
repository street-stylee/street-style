<?php
session_start();
// Inclui o arquivo de conexão com o banco de dados (formu.php)
// Se você usa require_once 'formu.php'; a variável $conexao estará disponível.
require_once 'formu.php';

// Variáveis para mensagens de feedback
$mensagem = '';
$tipo_mensagem = '';
$email_digitado = ''; // Para manter o e-mail no campo se houver erro

// login.php (CÓDIGO CORRIGIDO)

// ...

// Verifica se o usuário já está logado
if (isset($_SESSION['usuario_id'])) {
    header('Location: perfil.php'); // Mude de 'index.php' para 'perfil.php'
    exit;
}

// ...
// Verifica se o formulário foi submetido
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $senha = $_POST['senha'];
    $email_digitado = htmlspecialchars($email); // Salva para preencher o campo

    // 1. Validação
    if (empty($email) || empty($senha)) {
        $mensagem = 'E-mail e senha são obrigatórios.';
        $tipo_mensagem = 'error';
    } else {
        // 2. Busca o usuário pelo e-mail (USANDO PREPARED STATEMENT para segurança)
        $sql = "SELECT id, nome, senha FROM usuarios WHERE email = ?";

        // Verifica se a conexão está OK antes de preparar
        if ($stmt = $conexao->prepare($sql)) {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado->num_rows === 1) {
                $usuario = $resultado->fetch_assoc();
                $senha_hash_db = $usuario['senha'];

                // 3. Verifica a senha usando password_verify (IMPORTANTE)
                if (password_verify($senha, $senha_hash_db)) {
                    // Login bem-sucedido: Inicia a sessão
                    $_SESSION['usuario_id'] = $usuario['id'];
                    $_SESSION['usuario_nome'] = $usuario['nome'];

                    $mensagem = 'Login realizado com sucesso! Redirecionando...';
                    $tipo_mensagem = 'success';

                    // Redireciona para a URL de destino (checkout.php) ou home
                    $redirect_url = isset($_SESSION['redirect_after_login']) ? $_SESSION['redirect_after_login'] : 'index.php';
                    unset($_SESSION['redirect_after_login']);

                    // Fechamento da conexão após o uso bem-sucedido
                    $stmt->close();
                    $conexao->close();

                    header("Refresh: 2; url=" . $redirect_url);
                    exit;

                } else {
                    $mensagem = 'E-mail ou senha inválidos.';
                    $tipo_mensagem = 'error';
                }
            } else {
                $mensagem = 'E-mail ou senha inválidos.';
                $tipo_mensagem = 'error';
            }
            $stmt->close(); // Fecha o statement
        } else {
            $mensagem = 'Erro interno do servidor. Tente novamente mais tarde.';
            $tipo_mensagem = 'error';
        }
    }

    // 4. Fechamento da conexão se o script não saiu acima (em caso de erro)
    $conexao->close();
}
// Se a conexão não foi fechada no bloco POST (por erro), ela será fechada aqui
// A conexão só é fechada no final para evitar o erro de 'mysqli object is already closed'
// Se o POST falhou, a conexão já foi fechada na linha 80.
// Se o POST NÃO foi enviado, a conexão só será fechada no final.
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Street Style</title>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="_ADM/css/estilo_pg_produto.css">
    <link rel="stylesheet" href="_ADM/css/form_auth.css">
    <link rel="stylesheet" href="_ADM/css/header-footer.css">

</head>

<body>

    <?php require_once 'header.php' ?>

    <div class="auth-container">
        <div class="form-box">
            <h2>Acessar Conta</h2>

            <?php if ($mensagem): ?>
                <div class="message <?php echo $tipo_mensagem; ?>">
                    <?php echo $mensagem; ?>
                </div>
            <?php endif; ?>

            <form action="login.php" method="POST">
                <div class="input-group">
                    <label for="email">E-mail</label>
                    <input type="email" id="email" name="email" required value="<?php echo $email_digitado; ?>">
                </div>
                <div class="input-group">
                    <label for="senha">Senha</label>
                    <input type="password" id="senha" name="senha" required>
                </div>
                <button type="submit" class="btn-submit">Entrar</button>
            </form>
            <p>Ainda não tem conta? <a href="cadastro.php">Cadastre-se</a></p>
        </div>
    </div>

    <section class="contato">
        <div class="contato-info">
            <div class="primeiro-info">
                <img src="_ADM/img_index/logotipo2.png" alt="">
                <p>ETEC Jornalista Roberto Marinho, <br> São Paulo - SP</p>
                <p>streetstyle@gmail.com</p>
                <div class="social-icon">
                    <a href="https://www.facebook.com/profile.php?id=61554518331187"><i class='bx bxl-facebook'></i></a>
                    <a href="https://twitter.com/home"><i class="fa-brands fa-x-twitter"
                            style="color: #000000;"></i></a>
                    <a href="https://www.instagram.com/streetstyle.ufc/"><i class='bx bxl-instagram'></i></a>
                    <a href="https://www.youtube.com/"><i class='bx bxl-youtube'></i></a>
                </div>
            </div>
            <div class="segundo-info">
                <h4>Suporte</h4>
                <p>Contato</p>
                <p>Sobre nós</p>
                <p>Políticas de privacidade</p>
                <p>Politicas de devolução e trocas</p>
                <p>Entrega e Prazos</p>
            </div>
            <div class="terceiro-info">
                <h4>Junte-se conosco</h4>
                <p>Venda na Street Style</p>
                <p>Anuncie sua empresa</p>
                <p>Publique suas roupas</p>
                <p>Seja um associado</p>
                <p>Anuncie seus produtos</p>
            </div>
            <div class="quarto-info">
                <h4>Pagamento</h4>
                <p>Meios de <br>Pagamento</p>
                <p>Compre com <br>Pontos</p>
                <p>Cartão de Crédito</p>
            </div>
            <div class="cinco">
                <h4>Deixe-nos ajudar você</h4>
                <p>Sua conta</p>
                <p>Frete e prazo de entrega</p>
                <p>Devoluções e reembolsos</p>
                <p>Gerencie seu conteúdo e <br>dispositivos</p>
                <p>Ajuda</p>
            </div>
        </div>
    </section>
    <div class="texto-final">
        <p>Street Style © 2023. Todos os direitos reservados.</p>
    </div>
    <script>
        window.onscroll = function () {
            scrollFunction();
        };

        function scrollFunction() {
            var header = document.querySelector('header');
            if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
                header.classList.add('scrolled');
            } else {
                if (header.classList.contains('scrolled')) {
                    header.classList.remove('scrolled');
                }
            }
        }
    </script>
</body>

</html>