<?php
require_once 'formu.php';
session_start();
// Bloco de login (deixei descomentado, mas sem forçar o redirecionamento por enquanto)
// if((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) ==true))
// {
//     unset($_SESSION['email']);
//     unset($_SESSION['senha']);
//     header('Location: login.php');
// }

// 1. Definição das variáveis de sessão (melhor prática)
$usuario_logado = isset($_SESSION['usuario_id']);
$primeiro_nome = $usuario_logado ? htmlspecialchars(explode(' ', $_SESSION['usuario_nome'] ?? 'Usuário')[0]) : '';
// $logado = $_SESSION['email'] ?? ''; // Mantido como referência, mas usando $usuario_logado

require_once 'formu.php';
$sql = "SELECT id, nome, preco, imagem_url FROM produtos ORDER BY nome";
$resultado = $conexao->query($sql);
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <link rel="stylesheet" href="_ADM/css/header-footer.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Street Style | Produtos</title>

    <link rel="stylesheet" href="_ADM/css/produto.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&display=swap"
        rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">

    <link rel="shortcut icon" href="_ADM/favicon.ico/favicon.ico" type="image/x-icon">
    <link rel="icon" href="_ADM/favicon.ico/favicon.ico" type="image/x-icon">
    <link rel="icon" type="image/png" sizes="32x32" href="_ADM/favicon.ico/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="32x32" href="_ADM/favicon.ico/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="_ADM/favicon.ico/favicon-16x16.png">
</head>

<body id="cmc">
    
    <?php require_once 'header.php'; ?>

    <section class="menu-categorias">
        <div id="fijogadores">
            <a class="jog" href="#camisas">
                <img class="ijo" src="_ADM/img/icones/camisa.png" alt="Camisetas">
                <p>Camisetas</p>
            </a>
            <a class="jog" href="#calca">
                <img class="ijo" src="_ADM/img/icones/calca.png" alt="Calças">
                <p>Calças</p>
            </a>
            <a class="jog" href="#short">
                <img class="ijo" src="_ADM/img/icones/shorts.png" alt="Shorts">
                <p>Shorts</p>
            </a>
            <a class="jog" href="#moletom">
                <img class="ijo" src="_ADM/img/icones/moletom.png" alt="Moletons/Casacos">
                <p>Moletons/Casacos</p>
            </a>
        </div>
    </section>

    <?php
    function gerarEstrelas($avaliacao)
    {
        $html = '<div class="product-rating">';
        $avaliacao_arredondada = round($avaliacao * 2) / 2;
        for ($i = 1; $i <= 5; $i++) {
            if ($avaliacao_arredondada >= $i) {
                $html .= '<i class="bx bxs-star"></i>';
            } elseif ($avaliacao_arredondada == $i - 0.5) {
                $html .= '<i class="bx bxs-star-half"></i>';
            } else {
                $html .= '<i class="bx bx-star"></i>';
            }
        }
        $html .= '</div>';
        return $html;
    }


    function exibirProdutosPorCategoria($conexao, $categoria, $titulo, $ancora)
    {
        // SQL ATUALIZADO: Inclui a coluna 'avaliacao_media'
        $sql = "SELECT id, nome, preco, imagem_url, avaliacao_media FROM produtos WHERE categoria = ? ORDER BY nome";
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("s", $categoria);
        $stmt->execute();
        $resultado = $stmt->get_result();

        echo '<br id="' . $ancora . '">';
        echo '<br>';

        echo '<section class="em-alta">';
        echo '<div class="center-text">';
        echo '<h2>' . htmlspecialchars($titulo) . '</h2>';
        echo '</div>';
        echo '<div class="produtos">';

        if ($resultado->num_rows > 0) {
            while ($produto = $resultado->fetch_assoc()) {
                echo '<div class="linha">';
                echo '<a href="produto.php?id=' . htmlspecialchars($produto['id']) . '">';
                echo '<img src="' . htmlspecialchars($produto['imagem_url']) . '" alt="' . htmlspecialchars($produto['nome']) . '">';
                echo '</a>';

                echo '<div class="product-info">';
                echo gerarEstrelas($produto['avaliacao_media']);
                echo '<div class="coracao-icon"><i class="bx bx-heart"></i></div>';
                echo '</div>';

                echo '<div class="preco">';
                echo '<h4>' . htmlspecialchars($produto['nome']) . '</h4>';
                echo '<p>R$' . number_format($produto['preco'], 2, ',', '.') . '</p>';
                echo '</div>';
                echo '</div>';
            }
        } else {
            // MENSAGEM SE NÃO HOUVER PRODUTOS
            echo '<p style="text-align: center; color: #52616B;">Nenhum produto cadastrado nesta categoria. Verifique seu banco de dados.</p>';
        }

        echo '</div>';
        echo '</section>';
    }

    $categorias = ['Camisetas', 'Calças', 'Shorts', 'Moletons'];
    $titulos = ['Camisetas', 'Calças', 'Shorts', 'Moletons/Casacos'];
    $ancoras = ['camisas', 'calca', 'short', 'moletom'];

    for ($i = 0; $i < count($categorias); $i++) {
        exibirProdutosPorCategoria($conexao, $categorias[$i], $titulos[$i], $ancoras[$i]);

        // Adiciona a linha divisória APENAS se não for a última categoria
        if ($i < count($categorias) - 1) {
            echo '<div class="categoria-divisor"></div>';
        }
    }

    // Fecha a conexão com o banco de dados
    if (isset($conexao)) {
        $conexao->close();
    }
    ?>

    <br>

    <div class="seta-baixo">
        <a href="#cmc" class="baixo"><i class='bx bx-up-arrow-alt'></i></a>
    </div>

    <?php require_once 'footer.php' ?>

    <script src="java.js"></script>

    <script>
        // Lógica para abrir/fechar o menu mobile
        const menuIcon = document.getElementById('menu-icon');
        const navmenu = document.querySelector('.navmenu');

        menuIcon.onclick = () => {
            navmenu.classList.toggle('open');
        };

        // Rolagem suave para os links de categoria
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();

                const targetId = this.getAttribute('href');
                const targetElement = document.querySelector(targetId);

                if (targetElement) {
                    const offsetTop = targetElement.getBoundingClientRect().top + window.scrollY;

                    window.scrollTo({
                        top: offsetTop - 100, // Subtrai uma margem do topo
                        behavior: 'smooth'
                    });
                }
            });
        });
    </script>
</body>

</html>