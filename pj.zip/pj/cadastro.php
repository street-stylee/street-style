<?php
session_start();
// Inclui o arquivo de conexão com o banco de dados
require_once 'formu.php'; 

// Variáveis para mensagens de feedback
$mensagem = '';
$tipo_mensagem = '';
$nome = '';
$email = '';

// Verifica se o formulário foi submetido
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Captura e limpa os dados. Usa '??' para garantir que as variáveis existam.
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    // 1. Validação simples
    if (empty($nome) || empty($email) || empty($senha)) {
        $mensagem = 'Todos os campos são obrigatórios.';
        $tipo_mensagem = 'error';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $mensagem = 'Formato de e-mail inválido.';
        $tipo_mensagem = 'error';
    } else {
        // 2. Hash da senha (SEGURANÇA!)
        $senha_hash = password_hash($senha, PASSWORD_DEFAULT);

        // 3. Verifica se o e-mail já existe (Prepared Statement)
        $sql_check = "SELECT id FROM usuarios WHERE email = ?";
        if ($stmt_check = $conexao->prepare($sql_check)) {
            $stmt_check->bind_param("s", $email);
            $stmt_check->execute();
            $stmt_check->store_result();
            
            if ($stmt_check->num_rows > 0) {
                $mensagem = 'Este e-mail já está cadastrado.';
                $tipo_mensagem = 'error';
            } else {
                // 4. Insere o novo usuário (Prepared Statement)
                $sql_insert = "INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)";
                if ($stmt_insert = $conexao->prepare($sql_insert)) {
                    $stmt_insert->bind_param("sss", $nome, $email, $senha_hash);

                    if ($stmt_insert->execute()) {
                        // Cadastro bem-sucedido
                        $mensagem = 'Cadastro realizado com sucesso! Você será redirecionado para o login.';
                        $tipo_mensagem = 'success';
                        
                        // Fecha o statement e a conexão ANTES de sair
                        $stmt_insert->close();
                        $conexao->close(); 

                        // Redireciona e ENCERRA IMEDIATAMENTE o script
                        header("Refresh: 3; url=login.php");
                        exit; 
                    } else {
                        $mensagem = 'Erro ao cadastrar: ' . $stmt_insert->error;
                        $tipo_mensagem = 'error';
                    }
                    $stmt_insert->close();
                } else {
                     $mensagem = 'Erro interno ao preparar a inserção.';
                     $tipo_mensagem = 'error';
                }
            }
            $stmt_check->close();
        } else {
             $mensagem = 'Erro interno ao preparar a checagem de e-mail.';
             $tipo_mensagem = 'error';
        }
    }
    
    // Se houve POST e o script não chamou 'exit;' (ou seja, houve um erro), fecha a conexão aqui.
    if (isset($conexao) && $conexao->ping()) {
        $conexao->close();
    }
}
// Se não houve POST, a conexão permanece aberta para o HTML.
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro - Street Style</title>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="_ADM/css/estilo_pg_produto.css"> 
    <link rel="stylesheet" href="_ADM/css/form_auth.css">
    <link rel="stylesheet" href="_ADM/css/header-footer.css">
</head>

<body>
    
    <?php require_once 'header.php' ?>

    <div class="auth-container">
        <div class="form-box">
            <h2>Criar Conta</h2>
            
            <?php if ($mensagem): ?>
                <div class="message <?php echo $tipo_mensagem; ?>">
                    <?php echo $mensagem; ?>
                </div>
            <?php endif; ?>

            <form action="cadastro.php" method="POST">
                <div class="input-group">
                    <label for="nome">Nome Completo</label>
                    <input type="text" id="nome" name="nome" required value="<?php echo htmlspecialchars($nome); ?>">
                </div>
                <div class="input-group">
                    <label for="email">E-mail</label>
                    <input type="email" id="email" name="email" required value="<?php echo htmlspecialchars($email); ?>">
                </div>
                <div class="input-group">
                    <label for="senha">Senha</label>
                    <input type="password" id="senha" name="senha" required>
                </div>
                <button type="submit" class="btn-submit">Cadastrar</button>
            </form>
            <p>Já tem uma conta? <a href="login.php">Faça Login</a></p>
        </div>
    </div>
    
    <section class="contato">
        <div class="contato-info">
            <div class="primeiro-info">
                <img src="_ADM/img/logotipo2.png" alt="">
                <p>ETEC Jornalista Roberto Marinho, <br> São Paulo - SP</p>
                <p>streetstyle@gmail.com</p>
                <div class="social-icon">
                    <a href="https://www.facebook.com/profile.php?id=61554518331187"><i class='bx bxl-facebook'></i></a>
                    <a href="https://twitter.com/home"><i class="fa-brands fa-x-twitter" style="color: #000000;"></i></a>
                    <a href="https://www.instagram.com/streetstyle.ufc/"><i class='bx bxl-instagram'></i></a>
                    <a href="https://www.youtube.com/"><i class='bx bxl-youtube'></i></a>
                </div>
            </div>
            <div class="segundo-info">
                <h4>Suporte</h4>
                <p>Contato</p>
                <p>Sobre nós</p>
                <p>Políticas de privacidade</p>
                <p>Politicas de devolução e trocas</p>
                <p>Entrega e Prazos</p>
            </div>
            <div class="terceiro-info">
                <h4>Junte-se conosco</h4>
                <p>Venda na Street Style</p>
                <p>Anuncie sua empresa</p>
                <p>Publique suas roupas</p>
                <p>Seja um associado</p>
                <p>Anuncie seus produtos</p>
            </div>
            <div class="quarto-info">
                <h4>Pagamento</h4>
                <p>Meios de <br>Pagamento</p>
                <p>Compre com <br>Pontos</p>
                <p>Cartão de Crédito</p>
            </div>
            <div class="cinco">
                <h4>Deixe-nos ajudar você</h4>
                <p>Sua conta</p>
                <p>Frete e prazo de entrega</p>
                <p>Devoluções e reembolsos</p>
                <p>Gerencie seu conteúdo e <br>dispositivos</p>
                <p>Ajuda</p>
            </div>
        </div>
    </section>
    <div class="texto-final">
        <p>Street Style © 2023. Todos os direitos reservados.</p>
    </div>
    <script>
        window.onscroll = function () {
            scrollFunction();
        };

        function scrollFunction() {
            var header = document.querySelector('header');
            if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
                header.classList.add('scrolled');
            } else {
                if (header.classList.contains('scrolled')) {
                    header.classList.remove('scrolled');
                }
            }
        }
    </script>
    
    <?php
    // Se o formulário NÃO foi submetido, a conexão ainda está aberta 
    // e precisa ser fechada para evitar que o XAMPP/PHP gere erros após o script.
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' && isset($conexao) && $conexao->ping()) {
        $conexao->close();
    }
    ?>
</body>
</html>