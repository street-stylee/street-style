<?php
require_once 'formu.php';
@session_start();
// Bloco de login (deixei descomentado, mas sem forçar o redirecionamento por enquanto)
// if((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) ==true))
// {
//     unset($_SESSION['email']);
//     unset($_SESSION['senha']);
//     header('Location: login.php');
// }

// 1. Definição das variáveis de sessão (melhor prática)
$usuario_logado = isset($_SESSION['usuario_id']);
$primeiro_nome = $usuario_logado ? htmlspecialchars(explode(' ', $_SESSION['usuario_nome'] ?? 'Usuário')[0]) : '';
// $logado = $_SESSION['email'] ?? ''; // Mantido como referência, mas usando $usuario_logado

$sql = "SELECT id, nome, preco, imagem_url FROM produtos ORDER BY nome";
$resultado = $conexao->query($sql);
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <link rel="stylesheet" href="_ADM/css/header-footer.css">
    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE-edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Street Style | A melhor loja masculina para você!</title>

    <link rel="stylesheet" href="_ADM/css/index.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&display=swap"        
        rel="stylesheet">


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"        
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="    
        crossorigin="anonymous" referrerpolicy="no-referrer" />


    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">


    <link rel="shortcut icon" href="_ADM/favicon.ico/favicon.ico" type="image/x-icon">

    <link rel="icon" href="_ADM/favicon.ico/favicon.ico" type="image/x-icon">

    <link rel="icon" type="image/png" sizes="32x32" href="_ADM/favicon.ico/favicon-96x96.png">

    <link rel="icon" type="image/png" sizes="32x32" href="_ADM/favicon.ico/favicon-32x32.png">

    <link rel="icon" type="image/png" sizes="16x16" href="_ADM/favicon.ico/favicon-16x16.png">

</head>

<body>

    <?php require_once 'header.php' ?>
    <section class="main-home">
        <div class="main-text">
            <h5>Conjunto Verão</h5>
            <h1>Novo Conjunto<br> Verão 2025</h1>
            <p>Tik Tok</p>

            <a href="produto.php?id=17" class="main-btn">Compre Agora <i class='bx bx-right-arrow-alt'></i></a>
        </div>

        <div class="seta-baixo">
            <a href="#emalta" class="baixo"><i class='bx bx-down-arrow-alt'></i></a>
        </div>
    </section>

    <section class="em-alta sessao-ofertas-destaques" id="emalta">
        
        <div class="center-text">
            <h2>Nossos produtos <span>em alta</span></h2>
        </div>

        <div class="produtos">
            <div class="linha">
                <a href="produto.php?id=15">
                    <img src="_ADM/img/roupas/camisetas/camiseta-x-high-branca/1.webp" alt="">
                    <div class="product-text">
                        <h5>Oferta!</h5>
                    </div>
                </a>
                <div class="coracao-icon"><i class='bx bx-heart'></i></div>
                <div class="avaliar">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star-half'></i>
                </div>

                <div class="preco">
                    <h4>Camiseta X-High Branca</h4>
                    <p>R$179,00</p>
                </div>
            </div>

            <div class="linha">
                <a href="produto.php?id=18">
                    <img src="_ADM/img/roupas/moletons/sueter-x-ray/1.webp" alt="">
                    <div class="product-text">
                        <h5>Novo</h5>
                    </div>
                </a>
                <div class="coracao-icon"><i class='bx bx-heart'></i></div>
                <div class="avaliar">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bx-star'></i>

                </div>

                <div class="preco">
                    <h4>Suéter X-Ray</h4>
                    <p>R$339,00</p>
                </div>
            </div>

            <div class="linha">
                <a href="produto.php?id=32">
                    <img src="_ADM/img/roupas/shorts/shorts-x-high-preto/1.webp" alt="">
                </a>
                <div class="coracao-icon"><i class='bx bx-heart'></i></div>
                <div class="avaliar">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star-half'></i>
                </div>

                <div class="preco">
                    <h4>Shorts X-High Preto</h4>
                    <p>R$239,00</p>
                </div>
            </div>

            <div class="linha">
                <a href="produto.php?id=4">

                    <img src="_ADM/img/roupas/calcas/calca-suf-4-40-vermelha/1.webp" alt="">
                    <div class="product-text">
                        <h5>Em alta</h5>
                    </div>
                </a>
                <div class="coracao-icon"><i class='bx bx-heart'></i></div>
                <div class="avaliar">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bx-star'></i>
                </div>

                <div class="preco">
                    <h4>Calça Suf 4-40 Vermelha</h4>
                    <p>R$199,00</p>
                </div>
            </div>

            <div class="linha">
                <a href="produto.php?id=27">

                    <img src="_ADM/img/roupas/shorts/shorts-kierk-jeans-preto/1.webp" alt="">
                </a>
                <div class="coracao-icon"><i class='bx bx-heart'></i></div>
                <div class="avaliar">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star-half'></i>
                </div>

                <div class="preco">
                    <h4>Shorts Kierk Jeans Preto</h4>
                    <p>R$349,00</p>
                </div>
            </div>

            <div class="linha">
                <a href="produto.php?id=3">
                    <img src="_ADM/img/roupas/calcas/calca-jeans-escura/1.webp" alt="">
                    <div class="product-text">
                        <h5>Em alta</h5>
                    </div>
                </a>
                <div class="coracao-icon"><i class='bx bx-heart'></i></div>
                <div class="avaliar">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bx-star'></i>
                    <i class='bx bx-star'></i>
                </div>

                <div class="preco">
                    <h4>Calça Jeans Escura</h4>
                    <p>R$349,00</p>
                </div>
            </div>

            <div class="linha">
                <a href="produto.php?id=13">

                    <img src="_ADM/img/roupas/camisetas/camiseta-world-of-mine-preta/1.webp" alt="">
                    <div class="product-text">
                        <h5>Oferta!</h5>
                    </div>
                </a>
                <div class="coracao-icon"><i class='bx bx-heart'></i></div>
                <div class="avaliar">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bx-star'></i>
                </div>

                <div class="preco">
                    <h4>Camiseta World Of Mine Preta</h4>
                    <p>R$159,00</p>
                </div>
            </div>

            <div class="linha">
                <a href="produto.php?id=24">
                    <img src="_ADM/img/roupas/moletons/casaco-trippy/1.webp" alt="">
                    <div class="product-text">
                        <h5>Oferta!</h5>
                    </div>
                </a>
                <div class="coracao-icon"><i class='bx bx-heart'></i></div>
                <div class="avaliar">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star-half'></i>
                </div>

                <div class="preco">
                    <h4>Casaco Trippy</h4>
                    <p>R$649,00</p>
                </div>
            </div>

            <div class="linha">
                <a href="produto.php?id=11">
                    <img src="_ADM/img/roupas/camisetas/camiseta-pipa-verde/1.webp" alt="">
                    <div class="product-text">
                        <h5>Novo</h5>
                    </div>
                </a>
                <div class="coracao-icon"><i class='bx bx-heart'></i></div>
                <div class="avaliar">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bx-star'></i>
                </div>

                <div class="preco">
                    <h4>Camiseta Pipa Verde</h4>
                    <p>R$89,90</p>
                </div>
            </div>
        </div>
    </section>

    <section class="vantagens">
        <div class="vantagem-item">
            <i class='bx bxs-truck'></i>
            <h4>Frete Rápido e Seguro</h4>
            <p>Entregamos para todo o Brasil.</p>
        </div>
        <div class="vantagem-item">
            <i class='bx bxs-check-shield'></i>
            <h4>100% Original</h4>
            <p>Trabalhamos apenas com marcas autênticas.</p>
        </div>
        <div class="vantagem-item">
            <i class='bx bxs-credit-card'></i>
            <h4>Pagamento em 10x</h4>
            <p>Parcele sem juros no cartão de crédito.</p>
        </div>
        <div class="vantagem-item">
            <i class='bx bx-refresh'></i>
            <h4>Troca Grátis</h4>
            <p>Se não serviu, a primeira troca é por nossa conta.</p>
        </div>
    </section>


    <section class="em-alta sessao-ofertas-destaques" id="ofertas">
        <div class="center-text">
            <h2>Ofertas!</h2>
        </div>

        <div class="produtos">
            <div class="linha">
                <a href="produto.php?id=10">
                    <img src="_ADM/img/roupas/camisetas/camiseta-albatroz/1.webp" alt="">
                    <div class="product-text">
                        <h5>Oferta!</h5>
                    </div>
                </a>
                <div class="coracao-icon"><i class='bx bx-heart'></i></div>
                <div class="avaliar">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bx-star'></i>
                </div>

                <div class="preco">
                    <h4>Camiseta Albatroz</h4>
                    <p>R$109,00</p>
                </div>
            </div>

            <div class="linha">
                <a href="produto.php?id=2">

                    <img src="_ADM/img/roupas/calcas/calca-jeans-azul/1.webp" alt="">
                    <div class="product-text">
                        <h5>Oferta!</h5>
                    </div>
                </a>
                <div class="coracao-icon"><i class='bx bx-heart'></i></div>
                <div class="avaliar">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star-half'></i>
                </div>

                <div class="preco">
                    <h4>Calça Jeans Azul</h4>
                    <p>R$349,00</p>
                </div>
            </div>

            <div class="linha">
                <a href="produto.php?id=28">

                    <img src="_ADM/img/roupas/shorts/short-hider-preto/1.webp" alt="">
                    <div class="product-text">
                        <h5>Oferta!</h5>
                    </div>
                </a>
                <div class="coracao-icon"><i class='bx bx-heart'></i></div>
                <div class="avaliar">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bx-star'></i>
                    <i class='bx bx-star'></i>
                </div>

                <div class="preco">
                    <h4>Short Hider Preto</h4>
                    <p>R$109,00</p>
                </div>
            </div>

            <div class="linha">
                <a href="produto.php?id=12">

                    <img src="_ADM/img/roupas/camisetas/manga-longa-strength-branca/1.webp" alt="">
                    <div class="product-text">
                        <h5>Oferta!</h5>
                    </div>
                </a>
                <div class="coracao-icon"><i class='bx bx-heart'></i></div>
                <div class="avaliar">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bx-star'></i>
                </div>

                <div class="preco">
                    <h4>Manga Longa Strength Branca</h4>
                    <p>R$119,00</p>
                </div>
            </div>

            <div class="linha">
                <a href="produto.php?id=22">

                    <img src="_ADM/img/roupas/moletons/sueter-zushi/1.webp" alt="">
                    <div class="product-text">
                        <h5>Oferta!</h5>
                    </div>
                </a>
                <div class="coracao-icon"><i class='bx bx-heart'></i></div>
                <div class="avaliar">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bx-star'></i>
                </div>

                <div class="preco">
                    <h4>Suéter Zushi</h4>
                    <p>R$319,00</p>
                </div>
            </div>

            <div class="linha">
                <a href="produto.php?id=23">

                    <img src="_ADM/img/roupas/moletons/moletom-falador-passa-mal/1.webp" alt="">
                    <div class="product-text">
                        <h5>Oferta!</h5>
                    </div>
                </a>
                <div class="coracao-icon"><i class='bx bx-heart'></i></div>
                <div class="avaliar">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bx-star'></i>
                    <i class='bx bx-star'></i>
                </div>

                <div class="preco">
                    <h4>Moletom Falador Passa Mal</h4>
                    <p>R$239,00</p>
                </div>
            </div>

            <div class="linha">
                <a href="produto.php?id=7">

                    <img src="_ADM/img/roupas/calcas/calca-caqui-escuro/1.webp" alt="">
                    <div class="product-text">
                        <h5>Oferta!</h5>
                    </div>
                </a>
                <div class="coracao-icon"><i class='bx bx-heart'></i></div>
                <div class="avaliar">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star-half'></i>
                </div>

                <div class="preco">
                    <h4>Calça Caqui Escuro</h4>
                    <p>R$339,00</p>
                </div>
            </div>

            <div class="linha">
                <a href="produto.php?id=16">

                    <img src="_ADM/img/roupas/camisetas/camiseta-freak-bege/1.webp" alt="">
                    <div class="product-text">
                        <h5>Oferta!</h5>
                    </div>

                </a>
                <div class="coracao-icon"><i class='bx bx-heart'></i></div>
                <div class="avaliar">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star-half'></i>
                </div>
                <div class="preco">
                    <h4>Camiseta Freak Bege</h4>
                    <p>R$129,00</p>
                </div>
            </div>

            <div class="linha">
                <a href="produto.php?id=26">
                    <img src="_ADM/img/roupas/shorts/shorts-layered-laranja/1.webp" alt="">
                    <div class="product-text">
                        <h5>Oferta!</h5>
                    </div>
                </a>
                <div class="coracao-icon"><i class='bx bx-heart'></i></div>
                <div class="avaliar">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                </div>

                <div class="preco">
                    <h4>Shorts Layered Laranja</h4>
                    <p>R$129,90</p>
                </div>
            </div>
        </div>
    </section>
<!-- marquee -->

     <h1 class="h1-marquee">Parceiros</h1>
<div class="marquee" id="marquee">
    
  <div class="marquee-track">
    <div class="marquee-group">
      <span class="span-img"><img class="marquee-img" src="_ADM/img/marcas/nike.png" alt=""></span>
      <span class="span-img"><img class="marquee-img" src="_ADM/img/marcas/high.webp" alt=""></span>
      <span class="span-img"><img class="marquee-img" src="_ADM/img/marcas/adidas.png" alt=""></span>
      <span class="span-img"><img class="marquee-img" src="_ADM/img/marcas/oakley.png" alt=""></span>
      <span class="span-img"><img class="marquee-img" src="_ADM/img/marcas/asics.png" alt=""></span>
      <span class="span-img"><img class="marquee-img" src="_ADM/img/marcas/Under_armour_logo.svg.png" alt=""></span>
    </div>
  </div>
</div>
<br>
<br>


<!-- fim do marquee -->



    <section class="contato">
        <div class="contato-info">
            <div class="primeiro-info">
                <img src="_ADM/img/logotipo2.png" alt="">
                <p>ETEC Jornalista Roberto Marinho, <br> São Paulo - SP</p>
                <p>tccterceiroinfo@gmail.com</p>

                <div class="social-icon">
                    <a href="https://www.facebook.com/profile.php?id=61554518331187"><i class='bx bxl-facebook'></i></a>
                    <a href="https://twitter.com/home"><i class="fa-brands fa-x-twitter"></i></a>
                    <a href="https://www.instagram.com/streetstyle.ufc/"><i class='bx bxl-instagram'></i></a>
                    <a href="https://www.youtube.com/"><i class='bx bxl-youtube'></i></a>
                </div>
            </div>

            <div class="segundo-info">
                <h4>Suporte</h4>
                <p>Contato</p>
                <p>Sobre nós</p>
                <p>Políticas de privacidade</p>
                <p>Politicas de devolução e trocas</p>
                <p>Entrega e Prazos</p>
            </div>

            <div class="terceiro-info">
                <h4>Junte-se conosco</h4>
                <p>Venda na Street Style</p>
                <p>Anuncie sua empresa</p>
                <p>Publique suas roupas</p>
                <p>Seja um associado</p>
                <p>Anuncie seus produtos</p>
            </div>

            <div class="quarto-info">
                <h4>Pagamento</h4>
                <p>Meios de <br>Pagamento</p>
                <p>Compre com <br>Pontos</p>
                <p>Cartão de Crédito</p>
            </div>

            <div class="cinco">
                <h4>Deixe-nos ajudar você</h4>
                <p>Sua conta</p>
                <p>Frete e prazo de entrega</p>
                <p>Devoluções e reembolsos</p>
                <p>Gerencie seu conteúdo e <br>dispositivos</p>
                <p>Ajuda</p>
            </div>
        </div>
    </section>

    <div class="texto-final">
        <p>Street Style © 2025. Todos os direitos reservados.</p>
    </div>


    <script src="java.js"></script>
    <script src="_ADM/js/marquee.js"></script>

    <?php
    // Fecha a conexão com o banco de dados no final do script
    if (isset($conexao) && $conexao->ping()) {
        $conexao->close();
    }
    ?>
</body>

</html>