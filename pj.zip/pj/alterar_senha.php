<?php
require_once 'formu.php'; // Inclui a conexão e inicia a sessão

// Variáveis para feedback
$mensagem = '';
$tipo_mensagem = ''; // 'sucesso' ou 'erro'

// 1. VERIFICAÇÃO DE LOGIN
// editar_perfil.php (CÓDIGO CORRIGIDO - Use esta opção)

// 1. VERIFICAÇÃO DE LOGIN
// Redireciona se o ID do usuário NÃO estiver definido na sessão
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

$usuario_id = $_SESSION['usuario_id']; // Agora podemos usar o ID com segurança
// ... o restante do código segue

// =======================================================
// 2. PROCESSAMENTO DO FORMULÁRIO (ALTERAÇÃO DE SENHA)
// =======================================================
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // 2.1. Sanitização e obtenção das senhas
    $senha_atual = $_POST['senha_atual'] ?? '';
    $nova_senha = $_POST['nova_senha'] ?? '';
    $confirmar_senha = $_POST['confirmar_senha'] ?? '';

    // 2.2. Validação Inicial
    if (empty($senha_atual) || empty($nova_senha) || empty($confirmar_senha)) {
        $mensagem = "Todos os campos são obrigatórios.";
        $tipo_mensagem = 'erro';
    } else if (strlen($nova_senha) < 6) {
        $mensagem = "A nova senha deve ter no mínimo 6 caracteres.";
        $tipo_mensagem = 'erro';
    } else if ($nova_senha !== $confirmar_senha) {
        $mensagem = "A nova senha e a confirmação não coincidem.";
        $tipo_mensagem = 'erro';
    }

    // Se a validação inicial passou
    if ($tipo_mensagem != 'erro') {

        // 2.3. Verificação da Senha Atual (CRUCIAL)
        $sql_check = "SELECT senha FROM usuarios WHERE id = ?";
        $stmt_check = $conexao->prepare($sql_check);

        if ($stmt_check) {
            $stmt_check->bind_param("i", $usuario_id);
            $stmt_check->execute();
            $resultado_check = $stmt_check->get_result();
            $usuario = $resultado_check->fetch_assoc();
            $stmt_check->close();

            // Verifica se a senha atual fornecida é a mesma senha criptografada no banco
            // IMPORTANTE: Assumindo que você está usando password_hash() no cadastro.
            if ($usuario && password_verify($senha_atual, $usuario['senha'])) {

                // 2.4. CRIPTOGRAFIA e Atualização da Nova Senha
                $senha_hash = password_hash($nova_senha, PASSWORD_DEFAULT);

                $sql_update = "UPDATE usuarios SET senha = ? WHERE id = ?";
                $stmt_update = $conexao->prepare($sql_update);

                if ($stmt_update) {
                    $stmt_update->bind_param("si", $senha_hash, $usuario_id);

                    if ($stmt_update->execute()) {
                        $mensagem = "Sua senha foi alterada com sucesso!";
                        $tipo_mensagem = 'sucesso';
                    } else {
                        $mensagem = "Erro ao atualizar a senha: " . $stmt_update->error;
                        $tipo_mensagem = 'erro';
                    }
                    $stmt_update->close();
                } else {
                    $mensagem = "Erro interno ao preparar a atualização.";
                    $tipo_mensagem = 'erro';
                }

            } else {
                $mensagem = "A senha atual está incorreta. Tente novamente.";
                $tipo_mensagem = 'erro';
            }
        } else {
            $mensagem = "Erro interno ao buscar a senha atual.";
            $tipo_mensagem = 'erro';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alterar Senha | Street Style</title>

    <link rel="stylesheet" href="_ADM/css/header-footer.css">
    <link rel="stylesheet" href="_ADM/css/produto.css">
    <link rel="stylesheet" href="_ADM/css/perfil.css">
    <link rel="stylesheet" href="_ADM/css/form_geral.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
</head>

<body>

    <?php require_once 'header.php'; ?>

    <section class="perfil-section">
        <div class="perfil-card editar-card">

            <div class="perfil-header">
                <i class='bx bxs-lock-alt'></i>
                <h2>Alterar Senha</h2>
            </div>

            <?php if (!empty($mensagem)): ?>
                <div class="mensagem-feedback <?php echo $tipo_mensagem; ?>">
                    <?php echo $mensagem; ?>
                </div>
            <?php endif; ?>

            <form action="alterar_senha.php" method="POST" class="form-perfil">

                <div class="form-group">
                    <label for="senha_atual"><i class='bx bxs-lock-alt'></i> Senha Atual</label>
                    <input type="password" id="senha_atual" name="senha_atual" required>
                </div>

                <hr style="border-color: var(--color-cinza2); margin: 25px 0;">

                <div class="form-group">
                    <label for="nova_senha"><i class='bx bxs-key'></i> Nova Senha (mín. 6 caracteres)</label>
                    <input type="password" id="nova_senha" name="nova_senha" required>
                </div>

                <div class="form-group">
                    <label for="confirmar_senha"><i class='bx bxs-key'></i> Confirme a Nova Senha</label>
                    <input type="password" id="confirmar_senha" name="confirmar_senha" required>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn-submit"><i class='bx bxs-check-circle'></i> Mudar Senha</button>
                    <a href="perfil.php" class="btn-cancelar"><i class='bx bx-arrow-back'></i> Voltar ao Perfil</a>
                </div>
            </form>

        </div>
    </section>

    <?php require_once 'footer.php'; ?>

</body>

</html>
<?php
// Fechamento da conexão
if (isset($conexao)) {
    $conexao->close();
}
?>