<?php
// produto.php (Versão com Variação APENAS por Tamanho)
// =======================================================
// LÓGICA PHP DE CONEXÃO E BUSCA DE DADOS
// =======================================================

session_start();

require_once 'formu.php'; 

$usuario_logado = isset($_SESSION['usuario_id']);
$primeiro_nome = $usuario_logado ? htmlspecialchars(explode(' ', $_SESSION['usuario_nome'] ?? 'Usuário')[0]) : '';

// 2. Pega o ID do produto da URL e valida
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $produto_id = intval($_GET['id']);
} else {
    header('Location: produtos.php'); 
    exit;
}

// 3. Busca os dados do PRODUTO PRINCIPAL na tabela 'produtos'
$sql_produto = "SELECT id, nome, descricao, preco, imagem_url, categoria, avaliacao_media FROM produtos WHERE id = ?";
$stmt_produto = $conexao->prepare($sql_produto);
if ($stmt_produto === false) {
    die("Erro ao preparar a query de produto: " . $conexao->error);
}
$stmt_produto->bind_param("i", $produto_id);
$stmt_produto->execute();
$resultado_produto = $stmt_produto->get_result();

if ($resultado_produto->num_rows > 0) {
    $produto = $resultado_produto->fetch_assoc();
} else {
    header('Location: produtos.php');
    exit;
}
$stmt_produto->close();

// 4. Busca as IMAGENS EXTRAS na tabela 'produto_imagens'
$sql_imagens = "SELECT imagem_url FROM produto_imagens WHERE produto_id = ?";
$stmt_imagens = $conexao->prepare($sql_imagens);
if ($stmt_imagens === false) {
    die("Erro ao preparar a query de imagens: " . $conexao->error);
}
$stmt_imagens->bind_param("i", $produto_id);
$stmt_imagens->execute();
$resultado_imagens = $stmt_imagens->get_result();

$imagens_extras = [];
while ($imagem = $resultado_imagens->fetch_assoc()) {
    $imagens_extras[] = $imagem['imagem_url'];
}
$stmt_imagens->close();

// 4.1. Busca e Estrutura as Variações (TAMANHO/ESTOQUE)
$variacoes_json_data = [];
$tamanhos_disponiveis = [];

// A nova query AGORA SÓ TRAZ ID, TAMANHO E ESTOQUE
$sql_vari = "SELECT id, tamanho, estoque FROM produto_variacoes WHERE produto_id = ? ORDER BY tamanho";
$stmt_vari = $conexao->prepare($sql_vari);
if ($stmt_vari === false) {
    die("Erro ao preparar a query de variações: " . $conexao->error);
}

$stmt_vari->bind_param("i", $produto_id);
$stmt_vari->execute();
$resultado_vari = $stmt_vari->get_result();

// Estrutura os dados para o JavaScript: {Tamanho: {id, estoque}}
while ($variacao = $resultado_vari->fetch_assoc()) {
    $tamanho = $variacao['tamanho'];
    
    // Armazena a variação diretamente no índice do tamanho
    $variacoes_json_data[$tamanho] = [
        'id' => $variacao['id'],
        'estoque' => $variacao['estoque']
    ];
    $tamanhos_disponiveis[] = $tamanho;
}
$stmt_vari->close();

$primeiro_tamanho = !empty($tamanhos_disponiveis) ? reset($tamanhos_disponiveis) : null;


// 5. Busca produtos SEMELHANTES
$sql_semelhantes = "SELECT id, nome, preco, imagem_url, avaliacao_media FROM produtos 
                    WHERE categoria = ? AND id != ?
                    ORDER BY RAND() LIMIT 4"; 
$stmt_semelhantes = $conexao->prepare($sql_semelhantes);
$stmt_semelhantes->bind_param("si", $produto['categoria'], $produto_id);
$stmt_semelhantes->execute();
$resultado_semelhantes = $stmt_semelhantes->get_result();

$produtos_semelhantes = [];
while ($produto_semelhante = $resultado_semelhantes->fetch_assoc()) {
    if (!isset($produto_semelhante['avaliacao_media'])) {
        $produto_semelhante['avaliacao_media'] = rand(30, 50) / 10; 
    }
    $produtos_semelhantes[] = $produto_semelhante;
}
$stmt_semelhantes->close();

// 6. Encerra a conexão
$conexao->close();


/**
 * Função para gerar as estrelas de avaliação (Font Awesome 6)
 */
function gerarEstrelas($rating, $max_stars = 5) {
    $html = '';
    $rating = round($rating * 2) / 2;
    for ($i = 1; $i <= $max_stars; $i++) {
        if ($rating >= $i) {
            $html .= '<i class="fa-solid fa-star"></i>';
        } elseif ($rating > ($i - 1) && $rating < $i) {
            $html .= '<i class="fa-solid fa-star-half-stroke"></i>';
        } else {
            $html .= '<i class="fa-regular fa-star"></i>';
        }
    }
    return $html;
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($produto['nome']); ?> - Street Style</title>

    <link rel="stylesheet" href="_ADM/css/header-footer.css">
    <link rel="stylesheet" href="_ADM/css/estilo_pg_produto.css">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&family=Poppins:wght@100;300;400;500;600;700&display=swap" rel="stylesheet">
    
    <link rel="shortcut icon" href="../_ADM/favicon.ico/favicon.ico" type="image/x-icon">
    <link rel="icon" type="image/png" sizes="32x32" href="_ADM/favicon.ico/favicon-96x96.png">
    
    <style>
        /* --- ESTILOS DE VARIAÇÃO (Pode mover para estilo_pg_produto.css) --- */
        .opcoes-variacao label {
            display: block;
            font-weight: bold;
            margin-bottom: 8px;
        }
        .opcoes-lista {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        .variacao-btn {
            padding: 8px 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.2s;
            user-select: none; 
            font-size: 0.9em;
        }
        .variacao-btn:hover {
            border-color: #555;
        }
        .variacao-btn.selected {
            background-color: #2c3e50;
            color: white;
            border-color: #2c3e50;
            font-weight: bold;
        }
        .variacao-btn.disabled {
            opacity: 0.5;
            cursor: not-allowed;
            text-decoration: line-through;
            background-color: #f8f8f8;
        }
        #add-to-cart-btn:disabled {
            background-color: #bdc3c7;
            cursor: not-allowed;
            opacity: 0.7;
        }
    </style>

</head>

<body>
    <?php require_once 'header.php' ?>
    <div class="pequeno-container single-product">
        <div class="row">
            <div class="col-2">
                <img src="<?php echo htmlspecialchars($produto['imagem_url']); ?>" id="ProductImg"
                    alt="<?php echo htmlspecialchars($produto['nome']); ?>">
                
                <div class="pequeno-img-row">
                    <div class="pequeno-img-col">
                        <img src="<?php echo htmlspecialchars($produto['imagem_url']); ?>" class="pequeno-img" alt="Vista principal"
                            onclick="mudarImagem(this.src)">
                    </div>
                    <?php foreach ($imagens_extras as $url_extra): ?>
                        <div class="pequeno-img-col">
                            <img src="<?php echo htmlspecialchars($url_extra); ?>" class="pequeno-img" alt="Vista extra"
                                onclick="mudarImagem(this.src)">
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="col-2">
                <p>Produtos / <?php echo htmlspecialchars($produto['categoria']); ?></p>
                <h1><?php echo htmlspecialchars($produto['nome']); ?></h1>
                <div class="avaliar">
                    <?php echo gerarEstrelas($produto['avaliacao_media']); ?>

                    <span class="nota-avaliacao">
                        (<?php echo number_format($produto['avaliacao_media'], 1, ',', '.'); ?>)
                    </span>
                </div>
                
                <h4>R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></h4>
                
                <form id="form-carrinho" action="carrinho.php" method="post">
                    <input type="hidden" name="produto_id" value="<?php echo htmlspecialchars($produto_id); ?>">
                    
                    <input type="hidden" name="variacao_id" id="variacao-id" value=""> 

                    <div class="opcoes-variacao">
                        <label>Tamanho:</label>
                        <div id="tamanho-options" class="opcoes-lista">
                            <?php if (empty($tamanhos_disponiveis)): ?>
                                <p style="color: red;">Nenhuma variação disponível.</p>
                            <?php else: ?>
                                <?php foreach ($tamanhos_disponiveis as $tamanho): ?>
                                    <span 
                                        class="variacao-btn" 
                                        data-tamanho="<?php echo htmlspecialchars($tamanho); ?>">
                                        <?php echo htmlspecialchars($tamanho); ?>
                                    </span>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div id="estoque-status" style="margin: 15px 0; font-weight: bold;"></div>
                    
                    <input type="number" id="quantidade" name="quantidade" value="1" min="1" max="1" required style="width: 70px;">
                    
                    <button type="submit" class="btn" id="add-to-cart-btn" disabled>Adicionar ao Carrinho</button>
                </form>
                <h3>Detalhes do Produto</h3>
                <br>
                <p><?php echo nl2br(htmlspecialchars($produto['descricao'])); ?></p>
            </div>
        </div>
    </div>

    <section class="em-alta" id="emalta">
        <div class="center-text">
            <h2>Produtos <span>Semelhantes</span></h2>
        </div>
        
        <div class="produtos">
            <?php foreach ($produtos_semelhantes as $similar_produto): ?>
                <div class="linha">
                    <a href="produto.php?id=<?php echo htmlspecialchars($similar_produto['id']); ?>">
                        <img src="<?php echo htmlspecialchars($similar_produto['imagem_url']); ?>" 
                             alt="<?php echo htmlspecialchars($similar_produto['nome']); ?>">
                    </a>
                    
                    <div class="product-text">
                        <a href="#"><i class='bx bx-heart coracao-icon'></i></a> 
                    </div>
                    
                    <div class="preco">
                        <a href="produto.php?id=<?php echo htmlspecialchars($similar_produto['id']); ?>">
                            <h4><?php echo htmlspecialchars($similar_produto['nome']); ?></h4>
                        </a>
                        <div class="avaliar">
                            <?php 
                            echo gerarEstrelas($similar_produto['avaliacao_media']); 
                            ?>
                        </div>
                        <p>R$ <?php echo number_format($similar_produto['preco'], 2, ',', '.'); ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <?php require_once 'footer.php' ?>

    <script>
        // Função para mudar a imagem principal ao rolar (Header)
        window.onscroll = function () {
            scrollFunction();
        };

        function scrollFunction() {
            var header = document.querySelector('header');
            if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        }
        
        // Função para trocar a imagem principal (Galeria de miniaturas)
        var SmallImg = document.getElementsByClassName("pequeno-img");
        var ProductImg = document.getElementById("ProductImg");
        
        function mudarImagem(novaUrl) {
             ProductImg.src = novaUrl;
        }

        // Adiciona um evento de clique para cada miniatura
        for (let i = 0; i < SmallImg.length; i++) {
            SmallImg[i].onclick = function () {
                mudarImagem(this.src);
            };
        }
    </script>

    <script>
        // Carrega a estrutura de dados PHP: {Tamanho: {id, estoque}}
        const VARIACAO_DATA = <?php echo json_encode($variacoes_json_data); ?>;
        const primeiroTamanho = '<?php echo $primeiro_tamanho; ?>';
        
        const tamanhoOptions = document.getElementById('tamanho-options');
        const variacaoIdInput = document.getElementById('variacao-id');
        const estoqueStatus = document.getElementById('estoque-status');
        const quantidadeInput = document.getElementById('quantidade');
        const addToCartBtn = document.getElementById('add-to-cart-btn');

        let selectedTamanho = null;
        
        // ----------------------------------------------------
        // Inicialização e Seleção de Tamanho
        // ----------------------------------------------------
        document.addEventListener('DOMContentLoaded', () => {
             if (primeiroTamanho) {
                // Tenta pré-selecionar o primeiro tamanho disponível
                const firstSizeElement = tamanhoOptions.querySelector(`[data-tamanho="${primeiroTamanho}"]`);
                if (firstSizeElement) {
                    firstSizeElement.classList.add('selected');
                    selectedTamanho = primeiroTamanho;
                    updateStatus(selectedTamanho); // Atualiza o status do primeiro tamanho
                }
             } else {
                estoqueStatus.innerHTML = '<span style="color: red;">Produto esgotado ou sem variações.</span>';
                addToCartBtn.disabled = true;
             }
        });

        // Evento de clique para o Tamanho
        tamanhoOptions.addEventListener('click', (e) => {
            if (e.target.classList.contains('variacao-btn')) {
                // 1. Desmarca o atual e marca o novo
                document.querySelectorAll('#tamanho-options .variacao-btn').forEach(el => el.classList.remove('selected'));
                e.target.classList.add('selected');

                selectedTamanho = e.target.dataset.tamanho;
                
                // 2. Atualiza o status
                updateStatus(selectedTamanho);
            }
        });

        // ----------------------------------------------------
        // Atualização do Status de Estoque e ID
        // ----------------------------------------------------
        function updateStatus(tamanho) {
            const variacao = VARIACAO_DATA[tamanho];
            if (!variacao) {
                estoqueStatus.innerHTML = '<span style="color: red;">Variação não encontrada.</span>';
                addToCartBtn.disabled = true;
                return;
            }

            const estoque = variacao.estoque;

            if (estoque > 0) {
                estoqueStatus.innerHTML = `<span style="color: green;">Em estoque: ${estoque} unidades.</span>`;
                addToCartBtn.disabled = false;
                
                // Define o ID da Variação e o MAX de quantidade
                variacaoIdInput.value = variacao.id;
                quantidadeInput.max = estoque;
                // Garante que a quantidade não exceda o estoque
                quantidadeInput.value = Math.min(quantidadeInput.value, estoque);
                
            } else {
                estoqueStatus.innerHTML = '<span style="color: red;">Esgotado!</span>';
                addToCartBtn.disabled = true;
                variacaoIdInput.value = '';
                quantidadeInput.max = 1;
                quantidadeInput.value = 1;
            }
        }
    </script>
</body>

</html>