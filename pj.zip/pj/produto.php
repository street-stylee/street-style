<?php
// =======================================================
// LÓGICA PHP DE CONEXÃO E BUSCA DE DADOS
// =======================================================

session_start();

require_once 'formu.php'; 

$usuario_logado = isset($_SESSION['usuario_id']);
$primeiro_nome = $usuario_logado ? htmlspecialchars(explode(' ', $_SESSION['usuario_nome'] ?? 'Usuário')[0]) : '';

// 2. Pega o ID do produto da URL e valida
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $produto_id = intval($_GET['id']);
} else {
    header('Location: produtos.php'); 
    exit;
}

// 3. Busca os dados do PRODUTO PRINCIPAL na tabela 'produtos'
$sql_produto = "SELECT id, nome, descricao, preco, imagem_url, categoria, avaliacao_media FROM produtos WHERE id = ?";
$stmt_produto = $conexao->prepare($sql_produto);
if ($stmt_produto === false) {
    die("Erro ao preparar a query de produto: " . $conexao->error);
}
$stmt_produto->bind_param("i", $produto_id);
$stmt_produto->execute();
$resultado_produto = $stmt_produto->get_result();

if ($resultado_produto->num_rows > 0) {
    $produto = $resultado_produto->fetch_assoc();
} else {
    header('Location: produtos.php');
    exit;
}
$stmt_produto->close();

// 4. Busca as IMAGENS EXTRAS na tabela 'produto_imagens'
$sql_imagens = "SELECT imagem_url FROM produto_imagens WHERE produto_id = ?";
$stmt_imagens = $conexao->prepare($sql_imagens);
if ($stmt_imagens === false) {
    die("Erro ao preparar a query de imagens: " . $conexao->error);
}
$stmt_imagens->bind_param("i", $produto_id);
$stmt_imagens->execute();
$resultado_imagens = $stmt_imagens->get_result();

$imagens_extras = [];
while ($imagem = $resultado_imagens->fetch_assoc()) {
    $imagens_extras[] = $imagem['imagem_url'];
}
$stmt_imagens->close();

// 5. Busca produtos SEMELHANTES
$sql_semelhantes = "SELECT id, nome, preco, imagem_url, avaliacao_media FROM produtos 
                    WHERE categoria = ? AND id != ?
                    ORDER BY RAND() LIMIT 4"; 
$stmt_semelhantes = $conexao->prepare($sql_semelhantes);
$stmt_semelhantes->bind_param("si", $produto['categoria'], $produto_id);
$stmt_semelhantes->execute();
$resultado_semelhantes = $stmt_semelhantes->get_result();

$produtos_semelhantes = [];
while ($produto_semelhante = $resultado_semelhantes->fetch_assoc()) {
    if (!isset($produto_semelhante['avaliacao_media'])) {
        $produto_semelhante['avaliacao_media'] = rand(30, 50) / 10; 
    }
    $produtos_semelhantes[] = $produto_semelhante;
}
$stmt_semelhantes->close();

// 6. Encerra a conexão
$conexao->close();


/**
 * Função para gerar as estrelas de avaliação (Font Awesome 6)
 */
function gerarEstrelas($rating, $max_stars = 5) {
    $html = '';
    $rating = round($rating * 2) / 2;
    for ($i = 1; $i <= $max_stars; $i++) {
        if ($rating >= $i) {
            $html .= '<i class="fa-solid fa-star"></i>';
        } elseif ($rating > ($i - 1) && $rating < $i) {
            $html .= '<i class="fa-solid fa-star-half-stroke"></i>';
        } else {
            $html .= '<i class="fa-regular fa-star"></i>';
        }
    }
    return $html;
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($produto['nome']); ?> - Street Style</title>

    <link rel="stylesheet" href="_ADM/css/header-footer.css">

    <link rel="stylesheet" href="_ADM/css/estilo_pg_produto.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&display=swap"
        rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&family=Poppins:wght@100;300;400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link rel="shortcut icon" href="../_ADM/favicon.ico/favicon.ico" type="image/x-icon">
    <link rel="icon" type="image/png" sizes="32x32" href="_ADM/favicon.ico/favicon-96x96.png">

</head>

<body>
    <?php require_once 'header.php' ?>
    <div class="pequeno-container single-product">
        <div class="row">
            <div class="col-2">
                <img src="<?php echo htmlspecialchars($produto['imagem_url']); ?>" id="ProductImg"
                    alt="<?php echo htmlspecialchars($produto['nome']); ?>">
                
                <div class="pequeno-img-row">
                    <div class="pequeno-img-col">
                        <img src="<?php echo htmlspecialchars($produto['imagem_url']); ?>" class="pequeno-img" alt="Vista principal"
                            onclick="mudarImagem(this.src)">
                    </div>
                    <?php foreach ($imagens_extras as $url_extra): ?>
                        <div class="pequeno-img-col">
                            <img src="<?php echo htmlspecialchars($url_extra); ?>" class="pequeno-img" alt="Vista extra"
                                onclick="mudarImagem(this.src)">
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="col-2">
                <p>Produtos / <?php echo htmlspecialchars($produto['categoria']); ?></p>
                <h1><?php echo htmlspecialchars($produto['nome']); ?></h1>
                <div class="avaliar">
                    <?php echo gerarEstrelas($produto['avaliacao_media']); ?>

                    <span class="nota-avaliacao">
                        (<?php echo number_format($produto['avaliacao_media'], 1, ',', '.'); ?>)
                    </span>
                </div>
                
                <h4>R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></h4>
                
                <form action="carrinho.php" method="post">
                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($produto_id); ?>">
                    
                    <select name="tamanho" required>
                        <option value="" disabled selected>Selecione o Tamanho</option>
                        <option value="P">P</option>
                        <option value="M">M</option>
                        <option value="G">G</option>
                        <option value="GG">GG</option>
                    </select>
                    
                    <input type="number" name="quantidade" value="1" min="1" required>
                    
                    <button type="submit" class="btn">Adicionar ao Carrinho</button>
                </form>
                
                <h3>Detalhes do Produto</h3>
                <br>
                <p><?php echo nl2br(htmlspecialchars($produto['descricao'])); ?></p>
            </div>
        </div>
    </div>

    <section class="em-alta" id="emalta">
        <div class="center-text">
            <h2>Produtos <span>Semelhantes</span></h2>
        </div>
        
        <div class="produtos">
            <?php foreach ($produtos_semelhantes as $similar_produto): ?>
                <div class="linha">
                    <a href="produto.php?id=<?php echo htmlspecialchars($similar_produto['id']); ?>">
                        <img src="<?php echo htmlspecialchars($similar_produto['imagem_url']); ?>" 
                             alt="<?php echo htmlspecialchars($similar_produto['nome']); ?>">
                    </a>
                    
                    <div class="product-text">
                        <a href="#"><i class='bx bx-heart coracao-icon'></i></a> 
                    </div>
                    
                    <div class="preco">
                        <a href="produto.php?id=<?php echo htmlspecialchars($similar_produto['id']); ?>">
                            <h4><?php echo htmlspecialchars($similar_produto['nome']); ?></h4>
                        </a>
                        <div class="avaliar">
                            <?php 
                            echo gerarEstrelas($similar_produto['avaliacao_media']); 
                            ?>
                        </div>
                        <p>R$ <?php echo number_format($similar_produto['preco'], 2, ',', '.'); ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <?php require_once 'footer.php' ?>

    <script>
        // Função para mudar a imagem principal ao rolar (Header)
        window.onscroll = function () {
            scrollFunction();
        };

        function scrollFunction() {
            var header = document.querySelector('header');
            if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        }
        
        // Função para trocar a imagem principal (Galeria de miniaturas)
        function mudarImagem(novaUrl) {
            document.getElementById("ProductImg").src = novaUrl;
        }

        // Adiciona um evento de clique para cada miniatura
        var SmallImg = document.getElementsByClassName("pequeno-img");
        for (let i = 0; i < SmallImg.length; i++) {
            SmallImg[i].onclick = function () {
                mudarImagem(this.src);
            };
        }
    </script>

</body>

</html>