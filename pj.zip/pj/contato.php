<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title>Contato</title>
    <link rel="stylesheet" href="_ADM/css/stylecontato.css">
    <link rel="stylesheet" href="_ADM/css/header-footer.css">
    <link rel="stylesheet"
    href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">

    <link rel="shortcut icon" href="_ADM/favicon.ico/favicon.ico" type="image/x-icon">
    <link rel="icon" href="_ADM/favicon.ico/favicon.ico" type="image/x-icon">
    <link rel="icon" type="image/png" sizes="32x32" href="_ADM/favicon.ico/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="32x32" href="_ADM/favicon.ico/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="_ADM/favicon.ico/favicon-16x16.png">

</head>
<body>
    <?php require_once 'header.php' ?>
    

    <section class="form-espaco">
            <form action="contato.php" method="post">
                <h1>Entre em contato</h1>
                <p>Preencher o formulário para realizar o contato</p>
                <div class="inputP">
                    <input type="text" name="nome" id="nome" class="input" required>
                    <label for="nome">Nome completo</label>
                 </div>

                 <div class="inputP">
                    <input type="text" name="email" id="email" class="input" required>
                    <label for="email">Email de contato</label>
                 </div>

                 <div class="inputP">
                    <input type="tel" name="telefone" id="telefone" class="input" required>
                    <label for="telefone">Telefone de contato</label>
                 </div>

                 <div class="inputP">
                    <input type="text" name="contato" id="contato" class="input" required>
                    <label for="contato">Motivo do contato</label>
                 </div>
                 

                 <div class="botao"><input type="submit" value="Enviar"></div>
            </form>

    </section>
    <script src="java.js"></script>

</body>
</html>