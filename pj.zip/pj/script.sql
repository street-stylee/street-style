-- ############################################################
-- SCRIPT DE CRIAÇÃO E INSERÇÃO DE DADOS PARA O BANCO 'testebe'
-- entre no C:\xampp\mysql\bin
-- ############################################################

-- Configuração inicial
CREATE DATABASE IF NOT EXISTS testebe;
USE testebe;

-- 1. Remoção de tabelas antigas (para garantir que a estrutura seja recriada limpa)
DROP TABLE IF EXISTS produto_imagens;
DROP TABLE IF EXISTS produtos;
DROP TABLE IF EXISTS cadastro;
DROP TABLE IF EXISTS tes;


-- 2. Criação da tabela 'cadastro'
CREATE TABLE `cadastro` (
  `ID` INT NOT NULL AUTO_INCREMENT,
  `NOME` VARCHAR(60) NOT NULL,
  `SOBRENOME` VARCHAR(60) NOT NULL,
  `EMAIL` VARCHAR(60) NOT NULL,
  `CPF` VARCHAR(20) NOT NULL,
  `RG` VARCHAR(20) NOT NULL,
  `SENHA` VARCHAR(60) NOT NULL,
  PRIMARY KEY (`ID`)
);

-- 3. Criação da tabela 'produtos' (Principal)
CREATE TABLE `produtos` (
  `id` INT(11) AUTO_INCREMENT PRIMARY KEY,
  `nome` VARCHAR(255) NOT NULL,
  `descricao` TEXT,
  `preco` DECIMAL(10,2) NOT NULL,
  `imagem_url` VARCHAR(255),
  `categoria` VARCHAR(50) NOT NULL,
  -- Coluna para a avaliação em decimal (ex: 4.5)
  `avaliacao_media` DECIMAL(2,1) NOT NULL DEFAULT 0.0
);

-- 4. Criação da tabela 'produto_imagens' (Imagens Secundárias/Miniaturas)
CREATE TABLE `produto_imagens` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `produto_id` INT NOT NULL,
  `imagem_url` VARCHAR(255) NOT NULL,
  -- Garante que ao apagar um produto, suas imagens também sejam apagadas
  FOREIGN KEY (`produto_id`) REFERENCES `produtos`(`id`) ON DELETE CASCADE
);

-- 5. Criação da tabela 'tes' (Teste - Mantida como estava)
CREATE TABLE `tes` (
  `idtes` INT UNSIGNED NOT NULL,
  `IDD` INT NOT NULL,
  PRIMARY KEY (`idtes`, `IDD`)
);

-- ############################################################
-- INSERÇÃO DE DADOS NA TABELA 'produtos' (PRODUTO PRINCIPAL)
-- ############################################################

INSERT INTO `produtos` (id, nome, descricao, preco, imagem_url, categoria, avaliacao_media) VALUES
-- Calças (ID 1-8, 34)
(1, 'Calça Jogger 3M', 'Modelagem padrão, tecido sarja, cintura em elástico e estampa refletiva', 179.90, '_ADM/img/roupas/calcas/calca-jogger-3m/1.webp', 'Calças', 4.8),
(2, 'Calça Jeans Azul', 'Modelagem padrão, tecido sarja, cintura em elástico e estampa refletiva', 189.90, '_ADM/img/roupas/calcas/calca-jeans-azul/1.webp', 'Calças', 4.0),
(3, 'Calça Jeans Escura', 'Tecido Jeans lavado em modelagem reta e larga. Material pesado e robusto com cintura em elástico para regulagem. Possuí costura curva na parte traseira e arte bordada no tornozelo', 199.90, '_ADM/img/roupas/calcas/calca-jeans-escura/1.webp', 'Calças', 5.0),
(4, 'Calça Suf 4-40 Vermelha', 'Feita em Nylon com recortes em Ripstop na região do joelho. Cintura em elástico e regulagem no tornozelo. Bolsos laterais com Zíper selado e emborrachado', 159.90, '_ADM/img/roupas/calcas/calca-suf-4-40-vermelha/1.webp', 'Calças', 3.5),
(5, 'Calça Patch Nylon', 'Feita em Nylon com modelagem reta. Patch emborrachado em velcro removível. Cintura em elástico e regulagem no tornozelo', 169.90, '_ADM/img/roupas/calcas/calca-patch-nylon/1.webp', 'Calças', 4.3),
(6, 'Calça Líquen', 'Tecido Brim grosso e robusto com modelagem reta. Cinto e mosquetão embutido. Produto com pigmentação própria Mad Enlatados', 209.90, '_ADM/img/roupas/calcas/calca-liquen/1.webp', 'Calças', 4.5),
(7, 'Calça Caqui Escuro', 'Modelagem padrão, tecido sarja, cintura em elástico e estampa refletiva', 179.90, '_ADM/img/roupas/calcas/calca-caqui-escuro/1.webp', 'Calças', 4.1),
(8, 'Calça Estonada', 'Feita em Denim preto com desenvolvimento de envelhecimento. Modelagem Wide com bolsos faca frontais e traseiros. Zíper YKK e reforço em rebite de latão niquelado.', 219.90, '_ADM/img/roupas/calcas/calca-estonada/1.webp', 'Calças', 4.7),
(34, 'Calça Dyer Stoned Preta', 'Feita em modelagem reta e ajustada em tecido robusto. Construída em tecido sarja pesado. Possui bolsos laterais tipo cargo e passadores de cinto e cordelete aplicado no cós como signo da marca.', 209.90, '_ADM/img/roupas/calcas/calca-dyer-stoned-preta/1.webp', 'Calças', 4.1),

-- Camisetas (ID 9-16, 35)
(9, 'Camiseta Lizard Amarela', 'Camiseta em modelagem média com tecido leve e confortável. Gola com 2cm e estampas em Silk de alta qualidade', 89.90, '_ADM/img/roupas/camisetas/camiseta-lizard-amarela/1.webp', 'Camisetas', 4.6),
(10, 'Camiseta Albatroz', 'Camiseta em modelagem média com tecido leve e confortável. Gola com 2cm e estampas em Silk de alta qualidade', 89.90, '_ADM/img/roupas/camisetas/camiseta-albatroz/1.webp', 'Camisetas', 3.9),
(11, 'Camiseta Pipa Verde', 'Camiseta em modelagem média com tecido leve e confortável. Gola com 2cm e estampas em Silk de alta qualidade', 89.90, '_ADM/img/roupas/camisetas/camiseta-pipa-verde/1.webp', 'Camisetas', 5.0),
(12, 'Manga Longa Strength Branca', 'Camiseta em modelagem média com tecido leve e confortável. Gola com 2cm e estampas em Silk de alta qualidade', 109.90, '_ADM/img/roupas/camisetas/manga-longa-strength-branca/1.webp', 'Camisetas', 4.4),
(13, 'Camiseta World Of Mine Preta', 'Camiseta com modelagem “quadrada”. Estampas em Silk de alta qualidade', 99.90, '_ADM/img/roupas/camisetas/camiseta-world-of-mine-preta/1.webp', 'Camisetas', 4.2), 
(14, 'Camiseta Name Logo Cinza', 'Tecido Robusto e espesso em modelagem quadrada com estampa frontal bordada.', 119.90, '_ADM/img/roupas/camisetas/camiseta-name-logo-cinza/1.webp', 'Camisetas', 4.0),
(15, 'Camiseta X-High Branca', 'Camiseta em modelagem média com tecido leve e confortável. Gola com 2cm e estampas em Silk de alta qualidade', 89.90, '_ADM/img/roupas/camisetas/camiseta-x-high-branca/1.webp', 'Camisetas', 4.7),
(16, 'Camiseta Freak Bege', 'Camiseta estonada com modelagem média em tecido leve e confortável. Estampas em SIlk.', 99.90, '_ADM/img/roupas/camisetas/camiseta-freak-bege/1.webp', 'Camisetas', 4.5),
(35, 'Camiseta Arqueologs Branca', 'Feita em modelagem Boxy em tecido robusto. Estampas em Silk e gola de 2,5cm.', 179.90, '_ADM/img/roupas/camisetas/camiseta-arqueologos-branca/1.webp', 'Camisetas', 3.5),

-- Conjuntos (ID 17)
(17, 'Conjunto Verão 2025', 'O melhor conjunto de roupa masculino para o seu verão!', 249.90, '_ADM/img/roupas/conjuntos/1.jpg', 'Conjuntos', 3.8),

-- Moletons (ID 18-25, 36)
(18, 'Suéter X-Ray', 'Suéter denso com alta gramatura e modelagem média. Estampa tramada no tecido', 229.90, '_ADM/img/roupas/moletons/sueter-x-ray/1.webp', 'Moletons', 5.0),
(19, 'Casaco Funghi', 'Tecido tipo Tricô pesado. Possuí abertura central com Zíper YKK. Modelagem média', 249.90, '_ADM/img/roupas/moletons/casaco-funghi/1.webp', 'Moletons', 4.2),
(20, 'Moletom Barra Textura Branco', 'Tecido tipo Tricô pesado. Possuí abertura central com Zíper YKK. Modelagem média', 259.90, '_ADM/img/roupas/moletons/moletom-barra-textura-branco/1.webp', 'Moletons', 4.6),
(21, 'Moletom Boêmios Branco', 'Tecido tipo Tricô pesado. Possuí abertura central com Zíper YKK. Modelagem média', 259.90, '_ADM/img/roupas/moletons/moletom-boemios-branco/1.webp', 'Moletons', 4.4),
(22, 'Suéter Zushi', 'Feito em suéter com modelagem ampla com tecido grosso e robusto. Estampa embutida no tecido', 239.90, '_ADM/img/roupas/moletons/sueter-zushi/1.webp', 'Moletons', 4.1),
(23, 'Moletom Falador Passa Mal', 'Tecido tipo Tricô pesado. Possuí abertura central com Zíper YKK. Modelagem média', 259.90, '_ADM/img/roupas/moletons/moletom-falador-passa-mal/1.webp', 'Moletons', 4.9),
(24, 'Casaco Trippy', 'Tecido Fleece estampado com Zíper duplo; Preenchimento em manta acrílica e forro acetinado', 299.90, '_ADM/img/roupas/moletons/casaco-trippy/1.webp', 'Moletons', 3.9),
(25, 'Moletom Goods Logo Preto', 'Tecido Fleece estampado com Zíper duplo; Preenchimento em manta acrílica e forro acetinado', 289.90, '_ADM/img/roupas/moletons/moletom-goods-logo-preto/1.webp', 'Moletons', 4.5),
(36, 'Tricô Mountain', 'Moletom de tricô “Mountain” da Carnan, com estampa em tons de cinza que remete a paisagens naturais. Modelagem confortável, gola careca e acabamento canelado nos punhos e barra, ideal para um visual urbano e estiloso nos dias frios.', 589.00, '_ADM/img/roupas/moletons/trico-mountain/1.webp', 'Moletons', 4.7),

-- Shorts (ID 26-33, 37)
(26, 'Shorts Layered Laranja', 'Shorts leve e confortável com modelagem média e curta. Possuí recortes coloridos em diferentes materiais e etiqueta emborracha lateral', 129.90, '_ADM/img/roupas/shorts/shorts-layered-laranja/1.webp', 'Shorts', 4.7),
(27, 'Shorts Kierk Jeans Preto', 'Shorts leve e confortável com modelagem média e curta. Possuí recortes coloridos em diferentes materiais e etiqueta emborracha lateral', 139.90, '_ADM/img/roupas/shorts/shorts-kierk-jeans-preto/1.webp', 'Shorts', 4.3),
(28, 'Short Hider Preto', 'Bermuda em tactel com cintura em elástico e cadarço para regulagem. Forro interno e detalhe curvo em outro tom', 119.90, '_ADM/img/roupas/shorts/short-hider-preto/1.webp', 'Shorts', 4.0),
(29, 'Bermuda Jeans', 'Tecido Jeans grosso e robusto com modelagem reta. Passadores de cinto e patch em couro traseiro. Recortes curvos em torno da peça', 159.90, '_ADM/img/roupas/shorts/bermuda-jeans/1.webp', 'Shorts', 4.6),
(30, 'Shorts Goods Logo', 'Tecido grosso e robusto com modelagem reta. Passadores de cinto e patch em couro traseiro. Recortes curvos em torno da peça', 149.90, '_ADM/img/roupas/shorts/shorts-goods-logo/1.webp', 'Shorts', 4.5),
(31, 'Bermuda Jeans Coração B', 'Tecido jeans grosso e robusto com modelagem reta. Passadores de cinto e patch em couro traseiro. Recortes curvos em torno da peça', 159.90, '_ADM/img/roupas/shorts/bermuda-jeans-coracao-b/1.webp', 'Shorts', 4.2),
(32, 'Shorts X-High Preto', 'Tecido grosso e robusto com modelagem reta. Passadores de cinto e patch em couro traseiro. Recortes curvos em torno da peça', 149.90, '_ADM/img/roupas/shorts/shorts-x-high-preto/1.webp', 'Shorts', 4.8),
(33, 'Shorts Kierk Verde', 'Tecido robusto e confortável com modelagem média. Zíper YKK frontal para alívio instantâneo, bolsos frontais e traseiros e porta moedas; Patch emborrachado', 139.90, '_ADM/img/roupas/shorts/shorts-kierk-verde/1.webp', 'Shorts', 4.4),
(37, 'Bermuda Tripla Preta', 'Feita em modelagem ampla em tecido robusto. Construída em tecido sarja pesado. Possui passadores de cinto e bolsos frontais e traseiros. Contém a simulação de duas samba-canção xadrez saindo de cima do cós.', 169.90, '_ADM/img/roupas/shorts/bermuda-tripla-preta/1.webp', 'Shorts', 3.8);


-- ############################################################
-- INSERÇÃO DE DADOS NA TABELA 'produto_imagens' (MINIATURAS CORRIGIDAS)
-- ############################################################

INSERT INTO `produto_imagens` (produto_id, imagem_url) VALUES 
-- Calças
(1, '_ADM/img/roupas/calcas/calca-jogger-3m/2.webp'), (1, '_ADM/img/roupas/calcas/calca-jogger-3m/3.webp'), (1, '_ADM/img/roupas/calcas/calca-jogger-3m/4.webp'),
(2, '_ADM/img/roupas/calcas/calca-jeans-azul/2.webp'), (2, '_ADM/img/roupas/calcas/calca-jeans-azul/3.webp'),
(3, '_ADM/img/roupas/calcas/calca-jeans-escura/2.webp'), (3, '_ADM/img/roupas/calcas/calca-jeans-escura/3.webp'),
(4, '_ADM/img/roupas/calcas/calca-suf-4-40-vermelha/2.webp'), (4, '_ADM/img/roupas/calcas/calca-suf-4-40-vermelha/3.webp'),
(5, '_ADM/img/roupas/calcas/calca-patch-nylon/2.webp'), (5, '_ADM/img/roupas/calcas/calca-patch-nylon/3.webp'), (5, '_ADM/img/roupas/calcas/calca-patch-nylon/4.webp'),
(6, '_ADM/img/roupas/calcas/calca-liquen/2.webp'), (6, '_ADM/img/roupas/calcas/calca-liquen/3.webp'),
(8, '_ADM/img/roupas/calcas/calca-estonada/2.webp'), (8, '_ADM/img/roupas/calcas/calca-estonada/3.webp'), (8, '_ADM/img/roupas/calcas/calca-estonada/4.webp'),
(34, '_ADM/img/roupas/calcas/calca-dyer-stoned-preta/2.webp'),

-- Camisetas (URLs corrigidas para evitar o bug de miniaturas)
(9, '_ADM/img/roupas/camisetas/camiseta-lizard-amarela/2.webp'),
(10, '_ADM/img/roupas/camisetas/camiseta-albatroz/2.webp'),
(11, '_ADM/img/roupas/camisetas/camiseta-pipa-verde/2.webp'),
(12, '_ADM/img/roupas/camisetas/manga-longa-strength-branca/2.webp'), 
(13, '_ADM/img/roupas/camisetas/camiseta-world-of-mine-preta/2.webp'), 
(13, '_ADM/img/roupas/camisetas/camiseta-world-of-mine-preta/3.webp'), -- Min. da World of Mine
(14, '_ADM/img/roupas/camisetas/camiseta-name-logo-cinza/2.webp'), 

(15, '_ADM/img/roupas/camisetas/camiseta-x-high-branca/2.webp'), (15, '_ADM/img/roupas/camisetas/camiseta-x-high-branca/3.webp'),
(35, '_ADM/img/roupas/camisetas/camiseta-arqueologos-branca/2.webp'),

-- Conjuntos
(17, '_ADM/img/roupas/conjuntos/2.jpg'), (17, '_ADM/img/roupas/conjuntos/3.jpg'), (17, '_ADM/img/roupas/conjuntos/4.jpg'),

-- Moletons
(18, '_ADM/img/roupas/moletons/sueter-x-ray/2.webp'),
(19, '_ADM/img/roupas/moletons/casaco-funghi/2.webp'), (19, '_ADM/img/roupas/moletons/casaco-funghi/3.webp'), (19, '_ADM/img/roupas/moletons/casaco-funghi/4.webp'),
(20, '_ADM/img/roupas/moletons/moletom-barra-textura-branco/2.webp'),
(21, '_ADM/img/roupas/moletons/moletom-boemios-branco/2.webp'),
(22, '_ADM/img/roupas/moletons/sueter-zushi/2.webp'),
(23, '_ADM/img/roupas/moletons/moletom-falador-passa-mal/2.webp'),
(24, '_ADM/img/roupas/moletons/casaco-trippy/2.webp'),
(36, '_ADM/img/roupas/moletons/trico-mountain/2.webp'), (36, '_ADM/img/roupas/moletons/trico-mountain/3.webp'),

-- Shorts
(26, '_ADM/img/roupas/shorts/shorts-layered-laranja/2.webp'), (26, '_ADM/img/roupas/shorts/shorts-layered-laranja/3.webp'), (26, '_ADM/img/roupas/shorts/shorts-layered-laranja/4.webp'),
(27, '_ADM/img/roupas/shorts/shorts-kierk-jeans-preto/2.webp'),
(28, '_ADM/img/roupas/shorts/short-hider-preto/2.webp'), (28, '_ADM/img/roupas/shorts/short-hider-preto/3.webp'),
(29, '_ADM/img/roupas/shorts/bermuda-jeans/2.webp'), (29, '_ADM/img/roupas/shorts/bermuda-jeans/3.webp'),
(30, '_ADM/img/roupas/shorts/shorts-goods-logo/2.webp'), (30, '_ADM/img/roupas/shorts/shorts-goods-logo/3.webp'),
(31, '_ADM/img/roupas/shorts/bermuda-jeans-coracao-b/2.webp'), (31, '_ADM/img/roupas/shorts/bermuda-jeans-coracao-b/3.webp'), (31, '_ADM/img/roupas/shorts/bermuda-jeans-coracao-b/4.webp'),
(32, '_ADM/img/roupas/shorts/shorts-x-high-preto/2.webp'), (32, '_ADM/img/roupas/shorts/shorts-x-high-preto/3.webp'), (32, '_ADM/img/roupas/shorts/shorts-x-high-preto/4.webp'),
(33, '_ADM/img/roupas/shorts/shorts-kierk-verde/2.webp'), (33, '_ADM/img/roupas/shorts/shorts-kierk-verde/3.webp'),
(37, '_ADM/img/roupas/shorts/bermuda-tripla-preta/2.webp'), (37, '_ADM/img/roupas/shorts/bermuda-tripla-preta/3.webp');

CREATE TABLE usuarios (
    id INT(11) PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
-- Adiciona a coluna 'cpf'
ALTER TABLE usuarios ADD COLUMN cpf VARCHAR(20);

-- Adiciona a coluna 'telefone'
ALTER TABLE usuarios ADD COLUMN telefone VARCHAR(20);

-- Adiciona a coluna 'endereco' (ou mude para TEXT se precisar de mais espaço)
ALTER TABLE usuarios ADD COLUMN endereco VARCHAR(255);

CREATE TABLE pedidos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    data_pedido DATETIME DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(50) DEFAULT 'Pendente',
    valor_total DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);
-- Adiciona a coluna 'total' à tabela 'pedidos'
ALTER TABLE pedidos ADD COLUMN total DECIMAL(10, 2) NOT NULL DEFAULT 0.00;
CREATE TABLE itens_pedido (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pedido_id INT NOT NULL,
    nome_produto VARCHAR(255) NOT NULL,
    quantidade INT NOT NULL,
    preco_unitario DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (pedido_id) REFERENCES pedidos(id)
);

