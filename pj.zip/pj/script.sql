-- ############################################################
-- SCRIPT DE CRIAÇÃO E INSERÇÃO DE DADOS PARA O BANCO 'testebe'
-- FINAL E CORRIGIDO
-- ############################################################

-- Configuração inicial
CREATE DATABASE IF NOT EXISTS testebe;
USE testebe;

-- 1. Remoção de tabelas antigas (para garantir que a estrutura seja recriada limpa)
DROP TABLE IF EXISTS carrinho_itens;
DROP TABLE IF EXISTS itens_pedido;
DROP TABLE IF EXISTS pedidos;
DROP TABLE IF EXISTS produto_variacoes;
DROP TABLE IF EXISTS produto_imagens;
DROP TABLE IF EXISTS produtos;
DROP TABLE IF EXISTS usuarios;
DROP TABLE IF EXISTS tes; -- Tabela 'tes' removida, pois não é essencial ao fluxo

-- 2. Criação da tabela 'usuarios'
CREATE TABLE `usuarios` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `nome` VARCHAR(100) NOT NULL,
    `email` VARCHAR(100) NOT NULL UNIQUE,
    `senha` VARCHAR(255) NOT NULL,
    `nivel_acesso` VARCHAR(20) NOT NULL DEFAULT 'cliente',
    `cpf` VARCHAR(20),
    `telefone` VARCHAR(20),
    `endereco` VARCHAR(255),
    `data_cadastro` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
);

-- 3. Criação da tabela 'produtos' (Principal)
CREATE TABLE `produtos` (
    `id` INT(11) AUTO_INCREMENT PRIMARY KEY,
    `nome` VARCHAR(255) NOT NULL,
    `descricao` TEXT,
    `preco` DECIMAL(10, 2) NOT NULL,
    `imagem_url` VARCHAR(255),
    `categoria` VARCHAR(50) NOT NULL,
    `avaliacao_media` DECIMAL(2, 1) NOT NULL DEFAULT 0.0
);

-- 4. Criação da tabela 'produto_imagens' (Imagens Secundárias/Miniaturas)
CREATE TABLE `produto_imagens` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `produto_id` INT NOT NULL,
    `imagem_url` VARCHAR(255) NOT NULL,
    FOREIGN KEY (`produto_id`) REFERENCES `produtos`(`id`) ON DELETE CASCADE
);

-- 5. Criação da tabela 'produto_variacoes' (CORRIGIDO)
CREATE TABLE produto_variacoes (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `produto_id` INT NOT NULL,
    `tamanho` VARCHAR(20) NOT NULL,
    `estoque` INT NOT NULL DEFAULT 0,
    FOREIGN KEY (`produto_id`) REFERENCES produtos(`id`) ON DELETE CASCADE,
    -- Restrição UNIQUE que causava o erro: Garante que cada produto só tenha um tamanho específico.
    UNIQUE KEY idx_variacao_unica_simples (produto_id, tamanho)
);

-- 6. Criação da tabela 'carrinho_itens' (CORRIGIDO E SIMPLIFICADO)
CREATE TABLE carrinho_itens (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `usuario_id` INT NULL,
    `carrinho_session_id` VARCHAR(255) NULL,
    `produto_id` INT NOT NULL,
    `variacao_id` INT NOT NULL, -- Variacao ID é obrigatório
    `quantidade` INT NOT NULL DEFAULT 1,
    `data_adicao` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (`usuario_id`) REFERENCES usuarios(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`produto_id`) REFERENCES produtos(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`variacao_id`) REFERENCES produto_variacoes(`id`) ON DELETE CASCADE,
    
    -- Chaves de unicidade essenciais para o fluxo de login/mesclagem:
    -- A) Garante que um usuário só tenha uma variação específica uma vez.
    UNIQUE KEY uk_user_variacao (usuario_id, variacao_id),
    -- B) Garante que uma sessão só tenha uma variação específica uma vez.
    UNIQUE KEY uk_session_variacao (carrinho_session_id, variacao_id)
);

-- 7. Tabela de Pedidos
CREATE TABLE pedidos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    data_pedido DATETIME DEFAULT CURRENT_TIMESTAMP,
    total_produtos DECIMAL(10, 2) NOT NULL,
    valor_frete DECIMAL(10, 2) NOT NULL,
    valor_desconto DECIMAL(10, 2) NOT NULL,
    total_geral DECIMAL(10, 2) NOT NULL,
    status VARCHAR(50) DEFAULT 'Pendente',
    metodo_pagamento VARCHAR(50) NOT NULL,
    endereco_completo TEXT,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- 8. Tabela de Itens do Pedido (CORRIGIDO)
CREATE TABLE itens_pedido (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pedido_id INT NOT NULL,
    produto_id INT, -- Permite NULL se o produto original for deletado
    nome_produto VARCHAR(255) NOT NULL,
    tamanho VARCHAR(10),
    quantidade INT NOT NULL,
    preco_unitario DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (pedido_id) REFERENCES pedidos(id) ON DELETE CASCADE,
    -- Correção: Se o produto for deletado, o ID na fatura deve ser SET NULL, mantendo o histórico de nome.
    FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE SET NULL
);

-- 9. Tabela 'tes' (Removida por não ser essencial)

-- ############################################################
-- INSERÇÃO DE DADOS INICIAIS
-- ############################################################

-- NOTA IMPORTANTE: Use o HASH da senha '123456' que você gerou.
INSERT INTO `usuarios` (
        `id`,
        `nome`,
        `email`,
        `senha`,
        `nivel_acesso`,
        `cpf`,
        `telefone`
    )
VALUES (
        1,
        'Admin Teste',
        'admin@streetstyle.com',
        '$2y$10$uGWwqhXYoBFTty1dYsPd1uszMj3uO2BVDbNNtUGqXQT/FEXbUHgIm',
        'admin',
        '12345678900',
        '11999999999'
    );
-- INSERÇÃO DE PRODUTOS
INSERT INTO `produtos` (
        id,
        nome,
        descricao,
        preco,
        imagem_url,
        categoria,
        avaliacao_media
    )
VALUES (
        1,
        'Calça Jogger 3M',
        'Modelagem padrão, tecido sarja, cintura em elástico e estampa refletiva',
        179.90,
        '_ADM/img/roupas/calcas/calca-jogger-3m/1.webp',
        'Calças',
        4.8
    ),
    (
        2,
        'Calça Jeans Azul',
        'Modelagem padrão, tecido sarja, cintura em elástico e estampa refletiva',
        189.90,
        '_ADM/img/roupas/calcas/calca-jeans-azul/1.webp',
        'Calças',
        4.0
    ),
    (
        3,
        'Calça Jeans Escura',
        'Tecido Jeans lavado em modelagem reta e larga. Material pesado e robusto com cintura em elástico para regulagem. Possuí costura curva na parte traseira e arte bordada no tornozelo',
        199.90,
        '_ADM/img/roupas/calcas/calca-jeans-escura/1.webp',
        'Calças',
        5.0
    ),
    (
        4,
        'Calça Suf 4-40 Vermelha',
        'Feita em Nylon com recortes em Ripstop na região do joelho. Cintura em elástico e regulagem no tornozelo. Bolsos laterais com Zíper selado e emborrachado',
        159.90,
        '_ADM/img/roupas/calcas/calca-suf-4-40-vermelha/1.webp',
        'Calças',
        3.5
    ),
    (
        5,
        'Calça Patch Nylon',
        'Feita em Nylon com modelagem reta. Patch emborrachado em velcro removível. Cintura em elástico e regulagem no tornozelo',
        169.90,
        '_ADM/img/roupas/calcas/calca-patch-nylon/1.webp',
        'Calças',
        4.3
    ),
    (
        6,
        'Calça Líquen',
        'Tecido Brim grosso e robusto com modelagem reta. Cinto e mosquetão embutido. Produto com pigmentação própria Mad Enlatados',
        209.90,
        '_ADM/img/roupas/calcas/calca-liquen/1.webp',
        'Calças',
        4.5
    ),
    (
        7,
        'Calça Caqui Escuro',
        'Modelagem padrão, tecido sarja, cintura em elástico e estampa refletiva',
        179.90,
        '_ADM/img/roupas/calcas/calca-caqui-escuro/1.webp',
        'Calças',
        4.1
    ),
    (
        8,
        'Calça Estonada',
        'Feita em Denim preto com desenvolvimento de envelhecimento. Modelagem Wide com bolsos faca frontais e traseiros. Zíper YKK e reforço em rebite de latão niquelado.',
        219.90,
        '_ADM/img/roupas/calcas/calca-estonada/1.webp',
        'Calças',
        4.7
    ),
    (
        34,
        'Calça Dyer Stoned Preta',
        'Feita em modelagem reta e ajustada em tecido robusto. Construída em tecido sarja pesado. Possui bolsos laterais tipo cargo e passadores de cinto e cordelete aplicado no cós como signo da marca.',
        209.90,
        '_ADM/img/roupas/calcas/calca-dyer-stoned-preta/1.webp',
        'Calças',
        4.1
    ),
    (
        9,
        'Camiseta Lizard Amarela',
        'Camiseta em modelagem média com tecido leve e confortável. Gola com 2cm e estampas em Silk de alta qualidade',
        89.90,
        '_ADM/img/roupas/camisetas/camiseta-lizard-amarela/1.webp',
        'Camisetas',
        4.6
    ),
    (
        10,
        'Camiseta Albatroz',
        'Camiseta em modelagem média com tecido leve e confortável. Gola com 2cm e estampas em Silk de alta qualidade',
        89.90,
        '_ADM/img/roupas/camisetas/camiseta-albatroz/1.webp',
        'Camisetas',
        3.9
    ),
    (
        11,
        'Camiseta Pipa Verde',
        'Camiseta em modelagem média com tecido leve e confortável. Gola com 2cm e estampas em Silk de alta qualidade',
        89.90,
        '_ADM/img/roupas/camisetas/camiseta-pipa-verde/1.webp',
        'Camisetas',
        5.0
    ),
    (
        12,
        'Manga Longa Strength Branca',
        'Camiseta em modelagem média com tecido leve e confortável. Gola com 2cm e estampas em Silk de alta qualidade',
        109.90,
        '_ADM/img/roupas/camisetas/manga-longa-strength-branca/1.webp',
        'Camisetas',
        4.4
    ),
    (
        13,
        'Camiseta World Of Mine Preta',
        'Camiseta com modelagem “quadrada”. Estampas em Silk de alta qualidade',
        99.90,
        '_ADM/img/roupas/camisetas/camiseta-world-of-mine-preta/1.webp',
        'Camisetas',
        4.2
    ),
    (
        14,
        'Camiseta Name Logo Cinza',
        'Tecido Robusto e espesso em modelagem quadrada com estampa frontal bordada.',
        119.90,
        '_ADM/img/roupas/camisetas/camiseta-name-logo-cinza/1.webp',
        'Camisetas',
        4.0
    ),
    (
        15,
        'Camiseta X-High Branca',
        'Camiseta em modelagem média com tecido leve e confortável. Gola com 2cm e estampas em Silk de alta qualidade',
        89.90,
        '_ADM/img/roupas/camisetas/camiseta-x-high-branca/1.webp',
        'Camisetas',
        4.7
    ),
    (
        16,
        'Camiseta Freak Bege',
        'Camiseta estonada com modelagem média em tecido leve e confortável. Estampas em SIlk.',
        99.90,
        '_ADM/img/roupas/camisetas/camiseta-freak-bege/1.webp',
        'Camisetas',
        4.5
    ),
    (
        35,
        'Camiseta Arqueologs Branca',
        'Feita em modelagem Boxy em tecido robusto. Estampas em Silk e gola de 2,5cm.',
        179.90,
        '_ADM/img/roupas/camisetas/camiseta-arqueologos-branca/1.webp',
        'Camisetas',
        3.5
    ),
    (
        17,
        'Conjunto Verão 2025',
        'O melhor conjunto de roupa masculino para o seu verão!',
        249.90,
        '_ADM/img/roupas/conjuntos/1.jpg',
        'Conjuntos',
        3.8
    ),
    (
        18,
        'Suéter X-Ray',
        'Suéter denso com alta gramatura e modelagem média. Estampa tramada no tecido',
        229.90,
        '_ADM/img/roupas/moletons/sueter-x-ray/1.webp',
        'Moletons',
        5.0
    ),
    (
        19,
        'Casaco Funghi',
        'Tecido tipo Tricô pesado. Possuí abertura central com Zíper YKK. Modelagem média',
        249.90,
        '_ADM/img/roupas/moletons/casaco-funghi/1.webp',
        'Moletons',
        4.2
    ),
    (
        20,
        'Moletom Barra Textura Branco',
        'Tecido tipo Tricô pesado. Possuí abertura central com Zíper YKK. Modelagem média',
        259.90,
        '_ADM/img/roupas/moletons/moletom-barra-textura-branco/1.webp',
        'Moletons',
        4.6
    ),
    (
        21,
        'Moletom Boêmios Branco',
        'Tecido tipo Tricô pesado. Possuí abertura central com Zíper YKK. Modelagem média',
        259.90,
        '_ADM/img/roupas/moletons/moletom-boemios-branco/1.webp',
        'Moletons',
        4.4
    ),
    (
        22,
        'Suéter Zushi',
        'Feito em suéter com modelagem ampla com tecido grosso e robusto. Estampa embutida no tecido',
        239.90,
        '_ADM/img/roupas/moletons/sueter-zushi/1.webp',
        'Moletons',
        4.1
    ),
    (
        23,
        'Moletom Falador Passa Mal',
        'Tecido tipo Tricô pesado. Possuí abertura central com Zíper YKK. Modelagem média',
        259.90,
        '_ADM/img/roupas/moletons/moletom-falador-passa-mal/1.webp',
        'Moletons',
        4.9
    ),
    (
        24,
        'Casaco Trippy',
        'Tecido Fleece estampado com Zíper duplo; Preenchimento em manta acrílica e forro acetinado',
        299.90,
        '_ADM/img/roupas/moletons/casaco-trippy/1.webp',
        'Moletons',
        3.9
    ),
    (
        25,
        'Moletom Goods Logo Preto',
        'Tecido Fleece estampado com Zíper duplo; Preenchimento em manta acrílica e forro acetinado',
        289.90,
        '_ADM/img/roupas/moletons/moletom-goods-logo-preto/1.webp',
        'Moletons',
        4.5
    ),
    (
        36,
        'Tricô Mountain',
        'Moletom de tricô “Mountain” da Carnan, com estampa em tons de cinza que remete a paisagens naturais. Modelagem confortável, gola careca e acabamento canelado nos punhos e barra, ideal para um visual urbano e estiloso nos dias frios.',
        589.00,
        '_ADM/img/roupas/moletons/trico-mountain/1.webp',
        'Moletons',
        4.7
    ),
    (
        26,
        'Shorts Layered Laranja',
        'Shorts leve e confortável com modelagem média e curta. Possuí recortes coloridos em diferentes materiais e etiqueta emborracha lateral',
        129.90,
        '_ADM/img/roupas/shorts/shorts-layered-laranja/1.webp',
        'Shorts',
        4.7
    ),
    (
        27,
        'Shorts Kierk Jeans Preto',
        'Shorts leve e confortável com modelagem média e curta. Possuí recortes coloridos em diferentes materiais e etiqueta emborracha lateral',
        139.90,
        '_ADM/img/roupas/shorts/shorts-kierk-jeans-preto/1.webp',
        'Shorts',
        4.3
    ),
    (
        28,
        'Short Hider Preto',
        'Bermuda em tactel com cintura em elástico e cadarço para regulagem. Forro interno e detalhe curvo em outro tom',
        119.90,
        '_ADM/img/roupas/shorts/short-hider-preto/1.webp',
        'Shorts',
        4.0
    ),
    (
        29,
        'Bermuda Jeans',
        'Tecido Jeans grosso e robusto com modelagem reta. Passadores de cinto e patch em couro traseiro. Recortes curvos em torno da peça',
        159.90,
        '_ADM/ADM/img/roupas/shorts/bermuda-jeans/1.webp',
        'Shorts',
        4.6
    ),
    (
        30,
        'Shorts Goods Logo',
        'Tecido grosso e robusto com modelagem reta. Passadores de cinto e patch em couro traseiro. Recortes curvos em torno da peça',
        149.90,
        '_ADM/img/roupas/shorts/shorts-goods-logo/1.webp',
        'Shorts',
        4.5
    ),
    (
        31,
        'Bermuda Jeans Coração B',
        'Tecido jeans grosso e robusto com modelagem reta. Passadores de cinto e patch em couro traseiro. Recortes curvos em torno da peça',
        159.90,
        '_ADM/img/roupas/shorts/bermuda-jeans-coracao-b/1.webp',
        'Shorts',
        4.2
    ),
    (
        32,
        'Shorts X-High Preto',
        'Tecido grosso e robusto com modelagem reta. Passadores de cinto e patch em couro traseiro. Recortes curvos em torno da peça',
        149.90,
        '_ADM/img/roupas/shorts/shorts-x-high-preto/1.webp',
        'Shorts',
        4.8
    ),
    (
        33,
        'Shorts Kierk Verde',
        'Tecido robusto e confortável com modelagem média. Zíper YKK frontal para alívio instantâneo, bolsos frontais e traseiros e porta moedas; Patch emborrachado',
        139.90,
        '_ADM/img/roupas/shorts/shorts-kierk-verde/1.webp',
        'Shorts',
        4.4
    ),
    (
        37,
        'Bermuda Tripla Preta',
        'Feita em modelagem ampla em tecido robusto. Construída em tecido sarja pesado. Possui passadores de cinto e bolsos frontais e traseiros. Contém a simulação de duas samba-canção xadrez saindo de cima do cós.',
        169.90,
        '_ADM/img/roupas/shorts/bermuda-tripla-preta/1.webp',
        'Shorts',
        3.8
    );
-- INSERÇÃO DE PRODUTO_IMAGENS
INSERT INTO `produto_imagens` (produto_id, imagem_url)
VALUES (
        1,
        '_ADM/img/roupas/calcas/calca-jogger-3m/2.webp'
    ),
    (
        1,
        '_ADM/img/roupas/calcas/calca-jogger-3m/3.webp'
    ),
    (
        1,
        '_ADM/img/roupas/calcas/calca-jogger-3m/4.webp'
    ),
    (
        2,
        '_ADM/img/roupas/calcas/calca-jeans-azul/2.webp'
    ),
    (
        2,
        '_ADM/img/roupas/calcas/calca-jeans-azul/3.webp'
    ),
    (
        3,
        '_ADM/img/roupas/calcas/calca-jeans-escura/2.webp'
    ),
    (
        3,
        '_ADM/img/roupas/calcas/calca-jeans-escura/3.webp'
    ),
    (
        4,
        '_ADM/img/roupas/calcas/calca-suf-4-40-vermelha/2.webp'
    ),
    (
        4,
        '_ADM/img/roupas/calcas/calca-suf-4-40-vermelha/3.webp'
    ),
    (
        5,
        '_ADM/img/roupas/calcas/calca-patch-nylon/2.webp'
    ),
    (
        5,
        '_ADM/img/roupas/calcas/calca-patch-nylon/3.webp'
    ),
    (
        5,
        '_ADM/img/roupas/calcas/calca-patch-nylon/4.webp'
    ),
    (6, '_ADM/img/roupas/calcas/calca-liquen/2.webp'),
    (6, '_ADM/img/roupas/calcas/calca-liquen/3.webp'),
    (
        8,
        '_ADM/img/roupas/calcas/calca-estonada/2.webp'
    ),
    (
        8,
        '_ADM/img/roupas/calcas/calca-estonada/3.webp'
    ),
    (
        8,
        '_ADM/img/roupas/calcas/calca-estonada/4.webp'
    ),
    (
        34,
        '_ADM/img/roupas/calcas/calca-dyer-stoned-preta/2.webp'
    ),
    (
        9,
        '_ADM/img/roupas/camisetas/camiseta-lizard-amarela/2.webp'
    ),
    (
        10,
        '_ADM/img/roupas/camisetas/camiseta-albatroz/2.webp'
    ),
    (
        11,
        '_ADM/img/roupas/camisetas/camiseta-pipa-verde/2.webp'
    ),
    (
        12,
        '_ADM/img/roupas/camisetas/manga-longa-strength-branca/2.webp'
    ),
    (
        13,
        '_ADM/img/roupas/camisetas/camiseta-world-of-mine-preta/2.webp'
    ),
    (
        13,
        '_ADM/img/roupas/camisetas/camiseta-world-of-mine-preta/3.webp'
    ),
    (
        14,
        '_ADM/img/roupas/camisetas/camiseta-name-logo-cinza/2.webp'
    ),
    (
        15,
        '_ADM/img/roupas/camisetas/camiseta-x-high-branca/2.webp'
    ),
    (
        15,
        '_ADM/img/roupas/camisetas/camiseta-x-high-branca/3.webp'
    ),
    (
        35,
        '_ADM/img/roupas/camisetas/camiseta-arqueologos-branca/2.webp'
    ),
    (17, '_ADM/img/roupas/conjuntos/2.jpg'),
    (17, '_ADM/img/roupas/conjuntos/3.jpg'),
    (17, '_ADM/img/roupas/conjuntos/4.jpg'),
    (
        18,
        '_ADM/img/roupas/moletons/sueter-x-ray/2.webp'
    ),
    (
        19,
        '_ADM/img/roupas/moletons/casaco-funghi/2.webp'
    ),
    (
        19,
        '_ADM/img/roupas/moletons/casaco-funghi/3.webp'
    ),
    (
        19,
        '_ADM/img/roupas/moletons/casaco-funghi/4.webp'
    ),
    (
        20,
        '_ADM/img/roupas/moletons/moletom-barra-textura-branco/2.webp'
    ),
    (
        21,
        '_ADM/img/roupas/moletons/moletom-boemios-branco/2.webp'
    ),
    (
        21,
        '_ADM/img/roupas/moletons/moletom-boemios-branco/3.webp'
    ),
    (
        22,
        '_ADM/img/roupas/moletons/sueter-zushi/2.webp'
    ),
    (
        23,
        '_ADM/img/roupas/moletons/moletom-falador-passa-mal/2.webp'
    ),
    (
        24,
        '_ADM/img/roupas/moletons/casaco-trippy/2.webp'
    ),
    (
        36,
        '_ADM/img/roupas/moletons/trico-mountain/2.webp'
    ),
    (
        36,
        '_ADM/img/roupas/moletons/trico-mountain/3.webp'
    ),
    (
        26,
        '_ADM/img/roupas/shorts/shorts-layered-laranja/2.webp'
    ),
    (
        26,
        '_ADM/img/roupas/shorts/shorts-layered-laranja/3.webp'
    ),
    (
        26,
        '_ADM/img/roupas/shorts/shorts-layered-laranja/4.webp'
    ),
    (
        27,
        '_ADM/img/roupas/shorts/shorts-kierk-jeans-preto/2.webp'
    ),
    (
        28,
        '_ADM/img/roupas/shorts/short-hider-preto/2.webp'
    ),
    (
        28,
        '_ADM/img/roupas/shorts/short-hider-preto/3.webp'
    ),
    (
        29,
        '_ADM/img/roupas/shorts/bermuda-jeans/2.webp'
    ),
    (
        29,
        '_ADM/img/roupas/shorts/bermuda-jeans/3.webp'
    ),
    (
        30,
        '_ADM/img/roupas/shorts/shorts-goods-logo/2.webp'
    ),
    (
        30,
        '_ADM/img/roupas/shorts/shorts-goods-logo/3.webp'
    ),
    (
        31,
        '_ADM/img/roupas/shorts/bermuda-jeans-coracao-b/2.webp'
    ),
    (
        31,
        '_ADM/img/roupas/shorts/bermuda-jeans-coracao-b/3.webp'
    ),
    (
        31,
        '_ADM/img/roupas/shorts/bermuda-jeans-coracao-b/4.webp'
    ),
    (
        32,
        '_ADM/img/roupas/shorts/shorts-x-high-preto/2.webp'
    ),
    (
        32,
        '_ADM/img/roupas/shorts/shorts-x-high-preto/3.webp'
    ),
    (
        32,
        '_ADM/img/roupas/shorts/shorts-x-high-preto/4.webp'
    ),
    (
        33,
        '_ADM/img/roupas/shorts/shorts-kierk-verde/2.webp'
    ),
    (
        33,
        '_ADM/img/roupas/shorts/shorts-kierk-verde/3.webp'
    ),
    (
        37,
        '_ADM/img/roupas/shorts/bermuda-tripla-preta/2.webp'
    ),
    (
        37,
        '_ADM/img/roupas/shorts/bermuda-tripla-preta/3.webp'
    );

-- ############################################################
-- INSERÇÃO DE VARIAÇÕES INICIAIS (TODOS OS PRODUTOS) - CORRIGIDA
-- ############################################################
INSERT INTO `produto_variacoes` (produto_id, tamanho, estoque)
VALUES -- Calças (IDs 1-8, 34) - P, M, G, GG
    (1, 'P', 10),
    (1, 'M', 15),
    (1, 'G', 8),
    (1, 'GG', 5),
    (2, 'P', 5),
    (2, 'M', 10),
    (2, 'G', 15),
    (2, 'GG', 7),
    (3, 'P', 12),
    (3, 'M', 10),
    (3, 'G', 9),
    (3, 'GG', 3),
    (4, 'P', 8),
    (4, 'M', 11),
    (4, 'G', 6),
    (4, 'GG', 4),
    (5, 'P', 7),
    (5, 'M', 13),
    (5, 'G', 10),
    (5, 'GG', 6),
    (6, 'P', 10),
    (6, 'M', 15),
    (6, 'G', 12),
    (6, 'GG', 5),
    (7, 'P', 9),
    (7, 'M', 14),
    (7, 'G', 11),
    (7, 'GG', 7),
    (8, 'P', 6),
    (8, 'M', 10),
    (8, 'G', 9),
    (8, 'GG', 3),
    (34, 'P', 11),
    (34, 'M', 16),
    (34, 'G', 8),
    (34, 'GG', 4),
    -- Camisetas (IDs 9-16, 35) - P, M, G, GG
    (9, 'P', 5),
    (9, 'M', 10),
    (9, 'G', 15),
    (9, 'GG', 8),
    (10, 'P', 10),
    (10, 'M', 14),
    (10, 'G', 11),
    (10, 'GG', 5),
    (11, 'P', 7),
    (11, 'M', 12),
    (11, 'G', 10),
    (11, 'GG', 6),
    (12, 'P', 10),
    (12, 'M', 15),
    (12, 'G', 10),
    (12, 'GG', 7),
    (13, 'P', 8),
    (13, 'M', 13),
    (13, 'G', 9),
    (13, 'GG', 4),
    (14, 'P', 6),
    (14, 'M', 11),
    (14, 'G', 12),
    (14, 'GG', 5),
    (15, 'P', 10),
    (15, 'M', 15),
    (15, 'G', 13),
    (15, 'GG', 8),
    (16, 'P', 9),
    (16, 'M', 14),
    (16, 'G', 10),
    (16, 'GG', 6),
    (35, 'P', 12),
    (35, 'M', 16),
    (35, 'G', 11),
    (35, 'GG', 7),
    -- Conjuntos (ID 17) - P, M, G, GG
    (17, 'P', 5),
    (17, 'M', 9),
    (17, 'G', 6),
    (17, 'GG', 3),
    -- Moletons (IDs 18-25, 36) - P, M, G, GG
    (18, 'P', 10),
    (18, 'M', 15),
    (18, 'G', 12),
    (18, 'GG', 7),
    (19, 'P', 6),
    (19, 'M', 10),
    (19, 'G', 8),
    (19, 'GG', 5),
    (20, 'P', 7),
    (20, 'M', 11),
    (20, 'G', 9),
    (20, 'GG', 6),
    (21, 'P', 7),
    (21, 'M', 12),
    (21, 'G', 10),
    (21, 'GG', 4),
    (22, 'P', 8),
    (22, 'M', 13),
    (22, 'G', 11),
    (22, 'GG', 5),
    (23, 'P', 9),
    (23, 'M', 14),
    (23, 'G', 10),
    (23, 'GG', 6),
    (24, 'P', 5),
    (24, 'M', 9),
    (24, 'G', 7),
    (24, 'GG', 4),
    (25, 'P', 6),
    (25, 'M', 10),
    (25, 'G', 8),
    (25, 'GG', 5),
    (36, 'P', 4),
    (36, 'M', 7),
    (36, 'G', 5),
    (36, 'GG', 3),
    -- Shorts (IDs 26-33, 37) - P, M, G, GG
    (26, 'P', 10),
    (26, 'M', 15),
    (26, 'G', 12),
    (26, 'GG', 8),
    (27, 'P', 8),
    (27, 'M', 13),
    (27, 'G', 10),
    (27, 'GG', 6),
    (28, 'P', 9),
    (28, 'M', 14),
    (28, 'G', 11),
    (28, 'GG', 7),
    (29, 'P', 7),
    (29, 'M', 12),
    (29, 'G', 9),
    (29, 'GG', 5),
    (30, 'P', 11),
    (30, 'M', 16),
    (30, 'G', 13),
    (30, 'GG', 9),
    (31, 'P', 6),
    (31, 'M', 10),
    (31, 'G', 8),
    (31, 'GG', 4),
    (32, 'P', 10),
    (32, 'M', 15),
    (32, 'G', 12),
    (32, 'GG', 7),
    (33, 'P', 9),
    (33, 'M', 14),
    (33, 'G', 11),
    (33, 'GG', 6),
    (37, 'P', 7),
    (37, 'M', 12),
    (37, 'G', 9),
    (37, 'GG', 5);