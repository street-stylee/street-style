<?php
require_once 'formu.php';
@session_start();

// Redireciona se não houver um ID de pedido
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: perfil.php');
    exit;
}

$pedido_id = (int)$_GET['id'];
$usuario_id = $_SESSION['usuario_id'] ?? 0;
$dados_pedido = null;
$itens_pedido = [];

// 1. Conexão e Busca do Pedido (Segurança: Garante que o usuário só veja seus pedidos)
if ($usuario_id > 0) {
    
    // Consulta para buscar os dados gerais do pedido
    $sql_pedido = "SELECT * FROM pedidos WHERE id = ? AND usuario_id = ?";
    $stmt_pedido = $conexao->prepare($sql_pedido);
    if ($stmt_pedido) {
        $stmt_pedido->bind_param("ii", $pedido_id, $usuario_id);
        $stmt_pedido->execute();
        $resultado_pedido = $stmt_pedido->get_result();
        $dados_pedido = $resultado_pedido->fetch_assoc();
        $stmt_pedido->close();
    }

    // Consulta para buscar os itens do pedido
    $sql_itens = "SELECT ip.*, p.nome, p.imagem_url 
                  FROM itens_pedido ip 
                  JOIN produtos p ON ip.produto_id = p.id
                  WHERE ip.pedido_id = ?";
    $stmt_itens = $conexao->prepare($sql_itens);
    if ($stmt_itens) {
        $stmt_itens->bind_param("i", $pedido_id);
        $stmt_itens->execute();
        $resultado_itens = $stmt_itens->get_result();
        while ($item = $resultado_itens->fetch_assoc()) {
            $itens_pedido[] = $item;
        }
        $stmt_itens->close();
    }
}

// Se o pedido não for encontrado ou não pertencer ao usuário
if (!$dados_pedido) {
    header('Location: perfil.php');
    exit;
}

// Fechamento da conexão
if (isset($conexao) && $conexao->ping()) {
    $conexao->close();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pedido Concluído #<?php echo $pedido_id; ?></title>
    <link rel="stylesheet" href="_ADM/css/header-footer.css">
    <link rel="stylesheet" href="_ADM/css/estilo_checkout.css">
    <link rel="stylesheet" href="_ADM/css/footer.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <style>
  /* ==================================== */
/* ESTILOS PARA PEDIDO CONCLUÍDO (SUCESSO) */
/* ==================================== */

/* Definições de Variáveis (Ajuste se o seu tema usa outras cores) */
:root {
    --cor-sucesso: #27ae60; /* Verde principal */
    --cor-sucesso-claro: #f6fff9; /* Fundo suave */
    --cor-principal: #333; /* Cor de texto principal */
    --cor-secundaria: #555; /* Cor de texto secundária */
    --cor-borda: #ddd;
    --cor-sombra-leve: rgba(0, 0, 0, 0.08);
}

.sucesso-container {
    max-width: 700px; /* Levemente menor para focar no conteúdo */
    margin: 150px auto 50px;
    padding: 30px 40px; /* Padding maior nas laterais */
    text-align: center;
    
    /* Estilo do Card Principal */
    border: 1px solid var(--cor-sucesso); /* Borda mais discreta */
    border-radius: 12px;
    background-color: #fff; /* Fundo branco */
    box-shadow: 0 10px 30px var(--cor-sombra-leve); /* Sombra mais destacada */
}

.sucesso-container .bx-check-circle {
    font-size: 5rem; /* Ícone maior */
    color: var(--cor-sucesso);
    margin-bottom: 15px;
    display: block; /* Para garantir que o margin funcione */
    animation: bounceIn 0.8s ease-out; /* Adiciona uma pequena animação de entrada */
}

.sucesso-container h1 {
    color: var(--cor-sucesso);
    font-size: 2.2rem;
    font-weight: 700;
    margin-bottom: 15px;
}

.sucesso-container p {
    font-size: 1rem;
    color: var(--cor-secundaria);
    line-height: 1.6;
    margin-bottom: 10px;
}

/* ------------------ */
/* BOTÕES DE AÇÃO */
/* ------------------ */
.sucesso-container .btn-concluir-compra { /* Usado para "Ver Meus Pedidos" */
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background-color: var(--cor-sucesso);
    color: #fff;
    border: none;
    border-radius: 8px;
    padding: 12px 25px;
    font-size: 1rem;
    font-weight: 600;
    text-transform: uppercase;
    text-decoration: none;
    cursor: pointer;
    transition: background-color 0.3s, transform 0.1s;
    margin: 25px 15px 30px 0; /* Espaçamento entre botões */
}

.sucesso-container .btn-concluir-compra:hover {
    background-color: #1e8449; /* Verde mais escuro no hover */
    transform: translateY(-1px);
}

.sucesso-container .btn-concluir-compra i {
    margin-right: 8px;
    font-size: 1.1rem;
}

.sucesso-container .btn-cancelar { /* Usado para "Continuar Comprando" */
    background: #f1f1f1;
    color: var(--cor-principal);
    border: 1px solid var(--cor-borda);
    padding: 12px 25px;
    border-radius: 8px;
    font-size: 1rem;
    font-weight: 600;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    transition: background-color 0.3s;
}

.sucesso-container .btn-cancelar:hover {
    background: #e9e9e9;
}

.sucesso-container .btn-cancelar i {
    margin-right: 8px;
    font-size: 1.1rem;
}


/* ------------------ */
/* DETALHES DO PEDIDO */
/* ------------------ */
.resumo-pedido {
    text-align: left;
    border-top: 1px solid var(--cor-borda);
    padding-top: 25px;
    margin-top: 25px;
    background-color: var(--cor-sucesso-claro); /* Fundo suave para a seção de detalhes */
    padding: 20px;
    border-radius: 8px;
}

.resumo-pedido h3 {
    margin-bottom: 15px;
    color: var(--cor-principal);
    font-size: 1.2rem;
    border-left: 4px solid var(--cor-sucesso); /* Detalhe lateral */
    padding-left: 10px;
}

.resumo-pedido p {
    margin: 8px 0;
    font-size: 0.95rem;
    color: var(--cor-secundaria);
    padding-left: 15px;
}

.resumo-pedido strong {
    color: var(--cor-principal);
    font-weight: 600;
}

/* Animação para o ícone de check */
@keyframes bounceIn {
    0% {
        opacity: 0;
        transform: scale(0.3);
    }
    50% {
        opacity: 1;
        transform: scale(1.1);
    }
    70% {
        transform: scale(0.9);
    }
    100% {
        transform: scale(1);
    }
}
    </style>
</head>
<body>
    <?php require_once 'header.php' ?>

    <div class="sucesso-container">
        <i class='bx bxs-check-circle'></i>
        <h1>Pedido Concluído!</h1>
        <p>Obrigado pela sua compra. O número do seu pedido é **#<?php echo $pedido_id; ?>**.</p>
        <p>Você receberá um e-mail de confirmação em breve e pode acompanhar o status na seção "Meus Pedidos".</p>

        <a href="pedidos.php" class="btn-concluir-compra" style="margin-right: 15px;">
            <i class="bx bxs-package"></i> Ver Meus Pedidos
        </a>
        <a href="index.php" class="btn-cancelar">
            <i class="bx bx-home"></i> Continuar Comprando
        </a>
        
<div class="resumo-pedido">
    <h3>Detalhes do Pedido #<?php echo $pedido_id; ?></h3>
    <p><strong>Total Pago:</strong> R$ <?php echo number_format($dados_pedido['total_geral'], 2, ',', '.'); ?></p>
    <p><strong>Endereço de Entrega:</strong> <?php echo html_entity_decode(htmlspecialchars($dados_pedido['endereco_completo'])); ?></p>
</div>
    </div>

    <?php require_once 'footer.php' ?>
</body>
</html>