<?php
// carrinho.php (SCRIPT PROCESSADOR - Ações via GET e POST)
// =======================================================

session_start();
require_once 'formu.php'; // Inclui a conexão com o banco de dados

// =======================================================
// BLOCO DE MIGRAÇÃO DE CARRINHO (Visitante -> Usuário Logado)
// ESTE BLOCO É EXECUTADO SEMPRE QUE UM USUÁRIO RECÉM-LOGADO 
// ACESSA QUALQUER PÁGINA QUE CHAME ESTE PROCESSADOR.
// =======================================================
if (isset($_SESSION['usuario_id']) && isset($_SESSION['carrinho_session_id'])) {
    $usuario_id = $_SESSION['usuario_id'];
    $session_id_antiga = $_SESSION['carrinho_session_id'];

    $conexao->begin_transaction();
    try {
        // SQL 1: Se o usuário logado JÁ tinha o item (variacao_id), remove a versão do visitante
        // Isso previne duplicatas e prepara a migração
        $sql_delete_duplicates = "
            DELETE CI_SESSION FROM carrinho_itens CI_SESSION
            INNER JOIN carrinho_itens CI_USER ON 
                CI_SESSION.variacao_id = CI_USER.variacao_id AND CI_USER.usuario_id = ?
            WHERE CI_SESSION.carrinho_session_id = ? AND CI_SESSION.usuario_id IS NULL;
        ";
        $stmt_delete = $conexao->prepare($sql_delete_duplicates);
        $stmt_delete->bind_param("is", $usuario_id, $session_id_antiga);
        $stmt_delete->execute();
        $stmt_delete->close();

        // SQL 2: Migra os itens restantes do carrinho de sessão para o ID do usuário
        $sql_migrate = "
            UPDATE carrinho_itens 
            SET usuario_id = ?, carrinho_session_id = NULL 
            WHERE carrinho_session_id = ? AND usuario_id IS NULL;
        ";
        $stmt_migrate = $conexao->prepare($sql_migrate);
        $stmt_migrate->bind_param("is", $usuario_id, $session_id_antiga);
        $stmt_migrate->execute();
        $stmt_migrate->close();

        $conexao->commit();

        // 3. Remove o ID de sessão para que a migração não ocorra novamente
        unset($_SESSION['carrinho_session_id']);

    } catch (Exception $e) {
        $conexao->rollback();
        // Em um ambiente de produção, registre $e->getMessage() em um log
    }
}
// =======================================================


// 2. Define o ID de referência do carrinho
if (!isset($_SESSION['usuario_id']) && !isset($_SESSION['carrinho_session_id'])) {
    $_SESSION['carrinho_session_id'] = session_id();
}
$carrinho_ref_id = $_SESSION['usuario_id'] ?? $_SESSION['carrinho_session_id'];
$is_user = isset($_SESSION['usuario_id']);
$redirecionar_para = 'carrinho_visualizar.php'; // Página de destino

// ----------------------------------------------------
// AÇÕES VIA GET (Excluir, Limpar, Aumentar, Diminuir)
// ... (Seu código de ações GET continua aqui, pois ele já estava funcional) ...
// ----------------------------------------------------
if (isset($_GET['acao'])) {
    $acao = $_GET['acao'];
    $item_id = filter_input(INPUT_GET, 'item_id', FILTER_VALIDATE_INT);

    if ($acao === 'limpar') {
        $sql = "DELETE FROM carrinho_itens WHERE " . ($is_user ? "usuario_id = ?" : "carrinho_session_id = ?");
        $stmt = $conexao->prepare($sql);
        if ($is_user) {
            $stmt->bind_param("i", $carrinho_ref_id);
        } else {
            $stmt->bind_param("s", $carrinho_ref_id);
        }
        $stmt->execute();
        $stmt->close();
        header('Location: ' . $redirecionar_para);
        exit;
    }

    if ($item_id) {
        $conexao->begin_transaction();
        $sucesso = true;

        try {
            if ($acao === 'excluir') {
                $sql = "DELETE FROM carrinho_itens WHERE id = ?";
                $stmt = $conexao->prepare($sql);
                $stmt->bind_param("i", $item_id);
                if (!$stmt->execute())
                    $sucesso = false;
                $stmt->close();
            } elseif ($acao === 'diminuir' || $acao === 'aumentar') {
                $sql_select = "SELECT quantidade, variacao_id FROM carrinho_itens WHERE id = ?";
                $stmt_select = $conexao->prepare($sql_select);
                $stmt_select->bind_param("i", $item_id);
                $stmt_select->execute();
                $item = $stmt_select->get_result()->fetch_assoc();
                $stmt_select->close();

                if ($item) {
                    $variacao_id = $item['variacao_id'];
                    $nova_quantidade = $item['quantidade'] + ($acao === 'aumentar' ? 1 : -1);

                    if ($nova_quantidade < 1) {
                        $sql = "DELETE FROM carrinho_itens WHERE id = ?";
                        $stmt = $conexao->prepare($sql);
                        $stmt->bind_param("i", $item_id);
                        if (!$stmt->execute())
                            $sucesso = false;
                        $stmt->close();
                    } else {
                        if ($acao === 'aumentar') {
                            $sql_estoque = "SELECT estoque FROM produto_variacoes WHERE id = ?";
                            $stmt_estoque = $conexao->prepare($sql_estoque);
                            $stmt_estoque->bind_param("i", $variacao_id);
                            $stmt_estoque->execute();
                            $estoque_disponivel = $stmt_estoque->get_result()->fetch_column();
                            $stmt_estoque->close();

                            if ($nova_quantidade > $estoque_disponivel) {
                                $conexao->rollback();
                                header('Location: ' . $redirecionar_para . '?status=error_estoque_aumento');
                                exit;
                            }
                        }
                        $sql = "UPDATE carrinho_itens SET quantidade = ? WHERE id = ?";
                        $stmt = $conexao->prepare($sql);
                        $stmt->bind_param("ii", $nova_quantidade, $item_id);
                        if (!$stmt->execute())
                            $sucesso = false;
                        $stmt->close();
                    }
                }
            }

            if ($sucesso) {
                $conexao->commit();
                header('Location: ' . $redirecionar_para);
            } else {
                $conexao->rollback();
                header('Location: ' . $redirecionar_para . '?status=error_db');
            }

        } catch (Exception $e) {
            $conexao->rollback();
            header('Location: ' . $redirecionar_para . '?status=error_db_exception');
        }

        exit;
    }
}


// ----------------------------------------------------
// AÇÃO VIA POST (Adicionar item da página de produto)
// ... (Seu código de ações POST continua aqui) ...
// ----------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $produto_id = filter_input(INPUT_POST, 'produto_id', FILTER_VALIDATE_INT);
    $variacao_id = filter_input(INPUT_POST, 'variacao_id', FILTER_VALIDATE_INT);
    $quantidade = filter_input(INPUT_POST, 'quantidade', FILTER_VALIDATE_INT);

    if (!$produto_id || !$variacao_id || $quantidade <= 0) {
        header('Location: produto.php?id=' . ($produto_id ?? 0) . '&status=error_data');
        exit;
    }

    $sql_check = "SELECT estoque FROM produto_variacoes WHERE id = ? AND produto_id = ?";
    $stmt_check = $conexao->prepare($sql_check);
    $stmt_check->bind_param("ii", $variacao_id, $produto_id);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();

    if ($result_check->num_rows === 0) {
        header('Location: produto.php?id=' . $produto_id . '&status=error_variacao');
        $stmt_check->close();
        exit;
    }

    $variacao_info = $result_check->fetch_assoc();
    $estoque_disponivel = $variacao_info['estoque'];
    $stmt_check->close();

    $sql_carrinho = "SELECT id, quantidade FROM carrinho_itens 
                     WHERE variacao_id = ? AND " . ($is_user ? "usuario_id = ?" : "carrinho_session_id = ?");
    $stmt_carrinho = $conexao->prepare($sql_carrinho);

    if ($is_user) {
        $stmt_carrinho->bind_param("ii", $variacao_id, $carrinho_ref_id);
    } else {
        $stmt_carrinho->bind_param("is", $variacao_id, $carrinho_ref_id);
    }

    $stmt_carrinho->execute();
    $result_carrinho = $stmt_carrinho->get_result();
    $item_existente = $result_carrinho->fetch_assoc();
    $stmt_carrinho->close();

    $nova_quantidade = $quantidade + ($item_existente['quantidade'] ?? 0);

    if ($nova_quantidade > $estoque_disponivel) {
        header('Location: produto.php?id=' . $produto_id . '&status=error_estoque');
        exit;
    }

    $conexao->begin_transaction();
    $sucesso = true;

    try {
        if ($item_existente) {
            $sql_update = "UPDATE carrinho_itens SET quantidade = ? WHERE id = ?";
            $stmt_update = $conexao->prepare($sql_update);
            $stmt_update->bind_param("ii", $nova_quantidade, $item_existente['id']);
            if (!$stmt_update->execute())
                $sucesso = false;
            $stmt_update->close();

        } else {
            $sql_insert = "INSERT INTO carrinho_itens (usuario_id, carrinho_session_id, produto_id, variacao_id, quantidade) 
                           VALUES (?, ?, ?, ?, ?)";
            $stmt_insert = $conexao->prepare($sql_insert);

            // Importante: Tratamento para NULL para campos de ID não utilizados
            $usuario_id_val = $is_user ? $carrinho_ref_id : NULL;
            $session_id_val = !$is_user ? $carrinho_ref_id : NULL;

            // Tipos de Bind: 's' para os IDs (tratando INT e VARCHAR), seguido por 'iii'
            // NOTA: Em mysqli, o bind de NULL deve ser 's'.
            $stmt_insert->bind_param("ssiii", $usuario_id_val, $session_id_val, $produto_id, $variacao_id, $quantidade);
            
            if (!$stmt_insert->execute())
                $sucesso = false;
            $stmt_insert->close();
        }

        if ($sucesso) {
            $conexao->commit();
            header('Location: ' . $redirecionar_para . '?status=added');
        } else {
            $conexao->rollback();
            header('Location: produto.php?id=' . $produto_id . '&status=error_db');
        }

    } catch (Exception $e) {
        $conexao->rollback();
        header('Location: produto.php?id=' . $produto_id . '&status=error_db_exception');
    }

    exit;
}

// Se nenhuma ação foi executada, redireciona para a visualização
header('Location: ' . $redirecionar_para);
exit;
?>