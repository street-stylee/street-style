<?php
require_once 'formu.php';
session_start();
// Bloco de login (deixei descomentado, mas sem forçar o redirecionamento por enquanto)
// if((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) ==true))
// {
//     unset($_SESSION['email']);
//     unset($_SESSION['senha']);
//     header('Location: login.php');
// }

// 1. Definição das variáveis de sessão (melhor prática)
$usuario_logado = isset($_SESSION['usuario_id']);
$primeiro_nome = $usuario_logado ? htmlspecialchars(explode(' ', $_SESSION['usuario_nome'] ?? 'Usuário')[0]) : '';
// $logado = $_SESSION['email'] ?? ''; // Mantido como referência, mas usando $usuario_logado

require_once 'formu.php';
$sql = "SELECT id, nome, preco, imagem_url FROM produtos ORDER BY nome";
$resultado = $conexao->query($sql);
// --- Lógica para LIMPAR TODO o carrinho ---
if (isset($_GET['acao']) && $_GET['acao'] == 'limpar') {
    unset($_SESSION['carrinho']);
    header('Location: carrinho.php');
    exit;
}

// --- Lógica para EXCLUIR UM item do carrinho ---
if (isset($_GET['acao']) && $_GET['acao'] == 'excluir' && isset($_GET['id'])) {
    $id_para_excluir = $_GET['id'];
    if (isset($_SESSION['carrinho'])) {
        foreach ($_SESSION['carrinho'] as $indice => $item) {
            // Remove o item pelo ID (e implicitamente o tamanho)
            if ($item['id'] == $id_para_excluir) {
                unset($_SESSION['carrinho'][$indice]);
                break;
            }
        }
    }
    header('Location: carrinho.php');
    exit;
}

// --- Lógica para DIMINUIR a quantidade de um item ---
// Adicionamos 'tamanho' na URL para diminuir o item correto
if (isset($_GET['acao']) && $_GET['acao'] == 'diminuir' && isset($_GET['id']) && isset($_GET['tamanho'])) {
    $id_para_diminuir = $_GET['id'];
    $tamanho_item = $_GET['tamanho'];

    if (isset($_SESSION['carrinho'])) {
        foreach ($_SESSION['carrinho'] as $indice => $item) {
            // Verifica o ID e o Tamanho para garantir que diminui o item correto
            if ($item['id'] == $id_para_diminuir && $item['tamanho'] == $tamanho_item) {
                if ($item['quantidade'] > 1) {
                    $_SESSION['carrinho'][$indice]['quantidade']--;
                } else {
                    // Se a quantidade é 1, remove o item
                    unset($_SESSION['carrinho'][$indice]);
                }
                break;
            }
        }
    }
    header('Location: carrinho.php');
    exit;
}


// --- Lógica para ADICIONAR item ao carrinho (via POST) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $produto_id = $_POST['id'];
    $quantidade = intval($_POST['quantidade']);
    $tamanho = $_POST['tamanho'];

    $sql_produto = "SELECT nome, preco, imagem_url FROM produtos WHERE id = ?";
    $stmt = $conexao->prepare($sql_produto);
    $stmt->bind_param("i", $produto_id);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        $produto = $resultado->fetch_assoc();

        $item_carrinho = [
            'id' => $produto_id,
            'nome' => $produto['nome'],
            'preco' => $produto['preco'],
            'imagem' => $produto['imagem_url'],
            'quantidade' => $quantidade,
            'tamanho' => $tamanho
        ];

        if (!isset($_SESSION['carrinho'])) {
            $_SESSION['carrinho'] = [];
        }

        $item_existe = false;
        foreach ($_SESSION['carrinho'] as $indice => $item) {
            // Verifica se o item já existe (mesmo ID E mesmo tamanho)
            if ($item['id'] == $produto_id && $item['tamanho'] == $tamanho) {
                $_SESSION['carrinho'][$indice]['quantidade'] += $quantidade;
                $item_existe = true;
                break;
            }
        }

        if (!$item_existe) {
            $_SESSION['carrinho'][] = $item_carrinho;
        }
    }

    if (isset($stmt))
        $stmt->close();
    $conexao->close();

    header('Location: carrinho.php');
    exit;
}

// Função para calcular o total
$total_geral = 0;
if (isset($_SESSION['carrinho'])) {
    foreach ($_SESSION['carrinho'] as $item) {
        $total_geral += $item['preco'] * $item['quantidade'];
    }
}

// Fechamento da conexão para o restante da página (apenas se a lógica POST não foi executada)
if (!isset($_POST) || empty($_POST)) {
    if (isset($conexao)) {
        $conexao->close();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrinho de Compras - Street Style</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&display=swap"
        rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&family=Poppins:wght@100;300;400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link rel="shortcut icon" href="../_ADM/favicon.ico/favicon.ico" type="image/x-icon">
    <link rel="icon" type="image/png" sizes="32x32" href="_ADM/favicon.ico/favicon-96x96.png">

    <link rel="stylesheet" href="_ADM/css/estilo_pg_produto.css">
    <link rel="stylesheet" href="_ADM/css/header-footer.css">
    <link rel="stylesheet" href="_ADM/css/estilo_carrinho.css">
</head>

<body>
    <?php require_once 'header.php' ?>

    <div class="carrinho-container">
        <h1><i class='bx bx-shopping-bag' style="vertical-align: middle;"></i> Seu Carrinho</h1>

        <?php if (!empty($_SESSION['carrinho'])): ?>
            <div class="carrinho-header">
                <a href="?acao=limpar" class="btn btn-limpar-tudo">
                    <i class="fa-solid fa-trash-can"></i> Limpar Carrinho
                </a>
            </div>

            <ul class="lista-itens">
                <?php foreach ($_SESSION['carrinho'] as $indice => $item): ?>
                    <?php
                    $preco_total_item = $item['preco'] * $item['quantidade'];
                    ?>
                    <li class="item-carrinho">
                        <div class="item-imagem">
                            <img src="<?php echo htmlspecialchars($item['imagem']); ?>"
                                alt="<?php echo htmlspecialchars($item['nome']); ?>">
                        </div>
                        <div class="item-info">
                            <a href="produto.php?id=<?php echo htmlspecialchars($item['id']); ?>" class="item-nome">
                                <?php echo htmlspecialchars($item['nome']); ?>
                            </a>
                            <span class="item-tamanho">Tamanho: <?php echo htmlspecialchars($item['tamanho']); ?></span>
                            <span class="item-preco-unitario">R$
                                <?php echo number_format($item['preco'], 2, ',', '.'); ?>/un.</span>

                            <div class="item-acoes-mobile">
                                <span class="quantidade-mobile">Qtde:
                                    <?php echo htmlspecialchars($item['quantidade']); ?></span>
                                <a href="?acao=diminuir&id=<?php echo htmlspecialchars($item['id']); ?>&tamanho=<?php echo htmlspecialchars($item['tamanho']); ?>"
                                    class="btn-remover-mobile">Diminuir</a>
                            </div>
                        </div>

                        <div class="item-quantidade">
                            <a href="?acao=diminuir&id=<?php echo htmlspecialchars($item['id']); ?>&tamanho=<?php echo htmlspecialchars($item['tamanho']); ?>"
                                class="btn-qty">-</a>
                            <span class="quantidade-display"><?php echo htmlspecialchars($item['quantidade']); ?></span>
                            <a href="produto.php?id=<?php echo htmlspecialchars($item['id']); ?>" class="btn-qty">+</a>
                        </div>

                        <div class="item-subtotal">
                            <span class="subtotal-label">Subtotal</span>
                            <span class="subtotal-valor">R$ <?php echo number_format($preco_total_item, 2, ',', '.'); ?></span>
                        </div>

                        <a href="?acao=excluir&id=<?php echo htmlspecialchars($item['id']); ?>" class="btn-remover">
                            <i class="fa-solid fa-xmark"></i>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>

            <div class="resumo-compra">
                <div class="resumo-row">
                    <span>Subtotal de Produtos (<?php echo count($_SESSION['carrinho']); ?> itens)</span>
                    <span class="valor-produtos">R$ <?php echo number_format($total_geral, 2, ',', '.'); ?></span>
                </div>
                <div class="resumo-row total-final">
                    <h3>Total a Pagar</h3>
                    <h3 class="valor-final">R$ <?php echo number_format($total_geral, 2, ',', '.'); ?></h3>
                </div>

                <?php if (isset($_SESSION['usuario_id'])): ?>
                    <a href="checkout.php" class="btn-finalizar-compra">
                        <i class="fa-solid fa-truck-fast"></i> Finalizar Pedido
                    </a>
                <?php else: ?>
                    <?php $_SESSION['redirect_after_login'] = 'checkout.php'; ?>
                    <a href="login.php" class="btn-finalizar-compra btn-alert">
                        <i class="fa-solid fa-user-lock"></i> Faça Login para Finalizar
                    </a>
                <?php endif; ?>
            </div>

            <style>
                .btn-alert {
                    background-color: #f39c12 !important;
                    /* Laranja de Alerta */
                    box-shadow: 0 4px 8px rgba(243, 156, 18, 0.4);
                }

                .btn-alert:hover {
                    background-color: #e67e22 !important;
                    box-shadow: 0 6px 12px rgba(243, 156, 18, 0.6);
                }
            </style>

        <?php else: ?>
            <div class="carrinho-vazio">
                <i class='bx bx-shopping-bag' style="font-size: 80px; color: #ccc;"></i>
                <h2>Seu carrinho está vazio!</h2>
                <p>Parece que você ainda não adicionou nenhum item.</p>
            </div>
        <?php endif; ?>

        <a href="produtos.php" class="btn-continuar-comprando">
            <i class="fa-solid fa-arrow-left"></i> Continuar Comprando
        </a>
    </div>

    <section class="contato">
        <div class="contato-info">
            <div class="primeiro-info">
                <img src="_ADM/img_index/logotipo2.png" alt="">
                <p>ETEC Jornalista Roberto Marinho, <br> São Paulo - SP</p>
                <p>streetstyle@gmail.com</p>
                <div class="social-icon">
                    <a href="https://www.facebook.com/profile.php?id=61554518331187"><i class='bx bxl-facebook'></i></a>
                    <a href="https://twitter.com/home"><i class="fa-brands fa-x-twitter"
                            style="color: #000000;"></i></a>
                    <a href="https://www.instagram.com/streetstyle.ufc/"><i class='bx bxl-instagram'></i></a>
                    <a href="https://www.youtube.com/"><i class='bx bxl-youtube'></i></a>
                </div>
            </div>
            <div class="segundo-info">
                <h4>Suporte</h4>
                <p>Contato</p>
                <p>Sobre nós</p>
                <p>Políticas de privacidade</p>
                <p>Politicas de devolução e trocas</p>
                <p>Entrega e Prazos</p>
            </div>
            <div class="terceiro-info">
                <h4>Junte-se conosco</h4>
                <p>Venda na Street Style</p>
                <p>Anuncie sua empresa</p>
                <p>Publique suas roupas</p>
                <p>Seja um associado</p>
                <p>Anuncie seus produtos</p>
            </div>
            <div class="quarto-info">
                <h4>Pagamento</h4>
                <p>Meios de <br>Pagamento</p>
                <p>Compre com <br>Pontos</p>
                <p>Cartão de Crédito</p>
            </div>
            <div class="cinco">
                <h4>Deixe-nos ajudar você</h4>
                <p>Sua conta</p>
                <p>Frete e prazo de entrega</p>
                <p>Devoluções e reembolsos</p>
                <p>Gerencie seu conteúdo e <br>dispositivos</p>
                <p>Ajuda</p>
            </div>
        </div>
    </section>
    <div class="texto-final">
        <p>Street Style © 2025. Todos os direitos reservados.</p>
    </div>

    <script>
        // Função para mudar a imagem principal ao rolar (Header)
        window.onscroll = function () {
            scrollFunction();
        };

        function scrollFunction() {
            var header = document.querySelector('header');
            if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        }
    </script>

</body>

</html>