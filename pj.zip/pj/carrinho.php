<?php
require_once 'formu.php';
@session_start();

// 1. Definição das variáveis de sessão (melhor prática)
$usuario_logado = isset($_SESSION['usuario_id']);
// Use 'nome_usuario' se você o definiu na sessão, senão use 'Usuário' como fallback.
$primeiro_nome = $usuario_logado ? htmlspecialchars(explode(' ', $_SESSION['nome_usuario'] ?? 'Usuário')[0]) : ''; 

// --- Lógica para LIMPAR TODO o carrinho ---
if (isset($_GET['acao']) && $_GET['acao'] == 'limpar') {
    unset($_SESSION['carrinho']);
    header('Location: carrinho.php');
    exit;
}

// --- Lógica para EXCLUIR UM item do carrinho ---
if (isset($_GET['acao']) && $_GET['acao'] == 'excluir' && isset($_GET['id'])) {
    $id_para_excluir = $_GET['id'];
    // IMPORTANTE: Se você usa ID e TAMANHO para identificar um item único, 
    // a exclusão deve verificar o tamanho também, senão pode excluir um item de outro tamanho.
    $tamanho_item = $_GET['tamanho'] ?? null; 
    
    if (isset($_SESSION['carrinho'])) {
        foreach ($_SESSION['carrinho'] as $indice => $item) {
            // Remove o item pelo ID e Tamanho
            if ($item['id'] == $id_para_excluir && (is_null($tamanho_item) || $item['tamanho'] == $tamanho_item)) {
                unset($_SESSION['carrinho'][$indice]);
                break;
            }
        }
    }
    // Para reindexar o array após a remoção:
    $_SESSION['carrinho'] = array_values($_SESSION['carrinho']);
    
    header('Location: carrinho.php');
    exit;
}

// --- Lógica para DIMINUIR a quantidade de um item ---
if (isset($_GET['acao']) && $_GET['acao'] == 'diminuir' && isset($_GET['id']) && isset($_GET['tamanho'])) {
    $id_para_diminuir = $_GET['id'];
    $tamanho_item = $_GET['tamanho'];

    if (isset($_SESSION['carrinho'])) {
        foreach ($_SESSION['carrinho'] as $indice => $item) {
            if ($item['id'] == $id_para_diminuir && $item['tamanho'] == $tamanho_item) {
                if ($item['quantidade'] > 1) {
                    $_SESSION['carrinho'][$indice]['quantidade']--;
                } else {
                    // Se a quantidade é 1, remove o item
                    unset($_SESSION['carrinho'][$indice]);
                    // Reindexa o array após a remoção
                    $_SESSION['carrinho'] = array_values($_SESSION['carrinho']);
                }
                break;
            }
        }
    }
    header('Location: carrinho.php');
    exit;
}

// --- Lógica para AUMENTAR a quantidade de um item (CORREÇÃO) ---
if (isset($_GET['acao']) && $_GET['acao'] == 'aumentar' && isset($_GET['id']) && isset($_GET['tamanho'])) {
    $id_para_aumentar = $_GET['id'];
    $tamanho_item = $_GET['tamanho'];

    if (isset($_SESSION['carrinho'])) {
        foreach ($_SESSION['carrinho'] as $indice => $item) {
            if ($item['id'] == $id_para_aumentar && $item['tamanho'] == $tamanho_item) {
                // Aumenta a quantidade
                $_SESSION['carrinho'][$indice]['quantidade']++;
                break;
            }
        }
    }
    header('Location: carrinho.php');
    exit;
}


// --- Lógica para ADICIONAR item ao carrinho (via POST - ao adicionar da página de produto) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // É uma boa prática limpar os inputs do POST
    $produto_id = filter_input(INPUT_POST, 'id', FILTER_SANITIZE_NUMBER_INT);
    $quantidade = filter_input(INPUT_POST, 'quantidade', FILTER_SANITIZE_NUMBER_INT);
    $tamanho = filter_input(INPUT_POST, 'tamanho', FILTER_SANITIZE_FULL_SPECIAL_CHARS);

    if (!$produto_id || $quantidade < 1 || !$tamanho) {
        // Redireciona de volta para a página do produto ou mostra erro se dados inválidos
        header('Location: produtos.php');
        exit;
    }
    
    $sql_produto = "SELECT nome, preco, imagem_url FROM produtos WHERE id = ?";
    $stmt = $conexao->prepare($sql_produto);
    $stmt->bind_param("i", $produto_id);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        $produto = $resultado->fetch_assoc();

        $item_carrinho = [
            'id' => $produto_id,
            'nome' => $produto['nome'],
            'preco' => $produto['preco'],
            'imagem' => $produto['imagem_url'],
            'quantidade' => $quantidade,
            'tamanho' => $tamanho
        ];

        if (!isset($_SESSION['carrinho'])) {
            $_SESSION['carrinho'] = [];
        }

        $item_existe = false;
        foreach ($_SESSION['carrinho'] as $indice => $item) {
            // Verifica se o item já existe (mesmo ID E mesmo tamanho)
            if ($item['id'] == $produto_id && $item['tamanho'] == $tamanho) {
                $_SESSION['carrinho'][$indice]['quantidade'] += $quantidade;
                $item_existe = true;
                break;
            }
        }

        if (!$item_existe) {
            $_SESSION['carrinho'][] = $item_carrinho;
        }
    }

    if (isset($stmt)) $stmt->close();
    // Atenção: Fechar a conexão aqui pode causar problemas no 'header.php' se ele precisar da conexão.
    // É melhor fechar a conexão no final do script, após o HTML.

    header('Location: carrinho.php');
    exit;
}

// Função para calcular o total
$total_geral = 0;
if (isset($_SESSION['carrinho'])) {
    foreach ($_SESSION['carrinho'] as $item) {
        $total_geral += $item['preco'] * $item['quantidade'];
    }
}

// Fechamento da conexão para o restante da página (apenas se a lógica POST não foi executada)
// Removendo o bloco condicional de fechamento para fechar apenas no final do HTML
// if (!isset($_POST) || empty($_POST)) {
//     if (isset($conexao)) {
//         $conexao->close();
//     }
// }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrinho de Compras - Street Style</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&display=swap"
        rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700&family=Poppins:wght@100;300;400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link rel="shortcut icon" href="../_ADM/favicon.ico/favicon.ico" type="image/x-icon">
    <link rel="icon" type="image/png" sizes="32x32" href="_ADM/favicon.ico/favicon-96x96.png">

    <link rel="stylesheet" href="_ADM/css/estilo_pg_produto.css">
    <link rel="stylesheet" href="_ADM/css/header-footer.css">
    <link rel="stylesheet" href="_ADM/css/estilo_carrinho.css">
</head>

<body>
    <?php require_once 'header.php' ?>

    <div class="carrinho-container">
        <h1><i class='bx bx-shopping-bag' style="vertical-align: middle;"></i> Seu Carrinho</h1>

        <?php if (!empty($_SESSION['carrinho'])): ?>
            <div class="carrinho-header">
                <a href="?acao=limpar" class="btn btn-limpar-tudo">
                    <i class="fa-solid fa-trash-can"></i> Limpar Carrinho
                </a>
            </div>

            <ul class="lista-itens">
                <?php foreach ($_SESSION['carrinho'] as $indice => $item): ?>
                    <?php
                    $preco_total_item = $item['preco'] * $item['quantidade'];
                    // Chave única para o botão de exclusão que verifica o ID e o TAMANHO
                    $chave_unica_excluir = "id=" . urlencode($item['id']) . "&tamanho=" . urlencode($item['tamanho']);
                    $chave_unica_diminuir = "id=" . urlencode($item['id']) . "&tamanho=" . urlencode($item['tamanho']);
                    $chave_unica_aumentar = "id=" . urlencode($item['id']) . "&tamanho=" . urlencode($item['tamanho']);
                    ?>
                    <li class="item-carrinho">
                        <div class="item-imagem">
                            <img src="<?php echo htmlspecialchars($item['imagem']); ?>"
                                alt="<?php echo htmlspecialchars($item['nome']); ?>">
                        </div>
                        <div class="item-info">
                            <a href="produto.php?id=<?php echo htmlspecialchars($item['id']); ?>" class="item-nome">
                                <?php echo htmlspecialchars($item['nome']); ?>
                            </a>
                            <span class="item-tamanho">Tamanho: <?php echo htmlspecialchars($item['tamanho']); ?></span>
                            <span class="item-preco-unitario">R$
                                <?php echo number_format($item['preco'], 2, ',', '.'); ?>/un.</span>

                            <div class="item-acoes-mobile">
                                <span class="quantidade-mobile">Qtde:
                                    <?php echo htmlspecialchars($item['quantidade']); ?></span>
                                <a href="?acao=diminuir&<?php echo $chave_unica_diminuir; ?>"
                                    class="btn-remover-mobile">Diminuir</a>
                                    <a href="?acao=aumentar&<?php echo $chave_unica_aumentar; ?>"
                                    class="btn-remover-mobile">Aumentar</a>
                            </div>
                        </div>

                        <div class="item-quantidade">
                            <a href="?acao=diminuir&<?php echo $chave_unica_diminuir; ?>"
                                class="btn-qty">-</a>
                            <span class="quantidade-display"><?php echo htmlspecialchars($item['quantidade']); ?></span>
                            <a href="?acao=aumentar&<?php echo $chave_unica_aumentar; ?>" class="btn-qty">+</a>
                        </div>

                        <div class="item-subtotal">
                            <span class="subtotal-label">Subtotal</span>
                            <span class="subtotal-valor">R$ <?php echo number_format($preco_total_item, 2, ',', '.'); ?></span>
                        </div>

                        <a href="?acao=excluir&<?php echo $chave_unica_excluir; ?>" class="btn-remover">
                            <i class="fa-solid fa-xmark"></i>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>

            <div class="resumo-compra">
                <div class="resumo-row">
                    <span>Subtotal de Produtos (<?php echo count($_SESSION['carrinho']); ?> itens)</span>
                    <span class="valor-produtos">R$ <?php echo number_format($total_geral, 2, ',', '.'); ?></span>
                </div>
                <div class="resumo-row total-final">
                    <h3>Total a Pagar</h3>
                    <h3 class="valor-final">R$ <?php echo number_format($total_geral, 2, ',', '.'); ?></h3>
                </div>

                <?php if (isset($_SESSION['usuario_id'])): ?>
                    <a href="checkout.php" class="btn-finalizar-compra">
                        <i class="fa-solid fa-truck-fast"></i> Finalizar Pedido
                    </a>
                <?php else: ?>
                    <?php $_SESSION['redirect_after_login'] = 'checkout.php'; ?>
                    <a href="login.php" class="btn-finalizar-compra btn-alert">
                        <i class="fa-solid fa-user-lock"></i> Faça Login para Finalizar
                    </a>
                <?php endif; ?>
            </div>

            <style>
                .btn-alert {
                    background-color: #f39c12 !important;
                    /* Laranja de Alerta */
                    box-shadow: 0 4px 8px rgba(243, 156, 18, 0.4);
                }

                .btn-alert:hover {
                    background-color: #e67e22 !important;
                    box-shadow: 0 6px 12px rgba(243, 156, 18, 0.6);
                }
            </style>

        <?php else: ?>
            <div class="carrinho-vazio">
                <i class='bx bx-shopping-bag' style="font-size: 80px; color: #ccc;"></i>
                <h2>Seu carrinho está vazio!</h2>
                <p>Parece que você ainda não adicionou nenhum item.</p>
            </div>
        <?php endif; ?>

        <a href="produtos.php" class="btn-continuar-comprando">
            <i class="fa-solid fa-arrow-left"></i> Continuar Comprando
        </a>
    </div>

    <section class="contato">
        </section>
    <div class="texto-final">
        <p>Street Style © 2025. Todos os direitos reservados.</p>
    </div>

    <script>
        // Função para mudar a imagem principal ao rolar (Header)
        window.onscroll = function () {
            scrollFunction();
        };

        function scrollFunction() {
            var header = document.querySelector('header');
            if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        }
    </script>

</body>

</html>
<?php
// Fechamento da conexão no final do script
if (isset($conexao)) {
    $conexao->close();
}
?>