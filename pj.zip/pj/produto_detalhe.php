<?php
// include_once('conexao.php');
// $id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// $sql = "SELECT * FROM produtos WHERE id = $id";
// $result = $conexao->query($sql);
// if($result && mysqli_num_rows($result) > 0){
//     $produto = mysqli_fetch_assoc($result);
//     echo "<h1>".$produto['nome']."</h1>";
//     echo "<img src='".$produto['imagem_url']."' style='width:300px;'>";
//     echo "<p>".$produto['descricao']."</p>";
//     echo "<p>Preço: R$ ".$produto['preco']."</p>";
//     echo "<p>Categoria: ".$produto['categoria']."</p>";
//     echo "<p>Avaliação: ".$produto['avaliacao_media']." ⭐</p>";

//     // Imagens secundárias
//     $sql_imgs = "SELECT * FROM produto_imagens WHERE produto_id = $id";
//     $res_imgs = $conexao->query($sql_imgs);
//     if($res_imgs && mysqli_num_rows($res_imgs) > 0){
//         while($img = mysqli_fetch_assoc($res_imgs)){
//             echo "<img src='".$img['imagem_url']."' style='width:100px; margin:5px;'>";
//         }
//     }
// } else {
//     echo "<p>Produto não encontrado.</p>";
// }
?>