<?php
// admin_produtos.php

// Inclui o controle de acesso e a conexão
require_once 'admin_auth.php'; 
require_once '../formu.php';

$produtos = [];

// ----------------------------------------------------
// 1. Lógica para EXCLUSÃO de Produto (Ação GET/POST simples)
// ----------------------------------------------------
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $produto_id = $_GET['id'];
    
    // ATENÇÃO: A tabela 'produto_imagens' tem uma FOREIGN KEY ON DELETE CASCADE, 
    // então a exclusão do produto deve apagar suas imagens relacionadas automaticamente.
    $sql_delete = "DELETE FROM produtos WHERE id = ?";
    $stmt_delete = $conexao->prepare($sql_delete);
    
    if ($stmt_delete) {
        $stmt_delete->bind_param("i", $produto_id);
        if ($stmt_delete->execute()) {
            $mensagem_status = "Produto #{$produto_id} excluído com sucesso!";
        } else {
            $mensagem_status = "Erro ao excluir produto: " . $stmt_delete->error;
        }
        $stmt_delete->close();
    }
}

// ----------------------------------------------------
// 2. Lógica para Buscar e Listar os Produtos
// ----------------------------------------------------
$sql_produtos = "SELECT id, nome, preco, categoria, avaliacao_media FROM produtos ORDER BY id DESC";
$resultado = $conexao->query($sql_produtos);

if ($resultado) {
    while ($produto = $resultado->fetch_assoc()) {
        $produtos[] = $produto;
    }
}

$conexao->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Produtos | Admin</title>
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="../_ADM/css/admin_style.css"> 
    
    <style>
        /* CSS Específico para esta página */
        body { background-color: #f4f4f4; color: #333; }
        .admin-container { max-width: 1200px; margin: 50px auto; padding: 20px; background-color: #fff; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        h1 { border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; }
        
        .toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        
        .btn-adicionar {
            background-color: #27ae60; 
            color: #fff; 
            border: none; 
            padding: 10px 15px; 
            text-decoration: none;
            border-radius: 6px; 
            font-weight: 600;
            transition: background-color 0.3s;
        }
        .btn-adicionar:hover { background-color: #1e8449; }
        
        .produto-table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        .produto-table th, .produto-table td { padding: 12px; border: 1px solid #eee; text-align: left; }
        .produto-table th { background-color: #333; color: #fff; font-weight: 600; }
        .produto-table tr:nth-child(even) { background-color: #f9f9f9; }
        
        /* Coluna de Ações */
        .action-btns a {
            margin-right: 5px;
            padding: 5px 8px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 0.9rem;
            display: inline-flex;
            align-items: center;
        }
        .btn-editar { background-color: #3498db; color: #fff; }
        .btn-excluir { background-color: #e74c3c; color: #fff; }

        /* Mensagens de Status */
        .alert-success { padding: 10px; background-color: #d4edda; color: #155724; border-radius: 5px; margin-bottom: 20px; }
        .alert-error { padding: 10px; background-color: #f8d7da; color: #721c24; border-radius: 5px; margin-bottom: 20px; }
    </style>
    <script>
        function confirmarExclusao(id) {
            return confirm("Tem certeza que deseja EXCLUIR o Produto #" + id + "? Esta ação é irreversível.");
        }
    </script>
</head>
<body>

    <div class="admin-container">
        <h1><i class='bx bxs-t-shirt'></i> Gerenciar Produtos</h1>

        <?php if (isset($mensagem_status)): ?>
            <div class="<?php echo (strpos($mensagem_status, 'Erro') !== false) ? 'alert-error' : 'alert-success'; ?>">
                <?php echo $mensagem_status; ?>
            </div>
        <?php endif; ?>

        <div class="toolbar">
            <a href="admin_produto_form.php" class="btn-adicionar"><i class='bx bx-plus'></i> Adicionar Novo Produto</a>
            <a href="admin_dashboard.php">Voltar ao Dashboard</a>
        </div>

        <?php if (empty($produtos)): ?>
            <p>Nenhum produto encontrado. Adicione um novo.</p>
        <?php else: ?>
            <table class="produto-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Preço</th>
                        <th>Categoria</th>
                        <th>Avaliação</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($produtos as $produto): ?>
                        <tr>
                            <td>#<?php echo htmlspecialchars($produto['id']); ?></td>
                            <td><?php echo htmlspecialchars($produto['nome']); ?></td>
                            <td>R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></td>
                            <td><?php echo htmlspecialchars($produto['categoria']); ?></td>
                            <td><?php echo htmlspecialchars($produto['avaliacao_media']); ?> <i class='bx bxs-star' style="color: gold;"></i></td>
                            <td class="action-btns">
                                <a href="admin_produto_form.php?id=<?php echo $produto['id']; ?>" class="btn-editar">
                                    <i class='bx bxs-edit-alt'></i> Editar
                                </a>
                                <a href="admin_produtos.php?action=delete&id=<?php echo $produto['id']; ?>" class="btn-excluir" 
                                   onclick="return confirmarExclusao(<?php echo $produto['id']; ?>)">
                                    <i class='bx bxs-trash'></i> Excluir
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

</body>
</html>