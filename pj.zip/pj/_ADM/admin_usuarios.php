<?php
// admin_usuarios.php

require_once 'admin_auth.php'; 
require_once '../formu.php';

$usuarios = [];
$termo_busca = $_GET['busca'] ?? '';

// Prepara o filtro de busca
$where_clause = '';
$params = [];
$types = '';

if (!empty($termo_busca)) {
    // Busca por nome OU email
    $where_clause = "WHERE u.nome LIKE ? OR u.email LIKE ?";
    $like_termo = "%" . $termo_busca . "%";
    $params[] = $like_termo;
    $params[] = $like_termo;
    $types = "ss";
}

// ----------------------------------------------------
// 1. BUSCA DE USUÁRIOS E CONTAGEM DE PEDIDOS
// ----------------------------------------------------
$sql_usuarios = "SELECT 
                    u.id, 
                    u.nome, 
                    u.email, 
                    u.telefone, 
                    u.data_cadastro,
                    (SELECT COUNT(p.id) FROM pedidos p WHERE p.usuario_id = u.id) AS total_pedidos
                FROM usuarios u
                {$where_clause}
                ORDER BY u.id DESC";

$stmt = $conexao->prepare($sql_usuarios);

if ($stmt) {
    if (!empty($params)) {
        // Usa call_user_func_array para passar os parâmetros dinamicamente
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    $resultado = $stmt->get_result();

    while ($usuario = $resultado->fetch_assoc()) {
        $usuarios[] = $usuario;
    }
    $stmt->close();
}

$conexao->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Usuários | Admin</title>
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="../_ADM/css/admin_style.css"> 
    
    <style>
        /* CSS Específico da Página de Usuários */
        body { background-color: #f4f4f4; color: #333; }
        .admin-container { max-width: 1200px; margin: 50px auto; padding: 20px; background-color: #fff; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        h1 { border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; font-size: 2rem; }
        
        /* Barra de Busca e Ações */
        .toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
        .search-form { display: flex; gap: 10px; }
        .search-form input[type="text"] { padding: 8px; border: 1px solid #ccc; border-radius: 4px; width: 300px; }
        .search-form button { background-color: #3498db; color: #fff; border: none; padding: 8px 15px; border-radius: 4px; cursor: pointer; transition: background-color 0.3s; }
        .search-form button:hover { background-color: #2980b9; }

        /* Tabela de Usuários */
        .user-table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        .user-table th, .user-table td { padding: 12px; border: 1px solid #eee; text-align: left; }
        .user-table th { background-color: #333; color: #fff; font-weight: 600; }
        .user-table tr:nth-child(even) { background-color: #f9f9f9; }
        
        /* Destaque para o ID do Admin (ID 1) */
        .admin-row { background-color: #fcf8e3 !important; font-weight: 600; }
        .admin-row td { border-left: 3px solid #f0ad4e; }
        
        /* Botões de Ação na Tabela */
        .action-link {
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 0.9rem;
            display: inline-flex;
            align-items: center;
        }
        .btn-pedidos { background-color: #27ae60; color: #fff; }
        .btn-pedidos:hover { background-color: #1e8449; }
    </style>
</head>
<body>

    <div class="admin-container">
        <h1><i class='bx bxs-user-account'></i> Gerenciar Usuários/Clientes</h1>

        <div class="toolbar">
            <form method="GET" class="search-form">
                <input type="text" name="busca" placeholder="Buscar por Nome ou Email..." value="<?php echo htmlspecialchars($termo_busca); ?>">
                <button type="submit"><i class='bx bx-search'></i> Buscar</button>
                <?php if ($termo_busca): ?>
                    <a href="admin_usuarios.php" style="line-height: 2.5; color: #c0392b;">Limpar Busca</a>
                <?php endif; ?>
            </form>
            <a href="admin_dashboard.php">Voltar ao Dashboard</a>
        </div>

        <?php if (empty($usuarios)): ?>
            <p>Nenhum usuário encontrado<?php echo !empty($termo_busca) ? " para o termo '<strong>" . htmlspecialchars($termo_busca) . "</strong>'" : "."; ?></p>
        <?php else: ?>
            <p>Total de Clientes: <strong><?php echo count($usuarios); ?></strong></p>
            <table class="user-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>E-mail</th>
                        <th>Telefone</th>
                        <th>Cadastrado em</th>
                        <th>Total Pedidos</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($usuarios as $usuario): ?>
                        <tr class="<?php echo ($usuario['id'] == 1) ? 'admin-row' : ''; ?>">
                            <td>#<?php echo htmlspecialchars($usuario['id']); ?></td>
                            <td><?php echo htmlspecialchars($usuario['nome']); ?></td>
                            <td><?php echo htmlspecialchars($usuario['email']); ?></td>
                            <td><?php echo htmlspecialchars($usuario['telefone'] ?? 'N/A'); ?></td>
                            <td><?php echo date('d/m/Y', strtotime($usuario['data_cadastro'])); ?></td>
                            <td><?php echo htmlspecialchars($usuario['total_pedidos']); ?></td>
                            <td>
                                <a href="admin_pedidos.php?user_id=<?php echo $usuario['id']; ?>" class="action-link btn-pedidos">
                                    <i class='bx bxs-package'></i> Ver Pedidos
                                </a>
                                </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

</body>
</html>