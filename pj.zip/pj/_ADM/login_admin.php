<?php
// login_admin.php

session_start();
// Certifique-se de que este caminho está correto para o seu arquivo de conexão!
require_once 'formu.php'; 

$mensagem_erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $senha_digitada = $_POST['senha'];

    // 1. Busca o usuário pelo email, incluindo o nível de acesso
    $sql = "SELECT id, nome, senha, nivel_acesso FROM usuarios WHERE email = ?";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows === 1) {
        $usuario = $resultado->fetch_assoc();
        
        // 2. Verifica a senha (USANDO hash, o ideal!)
        // ATENÇÃO: Se suas senhas NÃO forem hash, use: if ($senha_digitada === $usuario['senha']) {
        if (password_verify($senha_digitada, $usuario['senha'])) {
            
            // 3. VERIFICA O NÍVEL DE ACESSO
            if ($usuario['nivel_acesso'] === 'admin') {
                
                // LOGIN DE ADMIN BEM-SUCEDIDO: Configura a sessão
                $_SESSION['usuario_id'] = $usuario['id'];
                $_SESSION['usuario_nome'] = $usuario['nome'];
                $_SESSION['nivel_acesso'] = $usuario['nivel_acesso'];
                
                // REDIRECIONAMENTO FINAL: Leva para o painel de produtos do admin
                header('Location: admin_dashboard.php'); 
                exit;

            } else {
                // Usuário existe, a senha está correta, mas NÃO é admin
                $mensagem_erro = "Acesso negado. Esta área é restrita a administradores.";
            }
            
        } else {
            // Senha incorreta
            $mensagem_erro = "Email ou senha incorretos.";
        }
    } else {
        // Usuário não encontrado
        $mensagem_erro = "Email ou senha incorretos.";
    }
    
    $stmt->close();
}

// Nota: A conexão `$conexao` DEVE ser fechada APENAS no final do script principal que a inclui.
// Se você fechar aqui, pode causar erro nos includes subsequentes.

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Administrativo</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #ecf0f1; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
        .login-box { background: white; padding: 40px; border-radius: 12px; box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15); width: 320px; text-align: center; }
        h2 { margin-bottom: 25px; color: #2c3e50; border-bottom: 2px solid #2c3e50; padding-bottom: 10px; }
        input[type="email"], input[type="password"] { width: 100%; padding: 12px; margin-bottom: 20px; border: 1px solid #bdc3c7; border-radius: 6px; box-sizing: border-box; font-size: 1em; }
        button { background-color: #3498db; color: white; padding: 12px 15px; border: none; border-radius: 6px; cursor: pointer; width: 100%; font-size: 1.1em; transition: background-color 0.3s; }
        button:hover { background-color: #2980b9; }
        .erro { color: #e74c3c; margin-bottom: 20px; background-color: #fceae9; border: 1px solid #e74c3c; padding: 10px; border-radius: 4px; font-weight: bold; }
    </style>
</head>
<body>
    <div class="login-box">
        <h2>Acesso Administrativo</h2>
        <?php if ($mensagem_erro): ?>
            <p class="erro"><?php echo $mensagem_erro; ?></p>
        <?php endif; ?>
        
        <form action="login_admin.php" method="POST">
            <input type="email" name="email" placeholder="Email do Administrador" required>
            <input type="password" name="senha" placeholder="Senha" required>
            <button type="submit">Entrar no Painel</button>
        </form>
    </div>
</body>
</html>