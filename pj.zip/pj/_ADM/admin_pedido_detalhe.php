<?php
// admin_pedido_detalhe.php - Código COMPLETO e ATUALIZADO (Detalhes)

require_once 'admin_auth.php'; 
require_once '../formu.php';

$pedido_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$dados_pedido = null;
$itens_pedido = [];
$usuario_info = null;
$mensagem_status = null;
$mensagem_erro = null;

if (!$pedido_id) {
    // Redireciona se o ID não for válido
    header("Location: admin_pedidos.php");
    exit;
}

// Definição de Status para o Select (para ser usado no POST e no HTML)
$status_opcoes = ['Pendente', 'Pago', 'Em Preparação', 'Enviado', 'Entregue', 'Cancelado'];

// Função para formatar o status (remove espaços para a classe CSS)
function format_status_class($status) {
    return str_replace(' ', '', htmlspecialchars($status));
}

// Função para decodificar o endereço (se houver codificação HTML)
function decode_address($address) {
    // Tenta decodificar o endereço, caso tenha sido armazenado com htmlspecialchars() ou similar
    return html_entity_decode(htmlspecialchars($address));
}


// ----------------------------------------------------
// 1. Lógica para Mudar o Status (Ação POST)
// ----------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    $novo_status = $_POST['novo_status'] ?? null;

    if ($novo_status) {
        $sql_update = "UPDATE pedidos SET status = ? WHERE id = ?";
        $stmt_update = $conexao->prepare($sql_update);
        if ($stmt_update) {
            $stmt_update->bind_param("si", $novo_status, $pedido_id);
            if ($stmt_update->execute()) {
                // Redireciona para evitar reenvio do formulário, mantendo o ID
                header("Location: admin_pedido_detalhe.php?id={$pedido_id}&status_msg=success");
                exit;
            } else {
                $mensagem_status = "Erro ao atualizar status: " . $stmt_update->error;
            }
            $stmt_update->close();
        }
    }
}

// Verifica mensagem de sucesso após redirecionamento
if (isset($_GET['status_msg']) && $_GET['status_msg'] === 'success') {
    // A mensagem será exibida após a busca principal para garantir que $dados_pedido esteja atualizado
}


// ----------------------------------------------------
// 2. BUSCA PRINCIPAL: Dados do Pedido e Cliente
// ----------------------------------------------------
$sql_principal = "SELECT 
                    p.*, 
                    u.nome AS nome_usuario, 
                    u.email AS email_usuario,
                    u.telefone AS telefone_usuario
                  FROM pedidos p
                  JOIN usuarios u ON p.usuario_id = u.id
                  WHERE p.id = ?";
$stmt_principal = $conexao->prepare($sql_principal);

if ($stmt_principal) {
    $stmt_principal->bind_param("i", $pedido_id);
    $stmt_principal->execute();
    $resultado_principal = $stmt_principal->get_result();
    
    if ($resultado_principal->num_rows === 0) {
        $mensagem_erro = "Pedido #{$pedido_id} não encontrado.";
    } else {
        $dados_pedido = $resultado_principal->fetch_assoc();
        $usuario_info = [
            'nome' => $dados_pedido['nome_usuario'],
            'email' => $dados_pedido['email_usuario'],
            'telefone' => $dados_pedido['telefone_usuario']
        ];
        
        // Se houver mensagem de sucesso do POST/redirecionamento, use o status atualizado
        if (isset($_GET['status_msg']) && $_GET['status_msg'] === 'success') {
            $mensagem_status = "Status do Pedido atualizado para '{$dados_pedido['status']}' com sucesso!";
        }
    }
    $stmt_principal->close();
}

// admin_pedido_detalhe.php - Bloco a ser editado (Linhas 104-114)

// 3. BUSCA DOS ITENS DO PEDIDO
// ----------------------------------------------------
if ($dados_pedido) {
    $sql_itens = "SELECT 
                    pi.quantidade, 
                    pi.preco_unitario,
                    pi.tamanho_variacao, 
                    prod.nome AS nome_produto,
                    prod.imagem_url
                  FROM pedido_itens pi  <-- ERRO AQUI! Mude para o nome correto (ex: itens_pedido)
                  JOIN produtos prod ON pi.produto_id = prod.id
                  WHERE pi.pedido_id = ?";
    
    // Altere 'pedido_itens' para o nome **real** da sua tabela.
    // Exemplo, se o nome for itens_pedido:
    /*
    $sql_itens = "SELECT ...
                  FROM itens_pedido pi
                  JOIN produtos prod ON pi.produto_id = prod.id
                  WHERE pi.pedido_id = ?";
    */
    
    $stmt_itens = $conexao->prepare($sql_itens); // ESTA É A LINHA 114
    // ... restante do código

    if ($stmt_itens) {
        $stmt_itens->bind_param("i", $pedido_id);
        $stmt_itens->execute();
        $resultado_itens = $stmt_itens->get_result();
        
        while ($item = $resultado_itens->fetch_assoc()) {
            $itens_pedido[] = $item;
        }
        $stmt_itens->close();
    }
}

$conexao->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalhe Pedido #<?php echo $pedido_id; ?> | Admin</title>
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="../_ADM/css/admin_style.css"> 
    <style>
        /* Estilos CSS Específicos */
        body { background-color: #f4f4f4; color: #333; }
        .admin-container { max-width: 1000px; margin: 50px auto; padding: 30px; background-color: #fff; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        h1 { border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 25px; font-size: 2rem; }
        .detalhes-grid { display: grid; grid-template-columns: 2fr 1fr; gap: 30px; margin-top: 20px; }
        .info-card { background-color: #f9f9f9; padding: 20px; border-radius: 6px; border: 1px solid #eee; margin-bottom: 20px; }
        .info-card h3 { border-bottom: 1px solid #ddd; padding-bottom: 10px; margin-bottom: 15px; font-size: 1.3rem; color: #333; }
        .info-card p { margin: 8px 0; font-size: 0.95rem; line-height: 1.5; }
        .financeiro div { display: flex; justify-content: space-between; padding: 5px 0; border-bottom: 1px dashed #ddd; }
        .financeiro .total { font-size: 1.1rem; font-weight: 700; color: #c0392b; border-bottom: 2px solid #c0392b; margin-top: 10px; padding-bottom: 10px; }
        .itens-table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        .itens-table th, .itens-table td { padding: 12px; border-bottom: 1px solid #eee; text-align: left; }
        .itens-table th { background-color: #eee; font-weight: 600; }
        .itens-table img { width: 50px; height: 50px; object-fit: cover; border-radius: 4px; vertical-align: middle; margin-right: 10px; }
        
        /* Status (Cores) - REPETIÇÃO DO CSS DO admin_pedidos.php */
        .status-tag { padding: 5px 10px; border-radius: 4px; font-weight: 600; font-size: 0.9em; text-transform: uppercase; }
        .status-Pendente { background-color: #fff3cd; color: #856404; }
        .status-Pago { background-color: #d4edda; color: #155724; }
        .status-EmPreparação { background-color: #d1ecf1; color: #0c5460; }
        .status-Enviado { background-color: #cce5ff; color: #004085; }
        .status-Entregue { background-color: #d4edda; color: #155724; }
        .status-Cancelado { background-color: #f8d7da; color: #721c24; }
        .status-action { display: flex; gap: 10px; align-items: center; margin-bottom: 15px; }
        .status-action select { padding: 8px; border-radius: 5px; border: 1px solid #ccc; }
        .status-action button { background-color: #3498db; color: #fff; border: none; padding: 8px 15px; border-radius: 5px; cursor: pointer; transition: background-color 0.3s; }
        .alert-success { padding: 10px; background-color: #d4edda; color: #155724; border-radius: 5px; margin-bottom: 20px; }
        .alert-error { padding: 10px; background-color: #f8d7da; color: #721c24; border-radius: 5px; margin-bottom: 20px; }
    </style>
</head>
<body>

    <div class="admin-container">
        
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <h1><i class='bx bxs-detail'></i> Detalhes do Pedido #<?php echo $pedido_id; ?></h1>
            <a href="admin_pedidos.php" style="font-weight: 600; text-decoration: none; color: #3498db;"><i class='bx bx-arrow-back'></i> Voltar à Lista</a>
        </div>

        <?php if (isset($mensagem_erro)): ?>
            <div class="alert-error"><?php echo $mensagem_erro; ?></div>
            <?php exit; endif; // Interrompe se o pedido não foi encontrado ?>

        <?php if (isset($mensagem_status)): ?>
            <div class="alert-success"><?php echo $mensagem_status; ?></div>
        <?php endif; ?>

        <div class="info-card">
            <h3>Status e Data</h3>
            <div class="status-action">
                <p style="margin: 0;">Status Atual: 
                    <span class="status-tag status-<?php echo format_status_class($dados_pedido['status']); ?>">
                        <?php echo htmlspecialchars($dados_pedido['status']); ?>
                    </span>
                </p>
                
                <form method="POST" style="display: flex; gap: 10px;">
                    <input type="hidden" name="action" value="update_status">
                    <select name="novo_status" required>
                        <?php foreach ($status_opcoes as $op): ?>
                            <option value="<?php echo $op; ?>" 
                                <?php echo ($dados_pedido['status'] === $op) ? 'selected' : ''; ?>>
                                <?php echo $op; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit"><i class='bx bx-refresh'></i> Atualizar Status</button>
                </form>
            </div>
            <p><strong>Data do Pedido:</strong> <?php echo date('d/m/Y H:i', strtotime($dados_pedido['data_pedido'])); ?></p>
            <p><strong>Método de Pagamento:</strong> <?php echo htmlspecialchars($dados_pedido['metodo_pagamento']); ?></p>
        </div>


        <div class="detalhes-grid">
            
            <div>
                <div class="info-card">
                    <h3>Endereço de Entrega</h3>
                    <p><?php echo decode_address($dados_pedido['endereco_completo']); ?></p>
                </div>
                
                <div class="info-card">
                    <h3>Informações do Cliente</h3>
                    <p><strong>Nome:</strong> <?php echo htmlspecialchars($usuario_info['nome']); ?></p>
                    <p><strong>E-mail:</strong> <?php echo htmlspecialchars($usuario_info['email']); ?></p>
                    <p><strong>Telefone:</strong> <?php echo htmlspecialchars($usuario_info['telefone']); ?></p>
                </div>
            </div>

            <div>
                <div class="info-card financeiro">
                    <h3>Resumo Financeiro</h3>
                    <div>
                        <span>Subtotal Produtos:</span>
                        <span>R$ <?php echo number_format($dados_pedido['total_produtos'], 2, ',', '.'); ?></span>
                    </div>
                    <div>
                        <span>Frete:</span>
                        <span>R$ <?php echo number_format($dados_pedido['valor_frete'], 2, ',', '.'); ?></span>
                    </div>
                    <?php if ($dados_pedido['valor_desconto'] > 0): ?>
                        <div style="color: #27ae60; font-weight: 600;">
                            <span>Desconto Aplicado:</span>
                            <span>- R$ <?php echo number_format($dados_pedido['valor_desconto'], 2, ',', '.'); ?></span>
                        </div>
                    <?php endif; ?>
                    <div class="total">
                        <span>Total Geral:</span>
                        <span>R$ <?php echo number_format($dados_pedido['total_geral'], 2, ',', '.'); ?></span>
                    </div>
                </div>
            </div>
        </div>
        
        <h2>Itens do Pedido (<?php echo count($itens_pedido); ?>)</h2>
        <table class="itens-table">
            <thead>
                <tr>
                    <th>Produto</th>
                    <th>Preço Unitário</th>
                    <th>Quantidade</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php $subtotal_total = 0; ?>
                <?php foreach ($itens_pedido as $item): ?>
                    <?php $subtotal_item = $item['preco_unitario'] * $item['quantidade']; $subtotal_total += $subtotal_item; ?>
                    <tr>
                        <td>
                            <img src="../<?php echo htmlspecialchars($item['imagem_url']); ?>" alt="Miniatura">
                            <?php echo htmlspecialchars($item['nome_produto']); ?> 
                            <?php if (!empty($item['tamanho_variacao'])): ?>
                                <small>(Tam: <?php echo htmlspecialchars($item['tamanho_variacao']); ?>)</small>
                            <?php endif; ?>
                        </td>
                        <td>R$ <?php echo number_format($item['preco_unitario'], 2, ',', '.'); ?></td>
                        <td><?php echo htmlspecialchars($item['quantidade']); ?></td>
                        <td>R$ <?php echo number_format($subtotal_item, 2, ',', '.'); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

    </div>

</body>
</html>