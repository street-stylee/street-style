<?php
// admin_dashboard.php

// Inclui o controle de acesso para garantir que apenas o admin possa ver esta página
require_once 'admin_auth.php'; 
require_once '../formu.php'; // Conexão com o banco

// ----------------------------------------------------
// 1. BUSCA DE DADOS PARA O DASHBOARD
// ----------------------------------------------------

$total_pedidos = 0;
$total_vendas = 0.00;
$total_clientes = 0;

// a) Contar Pedidos e Clientes (simples)
$sql_counts = "SELECT 
                    (SELECT COUNT(id) FROM pedidos) AS total_pedidos,
                    (SELECT COUNT(id) FROM usuarios) AS total_clientes,
                    (SELECT SUM(total_geral) FROM pedidos WHERE status = 'Concluido') AS total_vendas"; // Assumindo 'Concluido' como status de sucesso

$resultado = $conexao->query($sql_counts);
if ($resultado && $row = $resultado->fetch_assoc()) {
    $total_pedidos = $row['total_pedidos'];
    $total_vendas = $row['total_vendas'] ?? 0.00; // Usa 0.00 se for NULL
    $total_clientes = $row['total_clientes'];
}

$conexao->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | Administração Street Style</title>
    <link rel="stylesheet" href="../_ADM/css/admin_style.css"> 
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    
    <style>
        /* CSS BÁSICO PARA O DASHBOARD (admin_style.css deve ter mais) */
        body { background-color: #f4f4f4; color: #333; }
        .dashboard-container { max-width: 1200px; margin: 100px auto 50px; padding: 20px; }
        .header-admin { border-bottom: 3px solid #333; padding-bottom: 10px; margin-bottom: 30px; }
        .stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 40px; }
        .stat-card { background-color: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); display: flex; justify-content: space-between; align-items: center; }
        .stat-card i { font-size: 2.5rem; color: #27ae60; }
        .stat-card .value { font-size: 2.2rem; font-weight: 700; }
        .stat-card .label { font-size: 0.9rem; text-transform: uppercase; color: #777; }
        .nav-admin a { background-color: #333; color: #fff; padding: 10px 15px; text-decoration: none; border-radius: 4px; margin-right: 10px; transition: background-color 0.3s; }
        .nav-admin a:hover { background-color: #555; }
    </style>
</head>
<body>

    <div class="dashboard-container">
        <h1 class="header-admin"><i class='bx bxs-dashboard'></i> Painel de Administração</h1>

        <div class="nav-admin" style="margin-bottom: 30px;">
            <a href="admin_pedidos.php"><i class='bx bxs-package'></i> Gerenciar Pedidos</a>
            <a href="admin_produtos.php"><i class='bx bxs-t-shirt'></i> Gerenciar Produtos</a>
            <a href="admin_usuarios.php"><i class='bx bxs-user-account'></i> Gerenciar Usuários</a>
            <a href="../logout.php" style="float: right; background-color: #c0392b;"><i class='bx bx-log-out'></i> Sair</a>
        </div>
        
        <h2>Resumo Rápido</h2>
        <div class="stats-grid">
            <div class="stat-card">
                <div>
                    <div class="label">Total de Vendas</div>
                    <div class="value">R$ <?php echo number_format($total_vendas, 2, ',', '.'); ?></div>
                </div>
                <i class='bx bx-dollar-circle'></i>
            </div>
            
            <div class="stat-card">
                <div>
                    <div class="label">Pedidos Totais</div>
                    <div class="value"><?php echo $total_pedidos; ?></div>
                </div>
                <i class='bx bxs-package'></i>
            </div>
            
            <div class="stat-card">
                <div>
                    <div class="label">Clientes Registrados</div>
                    <div class="value"><?php echo $total_clientes; ?></div>
                </div>
                <i class='bx bxs-group'></i>
            </div>
        </div>

        <div style="background-color: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.05);">
            <h3>Últimos Pedidos</h3>
            <p>Área a ser preenchida com uma lista dos pedidos mais recentes.</p>
        </div>

    </div>

</body>
</html>