<?php
// admin_auth.php

// 1. Inicia a sessão para acessar as variáveis de sessão
@session_start();

// 2. Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    // Redireciona para a página de login se não estiver logado
    header("Location: ../login.php");
    exit;
}

// 3. Verifica se o usuário logado é o administrador (ID = 1)
// **ATENÇÃO:** Esta é uma verificação SIMPLES e não segura para produção.
// Em um sistema real, você usaria uma coluna 'role' ou 'permissao' no banco.
$admin_id_simulado = 1; 

if ($_SESSION['usuario_id'] != $admin_id_simulado) {
    // Redireciona para uma página de erro ou para a home se não for o admin
    header("Location: ../index.php");
    exit;
}

// Se o código chegou até aqui, o usuário é o administrador e pode prosseguir.
?>