<?php
// admin_pedidos.php - Código COMPLETO e ATUALIZADO (Listagem)

// --- INCLUSÕES ESSENCIAIS ---
// Certifique-se de que estes arquivos existam e estejam nos caminhos corretos:
// admin_auth.php: Verifica se o usuário é admin e está logado.
// ../formu.php: Contém a variável de conexão $conexao (caminho para a raiz).
require_once 'admin_auth.php';
require_once '../formu.php';

$pedidos = [];
$status_filtro = $_GET['status'] ?? 'Todos'; // Filtro por status (ex: Pendente)
// Novo filtro: ID do usuário (vindo do admin_usuarios.php, se implementado)
$user_id_filtro = filter_input(INPUT_GET, 'user_id', FILTER_VALIDATE_INT);
$params = [];
$types = '';


// 1. Lógica para Mudar o Status (Ação POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    $pedido_id = $_POST['pedido_id'] ?? null;
    $novo_status = $_POST['novo_status'] ?? null;

    if ($pedido_id && $novo_status) {
        $sql_update = "UPDATE pedidos SET status = ? WHERE id = ?";
        $stmt_update = $conexao->prepare($sql_update);
        if ($stmt_update) {
            $stmt_update->bind_param("si", $novo_status, $pedido_id);
            if ($stmt_update->execute()) {
                // Redireciona para evitar reenvio do formulário e mantém o filtro atual
                $redirect_url = "admin_pedidos.php?status=" . urlencode($status_filtro);
                if ($user_id_filtro) {
                    $redirect_url .= "&user_id=" . $user_id_filtro;
                }
                // Adiciona a mensagem de sucesso na URL
                header("Location: {$redirect_url}&status_msg=success");
                exit;
            } else {
                $mensagem_status = "Erro ao atualizar status: " . $stmt_update->error;
            }
            $stmt_update->close();
        }
    }
}

// 2. Constrói a cláusula WHERE para os filtros GET (Status e Usuário)
$where_parts = [];

if ($status_filtro !== 'Todos') {
    $where_parts[] = "p.status = ?";
    $params[] = $status_filtro;
    $types .= "s";
}

if ($user_id_filtro) {
    $where_parts[] = "p.usuario_id = ?";
    $params[] = $user_id_filtro;
    $types .= "i";
}

$where_clause = empty($where_parts) ? "" : "WHERE " . implode(" AND ", $where_parts);


// 3. Lógica para Buscar e Listar os Pedidos
$sql_pedidos = "SELECT 
                    p.id, 
                    p.data_pedido, 
                    p.total_geral, 
                    p.status, 
                    u.nome AS nome_usuario, 
                    u.email AS email_usuario
                FROM pedidos p
                JOIN usuarios u ON p.usuario_id = u.id
                {$where_clause}
                ORDER BY p.data_pedido DESC";

$stmt = $conexao->prepare($sql_pedidos);

if ($stmt) {
    if (!empty($params)) {
        // Vincula os parâmetros dinamicamente (para status e/ou user_id)
        $stmt->bind_param($types, ...$params);
    }

    $stmt->execute();
    $resultado = $stmt->get_result();

    while ($pedido = $resultado->fetch_assoc()) {
        $pedidos[] = $pedido;
    }
    $stmt->close();
}

// Fechamento da Conexão
$conexao->close();

// Definição de Status para o Select
$status_opcoes = ['Pendente', 'Pago', 'Em Preparação', 'Enviado', 'Entregue', 'Cancelado'];

// Função para formatar o status (remove espaços para a classe CSS)
function format_status_class($status) {
    return str_replace(' ', '', htmlspecialchars($status));
}

// Verifica mensagem de status de redirecionamento
if (isset($_GET['status_msg']) && $_GET['status_msg'] === 'success') {
    $mensagem_status = "Status do Pedido atualizado com sucesso!";
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Pedidos | Admin</title>
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="../_ADM/css/admin_style.css"> 
    <style>
        /* Estilos CSS Específicos */
        body { background-color: #f4f4f4; color: #333; }
        .admin-container { max-width: 1200px; margin: 50px auto; padding: 20px; background-color: #fff; border-radius: 8px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); }
        h1 { border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; }
        .filter-bar { margin-bottom: 20px; display: flex; align-items: center; gap: 15px; }
        .filter-bar select { padding: 8px; border-radius: 5px; border: 1px solid #ccc; }
        .data-table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        .data-table th, .data-table td { padding: 12px; border: 1px solid #eee; text-align: left; }
        .data-table th { background-color: #333; color: #fff; font-weight: 600; }
        .data-table tr:nth-child(even) { background-color: #f9f9f9; }
        
        /* Estilos de Status */
        .status-tag { padding: 5px 10px; border-radius: 4px; font-weight: 600; font-size: 0.9em; text-transform: uppercase; }
        .status-Pendente { background-color: #fff3cd; color: #856404; }
        .status-Pago { background-color: #d4edda; color: #155724; }
        .status-EmPreparação { background-color: #d1ecf1; color: #0c5460; }
        .status-Enviado { background-color: #cce5ff; color: #004085; }
        .status-Entregue { background-color: #d4edda; color: #155724; }
        .status-Cancelado { background-color: #f8d7da; color: #721c24; }
        
        /* Formulário de Ação */
        .status-form { display: flex; gap: 5px; align-items: center; margin-top: 5px; }
        .status-form select { padding: 6px; border-radius: 4px; }
        .status-form button { background-color: #27ae60; color: #fff; border: none; padding: 6px 10px; border-radius: 4px; cursor: pointer; transition: background-color 0.3s; }
        .action-link { background-color: #3498db; color: #fff; padding: 6px 10px; border-radius: 4px; text-decoration: none; font-size: 0.9em; }
        .action-link:hover { background-color: #2980b9; }
        .alert-success { padding: 10px; background-color: #d4edda; color: #155724; border-radius: 5px; margin-bottom: 20px; }
    </style>
</head>

<body>

    <div class="admin-container">
        <h1><i class='bx bxs-package'></i> Gerenciar Pedidos</h1>

        <?php if (isset($mensagem_status)): ?>
            <div class="alert-success"><?php echo $mensagem_status; ?></div>
        <?php endif; ?>

        <div class="filter-bar">
            <label for="status-filter">Filtrar por Status:</label>
            <select id="status-filter" onchange="window.location.href='admin_pedidos.php?status=' + this.value">
                <option value="Todos" <?php echo ($status_filtro === 'Todos') ? 'selected' : ''; ?>>Todos</option>
                <?php foreach ($status_opcoes as $op): ?>
                    <option value="<?php echo $op; ?>" <?php echo ($status_filtro === $op) ? 'selected' : ''; ?>>
                        <?php echo $op; ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <?php if ($user_id_filtro): ?>
                <span style="font-weight: 700; color: #c0392b;">(Filtrando por Cliente #<?php echo $user_id_filtro; ?>)</span>
                <a href="admin_pedidos.php" style="color: #c0392b; margin-left: -5px;">Limpar Filtro</a>
            <?php endif; ?>

            <a href="admin_dashboard.php" style="margin-left: auto; text-decoration: none; color: #333;">Voltar ao Dashboard</a>
        </div>

        <?php if (empty($pedidos)): ?>
            <p>Nenhum pedido encontrado com os filtros aplicados.</p>
        <?php else: ?>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Data/Hora</th>
                        <th>Cliente</th>
                        <th>Total</th>
                        <th>Status Atual</th>
                        <th>Ação</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pedidos as $pedido): ?>
                        <tr>
                            <td>#<?php echo htmlspecialchars($pedido['id']); ?></td>
                            <td><?php echo date('d/m/Y H:i', strtotime($pedido['data_pedido'])); ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($pedido['nome_usuario']); ?></strong><br>
                                <small><?php echo htmlspecialchars($pedido['email_usuario']); ?></small>
                            </td>
                            <td>R$ <?php echo number_format($pedido['total_geral'], 2, ',', '.'); ?></td>
                            <td>
                                <span class="status-tag status-<?php echo format_status_class($pedido['status']); ?>">
                                    <?php echo htmlspecialchars($pedido['status']); ?>
                                </span>
                            </td>
                            <td style="white-space: nowrap;">
                                <a href="admin_pedido_detalhe.php?id=<?php echo $pedido['id']; ?>" class="action-link" title="Ver Detalhes"><i class='bx bx-search-alt'></i> Detalhes</a>

                                <form method="POST" class="status-form">
                                    <input type="hidden" name="action" value="update_status">
                                    <input type="hidden" name="pedido_id" value="<?php echo $pedido['id']; ?>">
                                    <select name="novo_status" required>
                                        <?php foreach ($status_opcoes as $op): ?>
                                            <option value="<?php echo $op; ?>"
                                                <?php echo ($pedido['status'] === $op) ? 'selected' : ''; ?>>
                                                <?php echo $op; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="submit">Mudar</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

</body>
</html>