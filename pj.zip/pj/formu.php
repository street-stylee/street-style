<?php 
// Arquivo: formu.php

// 1. LÓGICA DE SESSÃO E LOGIN
// ===============================================

// Garante que a sessão seja iniciada
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Inicializa as variáveis como 'não logado'
$usuario_logado = false;
$primeiro_nome = 'Visitante';

// Verifica a sessão
if (isset($_SESSION['logado']) && $_SESSION['logado'] === true) {
    
    $usuario_logado = true;
    
    if (isset($_SESSION['nome_usuario'])) {
        $nome_completo = $_SESSION['nome_usuario'];
        $partes_nome = explode(' ', $nome_completo);
        $primeiro_nome = $partes_nome[0];
    }
}

// 2. LÓGICA DE CONEXÃO COM O BANCO
// ===============================================

$conexao = new mysqli("localhost:3306", "root", "", "testebe");

if ($conexao->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conexao->connect_error);
}

$conexao->set_charset("utf8");

// NOTA: Removida a tag de fechamento ?>